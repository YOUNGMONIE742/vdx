export function LoadingScreen({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="grid min-h-[40vh] place-items-center px-4">
      <div className="flex flex-col items-center gap-4">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-foreground text-background font-bold animate-pulse">V</div>
        <div className="h-1.5 w-40 overflow-hidden rounded-full bg-secondary">
          <div className="h-full w-1/3 animate-[loading_1.2s_ease-in-out_infinite] bg-primary"></div>
        </div>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
      <style>{`@keyframes loading { 0%{transform:translateX(-100%)} 100%{transform:translateX(300%)} }`}</style>
    </div>
  );
}
