import { Link } from "@tanstack/react-router";
import { ShieldX } from "lucide-react";
import { Button } from "@/components/ui/button";

export function AccessDenied({ message = "You do not have permission." }: { message?: string }) {
  return (
    <div className="mx-auto max-w-md px-4 py-20 text-center">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-destructive/10 text-destructive">
        <ShieldX className="h-7 w-7" />
      </div>
      <h1 className="mt-6 font-display text-3xl font-bold">Access Denied</h1>
      <p className="mt-2 text-muted-foreground">{message}</p>
      <div className="mt-6">
        <Link to="/">
          <Button variant="outline">Back to home</Button>
        </Link>
      </div>
    </div>
  );
}
