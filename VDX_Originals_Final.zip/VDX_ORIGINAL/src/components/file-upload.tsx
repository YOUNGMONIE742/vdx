import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Upload, X, Loader2, FileCheck2 } from "lucide-react";
import { toast } from "sonner";
import type { StoredBucket } from "./stored-image";

type Props = {
  bucket: StoredBucket;
  /** prefix (folder) inside bucket; trailing slash optional */
  prefix: string;
  accept?: string;
  maxMB?: number;
  label?: string;
  value: string | null;
  onChange: (path: string | null) => void;
};

export function FileUpload({
  bucket,
  prefix,
  accept = "image/*",
  maxMB = 5,
  label = "Upload file",
  value,
  onChange,
}: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function handle(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > maxMB * 1024 * 1024) {
      toast.error(`File too large. Max ${maxMB}MB.`);
      return;
    }
    setBusy(true);
    const ext = f.name.split(".").pop() ?? "bin";
    const cleanPrefix = prefix.replace(/\/+$/, "");
    const path = `${cleanPrefix}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage
      .from(bucket)
      .upload(path, f, { upsert: false, contentType: f.type });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    onChange(path);
    toast.success("Uploaded");
  }

  return (
    <div className="flex items-center gap-3">
      <input ref={inputRef} type="file" accept={accept} className="hidden" onChange={handle} />
      {value ? (
        <div className="flex items-center gap-2 rounded-full border border-border bg-secondary px-3 py-1.5 text-xs">
          <FileCheck2 className="h-3.5 w-3.5 text-emerald-600" />
          <span className="max-w-[180px] truncate font-mono">{value.split("/").pop()}</span>
          <button type="button" onClick={() => onChange(null)} aria-label="Remove">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      ) : null}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="rounded-full"
        disabled={busy}
        onClick={() => inputRef.current?.click()}
      >
        {busy ? (
          <Loader2 className="mr-1 h-4 w-4 animate-spin" />
        ) : (
          <Upload className="mr-1 h-4 w-4" />
        )}
        {value ? "Replace" : label}
      </Button>
    </div>
  );
}
