import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-border bg-card">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-foreground text-background font-bold">V</div>
            <div><p className="text-sm font-bold tracking-[0.18em]">VDX</p><p className="text-[9px] tracking-[0.28em] text-muted-foreground">ORIGINALS</p></div>
          </div>
          <p className="mt-5 max-w-sm text-sm leading-6 text-muted-foreground">Contemporary clothing, carefully selected for confident everyday style.</p>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-[0.18em]">Explore</h4>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li><Link to="/shop" className="hover:text-foreground">Shop</Link></li>
            <li><Link to="/categories" className="hover:text-foreground">Collections</Link></li>
            <li><Link to="/about" className="hover:text-foreground">About</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-bold uppercase tracking-[0.18em]">Contact</h4>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0" /> Best Plaza, Kachia Road, Sabo, Kaduna</li>
            <li className="flex gap-2"><Mail className="mt-0.5 h-4 w-4 shrink-0" /><a href="mailto:vdxoriginals@gmail.com" className="hover:text-foreground">vdxoriginals@gmail.com</a></li>
            <li className="flex gap-2"><Phone className="mt-0.5 h-4 w-4 shrink-0" /><a href="tel:07070273404" className="hover:text-foreground">07070273404</a></li>
            <li><a href="https://wa.me/2349115066738" target="_blank" rel="noreferrer" className="font-medium text-foreground hover:underline">WhatsApp · 09115066738</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border"><div className="mx-auto max-w-7xl px-4 py-5 text-xs text-muted-foreground sm:px-6">© {new Date().getFullYear()} VDX Originals. All rights reserved.</div></div>
    </footer>
  );
}
