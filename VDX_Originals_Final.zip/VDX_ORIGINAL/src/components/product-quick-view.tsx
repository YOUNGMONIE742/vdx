import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoredImage } from "@/components/stored-image";
import { Button } from "@/components/ui/button";
import { ngn } from "@/lib/format";
import { useCart } from "@/lib/cart-context";
import { parseVariantGroups, variantSummary } from "@/lib/variants";
import { Minus, Plus, ShoppingBag, X } from "lucide-react";
import { toast } from "sonner";

/** Modal quick view: image, price, variants, quantity and add-to-cart without leaving the grid. */
export function ProductQuickView({
  productId,
  onClose,
}: {
  productId: string;
  onClose: () => void;
}) {
  const cart = useCart();
  const [qty, setQty] = useState(1);
  const [selection, setSelection] = useState<Record<string, string>>({});

  const { data: product, isLoading } = useQuery({
    queryKey: ["quick-view", productId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select(
          "id, title, slug, short_description, price_ngn, discount_price_ngn, stock, reserved_stock, primary_image_url, variants, sold_by_type, vendor_id",
        )
        .eq("id", productId)
        .eq("status", "approved")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const groups = parseVariantGroups(product?.variants);
  const groupNames = Object.keys(groups);
  const available = product ? Math.max(0, (product.stock ?? 0) - (product.reserved_stock ?? 0)) : 0;
  const vendorName = "VDX Originals";

  function addToCart() {
    if (!product) return;
    const missing = groupNames.filter((g) => !selection[g]);
    if (missing.length) {
      toast.error(`Please choose ${missing.join(" and ")} first.`);
      return;
    }
    if (available <= 0) {
      toast.error("Out of stock");
      return;
    }
    cart.add({
      product_id: product.id,
      title: product.title,
      slug: product.slug,
      price_ngn: Number(product.discount_price_ngn ?? product.price_ngn),
      quantity: qty,
      image: product.primary_image_url,
      vendor_id: product.vendor_id,
      vendor_name: vendorName,
      sold_by_type: product.sold_by_type as "vendor" | "welcome_wagon",
      stock: available,
      variant: variantSummary(selection),
    });
    toast.success(`Added ${qty} × ${product.title} to cart`);
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="w-full max-w-2xl overflow-hidden rounded-2xl bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label="Quick view"
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <h3 className="font-display text-lg font-semibold">Quick view</h3>
          <button
            onClick={onClose}
            aria-label="Close"
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        {isLoading || !product ? (
          <div className="grid gap-4 p-5 sm:grid-cols-2">
            <div className="aspect-square animate-pulse rounded-xl bg-secondary" />
            <div className="space-y-3">
              <div className="h-6 w-3/4 animate-pulse rounded bg-secondary" />
              <div className="h-5 w-24 animate-pulse rounded bg-secondary" />
              <div className="h-16 w-full animate-pulse rounded-xl bg-secondary" />
            </div>
          </div>
        ) : (
          <div className="grid gap-5 p-5 sm:grid-cols-2">
            <div className="aspect-square overflow-hidden rounded-xl bg-secondary">
              <StoredImage
                bucket="product-media"
                path={product.primary_image_url}
                alt={product.title}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="flex flex-col">
              <h4 className="font-display text-xl font-bold">{product.title}</h4>
              <p className="text-xs text-muted-foreground">VDX Originals</p>
              <div className="mt-2 flex items-baseline gap-2">
                {product.discount_price_ngn ? (
                  <>
                    <p className="text-xl font-bold text-primary">
                      {ngn(product.discount_price_ngn)}
                    </p>
                    <p className="text-sm text-muted-foreground line-through">
                      {ngn(product.price_ngn)}
                    </p>
                  </>
                ) : (
                  <p className="text-xl font-bold text-primary">{ngn(product.price_ngn)}</p>
                )}
              </div>
              {product.short_description && (
                <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">
                  {product.short_description}
                </p>
              )}
              {groupNames.map((group) => (
                <div key={group} className="mt-3">
                  <p className="mb-1 text-xs font-semibold uppercase text-muted-foreground">
                    {group}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {groups[group].map((opt) => {
                      const active = selection[group] === opt;
                      return (
                        <button
                          key={opt}
                          onClick={() => setSelection((s) => ({ ...s, [group]: opt }))}
                          className={`rounded-full border px-3 py-1 text-xs font-medium transition ${active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card hover:border-primary"}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
              <p className="mt-3 text-xs text-muted-foreground">
                <strong className="text-foreground">{available}</strong> available
              </p>
              <div className="mt-auto flex items-center gap-3 pt-4">
                <div className="inline-flex items-center rounded-full border border-border">
                  <button
                    className="grid h-9 w-9 place-items-center"
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    aria-label="Decrease"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-8 text-center text-sm font-semibold">{qty}</span>
                  <button
                    className="grid h-9 w-9 place-items-center"
                    onClick={() => setQty((q) => Math.min(Math.max(available, 1), q + 1))}
                    aria-label="Increase"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
                <Button className="rounded-full" disabled={available === 0} onClick={addToCart}>
                  <ShoppingBag className="mr-1 h-4 w-4" /> Add to cart
                </Button>
              </div>
              <Link
                to="/product/$slug"
                params={{ slug: product.slug }}
                className="mt-3 text-xs font-medium text-primary hover:underline"
              >
                View full details →
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
