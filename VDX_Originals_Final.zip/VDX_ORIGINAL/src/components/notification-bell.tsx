import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, CheckCheck, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { requestPushPermission, showPush } from "@/lib/push";

type Notif = {
  id: string;
  title: string;
  body: string;
  link: string | null;
  read: boolean;
  kind: string;
  created_at: string;
};

function ago(iso: string) {
  const s = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return new Date(iso).toLocaleDateString();
}

export function NotificationBell() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const seen = useRef<Set<string>>(new Set());

  const { data } = useQuery({
    queryKey: ["notification-bell", user?.id],
    enabled: !!user,
    refetchInterval: 30_000,
    queryFn: async (): Promise<Notif[]> => {
      const { data, error } = await supabase
        .from("notifications")
        .select("id, title, body, link, read, kind, created_at")
        .order("created_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return (data ?? []) as Notif[];
    },
  });

  const items = useMemo(() => data ?? [], [data]);
  const unread = items.filter((n) => !n.read).length;

  // Device notification for newly arrived unread items (permission granted only).
  useEffect(() => {
    const first = seen.current.size === 0;
    for (const n of items) {
      if (!seen.current.has(n.id)) {
        seen.current.add(n.id);
        if (!first && !n.read) showPush(n.title, n.body);
      }
    }
  }, [items]);

  if (!user) return null;

  async function markAll() {
    await supabase.from("notifications").update({ read: true }).eq("read", false);
    qc.invalidateQueries({ queryKey: ["notification-bell"] });
  }
  async function markOne(id: string) {
    await supabase.from("notifications").update({ read: true }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notification-bell"] });
  }
  async function remove(id: string) {
    await supabase.from("notifications").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["notification-bell"] });
  }

  return (
    <div className="relative">
      <button
        onClick={() => {
          setOpen((v) => !v);
          void requestPushPermission();
        }}
        aria-label="Notifications"
        className="relative grid h-10 w-10 place-items-center rounded-xl border border-border"
      >
        <Bell className="h-4 w-4" />
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 grid h-5 min-w-[20px] place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-50 mt-2 w-[22rem] max-w-[90vw] overflow-hidden rounded-2xl border border-border bg-card shadow-xl">
            <div className="flex items-center justify-between border-b border-border/60 px-4 py-3">
              <p className="font-display text-sm font-semibold">Notifications</p>
              {unread > 0 && (
                <button
                  onClick={markAll}
                  className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                >
                  <CheckCheck className="h-3.5 w-3.5" /> Mark all read
                </button>
              )}
            </div>
            <ul className="max-h-96 divide-y divide-border/60 overflow-y-auto">
              {items.length === 0 ? (
                <li className="px-4 py-8 text-center text-xs text-muted-foreground">
                  You're all caught up.
                </li>
              ) : (
                items.map((n) => (
                  <li key={n.id} className={`px-4 py-3 text-sm ${n.read ? "" : "bg-primary/5"}`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold">{n.title}</p>
                        <p className="mt-0.5 text-xs text-muted-foreground">{n.body}</p>
                        <p className="mt-1 text-[10px] uppercase tracking-wide text-muted-foreground">
                          {ago(n.created_at)}
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-col gap-1">
                        {!n.read && (
                          <button
                            onClick={() => markOne(n.id)}
                            aria-label="Mark read"
                            className="text-muted-foreground hover:text-primary"
                          >
                            <CheckCheck className="h-4 w-4" />
                          </button>
                        )}
                        <button
                          onClick={() => remove(n.id)}
                          aria-label="Delete"
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    {n.link && (
                      <Link
                        to={n.link as never}
                        onClick={() => setOpen(false)}
                        className="mt-1 inline-block text-xs font-semibold text-primary hover:underline"
                      >
                        Open
                      </Link>
                    )}
                  </li>
                ))
              )}
            </ul>
            <Link
              to="/notifications"
              onClick={() => setOpen(false)}
              className="block border-t border-border/60 px-4 py-3 text-center text-xs font-semibold text-primary hover:bg-secondary"
            >
              View announcements
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
