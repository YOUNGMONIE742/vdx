import { useEffect, useState } from "react";
import { Palette } from "lucide-react";

type ThemeKey = "brand" | "black" | "white" | "blue" | "pink";
const THEMES: { key: ThemeKey; label: string; swatch: string }[] = [
  { key: "brand", label: "Brand (default)", swatch: "linear-gradient(135deg,#6b3fd0,#e79bb6)" },
  { key: "black", label: "Black", swatch: "#111" },
  { key: "white", label: "White", swatch: "#f5f5f5" },
  { key: "blue", label: "Blue", swatch: "#3b6ee0" },
  { key: "pink", label: "Pink", swatch: "#ec6fa1" },
];
const STORAGE = "ww-theme";
const CLASSES: Record<ThemeKey, string> = {
  brand: "",
  black: "theme-black",
  white: "theme-white",
  blue: "theme-blue",
  pink: "theme-pink",
};

export function applyStoredTheme() {
  try {
    const t = (localStorage.getItem(STORAGE) as ThemeKey | null) ?? "brand";
    setTheme(t);
  } catch {
    /* ignore */
  }
}

function setTheme(t: ThemeKey) {
  const root = document.documentElement;
  Object.values(CLASSES).forEach((c) => c && root.classList.remove(c));
  const cls = CLASSES[t];
  if (cls) root.classList.add(cls);
  try {
    localStorage.setItem(STORAGE, t);
  } catch {
    /* ignore */
  }
}

export function ThemeToggle() {
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState<ThemeKey>("brand");

  useEffect(() => {
    try {
      const t = (localStorage.getItem(STORAGE) as ThemeKey | null) ?? "brand";
      setCurrent(t);
    } catch {
      /* ignore */
    }
  }, []);

  function pick(t: ThemeKey) {
    setTheme(t);
    setCurrent(t);
    setOpen(false);
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="grid h-10 w-10 place-items-center rounded-xl border border-border"
        aria-label="Change theme"
        title="Change theme"
      >
        <Palette className="h-4 w-4" />
      </button>
      {open && (
        <>
          <button
            type="button"
            aria-hidden
            className="fixed inset-0 z-40 cursor-default"
            onClick={() => setOpen(false)}
          />
          <div className="fixed left-1/2 top-1/2 z-50 w-64 -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-border bg-popover p-3 shadow-2xl">
            <p className="px-2 py-1.5 text-xs font-semibold uppercase text-muted-foreground">
              Theme
            </p>
            {THEMES.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => pick(t.key)}
                className={`flex w-full items-center gap-2 rounded-xl px-2 py-2 text-left text-sm hover:bg-secondary ${current === t.key ? "bg-secondary" : ""}`}
              >
                <span
                  className="h-5 w-5 rounded-full border border-border"
                  style={{ background: t.swatch }}
                />
                <span className="flex-1">{t.label}</span>
                {current === t.key && <span className="text-xs text-primary">✓</span>}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
