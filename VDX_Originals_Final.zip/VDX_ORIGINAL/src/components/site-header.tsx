import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, User as UserIcon, X } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useCart } from "@/lib/cart-context";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "@/components/theme-toggle";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/categories", label: "Collections" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const { user, loading, signOut } = useAuth();
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  const location = useLocation();
  const isHome = location.pathname === "/";

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    navigate({ to: "/shop", search: { q: q || undefined } as never });
    setOpen(false);
  }

  return (
    <header className={cn("z-40 w-full border-b transition-colors duration-300", isHome ? "absolute left-0 top-0 border-white/10 bg-black/10 text-white backdrop-blur-md" : "sticky top-0 border-border/70 bg-background/90 backdrop-blur-xl")}>
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <button
          className={cn("grid h-10 w-10 place-items-center rounded-xl border md:hidden", isHome ? "border-white/25 bg-white/5 text-white" : "border-border")}
          onClick={() => setOpen((v) => !v)}
          aria-label="Menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>

        <Link to="/" className="flex items-end gap-2.5 leading-none">
          <span className={cn("font-sans text-3xl font-extrabold tracking-[-0.07em] md:text-4xl", isHome ? "text-white" : "text-foreground")}>VDX</span>
          <span className={cn("pb-0.5 font-display text-[10px] font-semibold uppercase tracking-[0.22em] md:text-xs", isHome ? "text-white/75" : "text-muted-foreground")}>ORIGINALS</span>
        </Link>

        <form onSubmit={submitSearch} className="ml-4 hidden flex-1 md:flex">
          <div className="relative w-full max-w-xl">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search the collection…"
              className={cn("h-10 w-full rounded-full border pl-10 pr-4 text-sm outline-none focus:ring-2", isHome ? "border-white/20 bg-white/10 text-white placeholder:text-white/55 focus:border-white/40 focus:ring-white/10" : "border-border bg-card focus:border-foreground focus:ring-foreground/10")}
            />
          </div>
        </form>

        <nav className="ml-auto hidden items-center gap-1 lg:flex">
          {NAV.slice(1).map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className={cn("rounded-full px-3 py-2 text-sm font-medium transition", isHome ? "text-white/80 hover:bg-white/10 hover:text-white" : "text-foreground/70 hover:bg-secondary hover:text-foreground")}
              activeProps={{ className: "text-foreground bg-secondary" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2 lg:ml-2">
          <ThemeToggle />
          <Link to="/cart" className={cn("relative grid h-10 w-10 place-items-center rounded-xl border", isHome ? "border-white/25 bg-white/5 text-white" : "border-border")} aria-label="Cart">
            <ShoppingBag className="h-4 w-4" />
            {count > 0 && (
              <span className={cn("absolute -right-1 -top-1 grid h-5 min-w-[20px] place-items-center rounded-full px-1 text-[10px] font-bold", isHome ? "bg-white text-black" : "bg-foreground text-background")}>
                {count}
              </span>
            )}
          </Link>
          {loading ? null : user ? (
            <Link to="/dashboard">
              <Button size="sm" className={cn("rounded-full", isHome ? "bg-white text-black hover:bg-white/90" : "")}>
                <UserIcon className="mr-1 h-4 w-4" /> Account
              </Button>
            </Link>
          ) : (
            <Link to="/auth">
              <Button size="sm" className={cn("rounded-full", isHome ? "bg-white text-black hover:bg-white/90" : "")}>Sign in</Button>
            </Link>
          )}
        </div>
      </div>

      {open && (
        <div className={cn("border-t md:hidden", isHome ? "border-white/10 bg-black/95 text-white" : "border-border bg-background")}>
          <form onSubmit={submitSearch} className="p-4">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products…" className={cn("h-11 w-full rounded-full border pl-10 pr-4 text-sm outline-none", isHome ? "border-white/20 bg-white/10 text-white placeholder:text-white/55" : "border-border bg-card")} />
            </div>
          </form>
          <nav className="grid gap-1 px-3 pb-4">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className={cn("rounded-xl px-4 py-3 text-sm font-medium text-foreground/80")} activeProps={{ className: "bg-secondary text-foreground" }}>
                {n.label}
              </Link>
            ))}
            <Link to="/support" onClick={() => setOpen(false)} className="rounded-xl px-4 py-3 text-sm font-medium">Support</Link>
            <Link to="/track-order" onClick={() => setOpen(false)} className="rounded-xl px-4 py-3 text-sm font-medium">Track order</Link>
            {user ? (
              <div className="mt-2 grid gap-1 border-t border-border pt-2">
                <Link to="/dashboard" onClick={() => setOpen(false)} className="rounded-xl px-4 py-3 text-sm font-medium">Dashboard</Link>
                <Link to="/settings" onClick={() => setOpen(false)} className="rounded-xl px-4 py-3 text-sm font-medium">Account settings</Link>
                <button type="button" onClick={async () => { setOpen(false); await signOut(); navigate({ to: "/" }); }} className="rounded-xl px-4 py-3 text-left text-sm font-medium text-destructive hover:bg-destructive/10">Sign out</button>
              </div>
            ) : (
              <div className="mt-2 grid grid-cols-2 gap-2 border-t border-border pt-2">
                <Link to="/auth" onClick={() => setOpen(false)} className="rounded-xl border border-border px-4 py-2.5 text-center text-sm font-medium">Sign in</Link>
                <Link to="/auth" search={{ tab: "register" } as never} onClick={() => setOpen(false)} className="rounded-xl bg-foreground px-4 py-2.5 text-center text-sm font-medium text-background">Create account</Link>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
