export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5";
  };
  public: {
    Tables: {
      admin_applications: {
        Row: {
          created_at: string;
          decline_reason: string | null;
          id: string;
          reason: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
          status: Database["public"]["Enums"]["application_status"];
          updated_at: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          decline_reason?: string | null;
          id?: string;
          reason: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          status?: Database["public"]["Enums"]["application_status"];
          updated_at?: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          decline_reason?: string | null;
          id?: string;
          reason?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          status?: Database["public"]["Enums"]["application_status"];
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      announcements: {
        Row: {
          audience: Database["public"]["Enums"]["announcement_audience"];
          body: string;
          created_at: string;
          created_by: string;
          id: string;
          target_user_ids: string[] | null;
          title: string;
        };
        Insert: {
          audience?: Database["public"]["Enums"]["announcement_audience"];
          body: string;
          created_at?: string;
          created_by: string;
          id?: string;
          target_user_ids?: string[] | null;
          title: string;
        };
        Update: {
          audience?: Database["public"]["Enums"]["announcement_audience"];
          body?: string;
          created_at?: string;
          created_by?: string;
          id?: string;
          target_user_ids?: string[] | null;
          title?: string;
        };
        Relationships: [];
      };
      categories: {
        Row: {
          created_at: string;
          description: string | null;
          display_order: number;
          id: string;
          image_url: string | null;
          name: string;
          slug: string;
        };
        Insert: {
          created_at?: string;
          description?: string | null;
          display_order?: number;
          id?: string;
          image_url?: string | null;
          name: string;
          slug: string;
        };
        Update: {
          created_at?: string;
          description?: string | null;
          display_order?: number;
          id?: string;
          image_url?: string | null;
          name?: string;
          slug?: string;
        };
        Relationships: [];
      };
      feedback: {
        Row: {
          created_at: string;
          email: string;
          id: string;
          message: string;
          name: string;
          source: string;
          status: string;
          user_id: string | null;
        };
        Insert: {
          created_at?: string;
          email: string;
          id?: string;
          message: string;
          name: string;
          source?: string;
          status?: string;
          user_id?: string | null;
        };
        Update: {
          created_at?: string;
          email?: string;
          id?: string;
          message?: string;
          name?: string;
          source?: string;
          status?: string;
          user_id?: string | null;
        };
        Relationships: [];
      };
      financial_audit_log: {
        Row: {
          action: string;
          actor_id: string | null;
          actor_role: string | null;
          created_at: string;
          entity_id: string | null;
          entity_type: string | null;
          id: string;
          ip_address: string | null;
          new_value: Json | null;
          previous_value: Json | null;
          vendor_id: string | null;
        };
        Insert: {
          action: string;
          actor_id?: string | null;
          actor_role?: string | null;
          created_at?: string;
          entity_id?: string | null;
          entity_type?: string | null;
          id?: string;
          ip_address?: string | null;
          new_value?: Json | null;
          previous_value?: Json | null;
          vendor_id?: string | null;
        };
        Update: {
          action?: string;
          actor_id?: string | null;
          actor_role?: string | null;
          created_at?: string;
          entity_id?: string | null;
          entity_type?: string | null;
          id?: string;
          ip_address?: string | null;
          new_value?: Json | null;
          previous_value?: Json | null;
          vendor_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "financial_audit_log_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "public_vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "financial_audit_log_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "vendors";
            referencedColumns: ["id"];
          },
        ];
      };
      notification_preferences: {
        Row: {
          announcements: boolean;
          created_at: string;
          orders: boolean;
          payments: boolean;
          push_enabled: boolean;
          reviews: boolean;
          updated_at: string;
          user_id: string;
          wallet: boolean;
        };
        Insert: {
          announcements?: boolean;
          created_at?: string;
          orders?: boolean;
          payments?: boolean;
          push_enabled?: boolean;
          reviews?: boolean;
          updated_at?: string;
          user_id: string;
          wallet?: boolean;
        };
        Update: {
          announcements?: boolean;
          created_at?: string;
          orders?: boolean;
          payments?: boolean;
          push_enabled?: boolean;
          reviews?: boolean;
          updated_at?: string;
          user_id?: string;
          wallet?: boolean;
        };
        Relationships: [];
      };
      notifications: {
        Row: {
          body: string;
          created_at: string;
          id: string;
          kind: string;
          link: string | null;
          read: boolean;
          title: string;
          user_id: string;
        };
        Insert: {
          body: string;
          created_at?: string;
          id?: string;
          kind?: string;
          link?: string | null;
          read?: boolean;
          title: string;
          user_id: string;
        };
        Update: {
          body?: string;
          created_at?: string;
          id?: string;
          kind?: string;
          link?: string | null;
          read?: boolean;
          title?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      order_items: {
        Row: {
          created_at: string;
          id: string;
          order_id: string;
          product_id: string;
          quantity: number;
          sold_by_type: Database["public"]["Enums"]["sold_by_type"];
          subtotal_ngn: number;
          title: string;
          unit_price_ngn: number;
          vendor_id: string | null;
        };
        Insert: {
          created_at?: string;
          id?: string;
          order_id: string;
          product_id: string;
          quantity: number;
          sold_by_type: Database["public"]["Enums"]["sold_by_type"];
          subtotal_ngn: number;
          title: string;
          unit_price_ngn: number;
          vendor_id?: string | null;
        };
        Update: {
          created_at?: string;
          id?: string;
          order_id?: string;
          product_id?: string;
          quantity?: number;
          sold_by_type?: Database["public"]["Enums"]["sold_by_type"];
          subtotal_ngn?: number;
          title?: string;
          unit_price_ngn?: number;
          vendor_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey";
            columns: ["order_id"];
            isOneToOne: false;
            referencedRelation: "orders";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "order_items_product_id_fkey";
            columns: ["product_id"];
            isOneToOne: false;
            referencedRelation: "products";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "order_items_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "public_vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "order_items_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "vendors";
            referencedColumns: ["id"];
          },
        ];
      };
      orders: {
        Row: {
          contact_phone: string | null;
          created_at: string;
          customer_email: string | null;
          customer_name: string | null;
          id: string;
          notes: string | null;
          order_number: string;
          payment_expires_at: string | null;
          shipping_address: Json | null;
          shipping_ngn: number;
          status: Database["public"]["Enums"]["order_status"];
          stock_consumed: boolean;
          subtotal_ngn: number;
          total_ngn: number;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          contact_phone?: string | null;
          created_at?: string;
          customer_email?: string | null;
          customer_name?: string | null;
          id?: string;
          notes?: string | null;
          order_number?: string;
          payment_expires_at?: string | null;
          shipping_address?: Json | null;
          shipping_ngn?: number;
          status?: Database["public"]["Enums"]["order_status"];
          stock_consumed?: boolean;
          subtotal_ngn?: number;
          total_ngn?: number;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          contact_phone?: string | null;
          created_at?: string;
          customer_email?: string | null;
          customer_name?: string | null;
          id?: string;
          notes?: string | null;
          order_number?: string;
          payment_expires_at?: string | null;
          shipping_address?: Json | null;
          shipping_ngn?: number;
          status?: Database["public"]["Enums"]["order_status"];
          stock_consumed?: boolean;
          subtotal_ngn?: number;
          total_ngn?: number;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      payments: {
        Row: {
          amount_ngn: number;
          created_at: string;
          id: string;
          order_id: string;
          proof_url: string | null;
          transaction_id: string | null;
          user_id: string;
          verified: boolean;
          verified_at: string | null;
          verified_by: string | null;
        };
        Insert: {
          amount_ngn: number;
          created_at?: string;
          id?: string;
          order_id: string;
          proof_url?: string | null;
          transaction_id?: string | null;
          user_id: string;
          verified?: boolean;
          verified_at?: string | null;
          verified_by?: string | null;
        };
        Update: {
          amount_ngn?: number;
          created_at?: string;
          id?: string;
          order_id?: string;
          proof_url?: string | null;
          transaction_id?: string | null;
          user_id?: string;
          verified?: boolean;
          verified_at?: string | null;
          verified_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "payments_order_id_fkey";
            columns: ["order_id"];
            isOneToOne: false;
            referencedRelation: "orders";
            referencedColumns: ["id"];
          },
        ];
      };
      product_images: {
        Row: {
          created_at: string;
          display_order: number;
          id: string;
          product_id: string;
          url: string;
        };
        Insert: {
          created_at?: string;
          display_order?: number;
          id?: string;
          product_id: string;
          url: string;
        };
        Update: {
          created_at?: string;
          display_order?: number;
          id?: string;
          product_id?: string;
          url?: string;
        };
        Relationships: [
          {
            foreignKeyName: "product_images_product_id_fkey";
            columns: ["product_id"];
            isOneToOne: false;
            referencedRelation: "products";
            referencedColumns: ["id"];
          },
        ];
      };
      products: {
        Row: {
          brand: string | null;
          category_id: string | null;
          condition: string | null;
          created_at: string;
          created_by: string;
          decline_reason: string | null;
          delivery_time: string | null;
          description: string | null;
          dimensions: string | null;
          discount_price_ngn: number | null;
          id: string;
          images: string[] | null;
          is_featured: boolean | null;
          low_stock_threshold: number;
          price_ngn: number;
          primary_image_url: string | null;
          product_code: string | null;
          reserved_stock: number;
          return_policy: string | null;
          shipping_fee_ngn: number | null;
          short_description: string | null;
          sku: string | null;
          slug: string;
          sold_by: string | null;
          sold_by_type: Database["public"]["Enums"]["sold_by_type"];
          status: Database["public"]["Enums"]["product_status"];
          stock: number;
          subcategory: string | null;
          supplier: string | null;
          tags: string[] | null;
          title: string;
          updated_at: string;
          variants: Json | null;
          vendor_id: string | null;
          video_url: string | null;
          visibility: string | null;
          warranty: string | null;
          weight: string | null;
        };
        Insert: {
          brand?: string | null;
          category_id?: string | null;
          condition?: string | null;
          created_at?: string;
          created_by: string;
          decline_reason?: string | null;
          delivery_time?: string | null;
          description?: string | null;
          dimensions?: string | null;
          discount_price_ngn?: number | null;
          id?: string;
          images?: string[] | null;
          is_featured?: boolean | null;
          low_stock_threshold?: number;
          price_ngn: number;
          primary_image_url?: string | null;
          product_code?: string | null;
          reserved_stock?: number;
          return_policy?: string | null;
          shipping_fee_ngn?: number | null;
          short_description?: string | null;
          sku?: string | null;
          slug: string;
          sold_by?: string | null;
          sold_by_type?: Database["public"]["Enums"]["sold_by_type"];
          status?: Database["public"]["Enums"]["product_status"];
          stock?: number;
          subcategory?: string | null;
          supplier?: string | null;
          tags?: string[] | null;
          title: string;
          updated_at?: string;
          variants?: Json | null;
          vendor_id?: string | null;
          video_url?: string | null;
          visibility?: string | null;
          warranty?: string | null;
          weight?: string | null;
        };
        Update: {
          brand?: string | null;
          category_id?: string | null;
          condition?: string | null;
          created_at?: string;
          created_by?: string;
          decline_reason?: string | null;
          delivery_time?: string | null;
          description?: string | null;
          dimensions?: string | null;
          discount_price_ngn?: number | null;
          id?: string;
          images?: string[] | null;
          is_featured?: boolean | null;
          low_stock_threshold?: number;
          price_ngn?: number;
          primary_image_url?: string | null;
          product_code?: string | null;
          reserved_stock?: number;
          return_policy?: string | null;
          shipping_fee_ngn?: number | null;
          short_description?: string | null;
          sku?: string | null;
          slug?: string;
          sold_by?: string | null;
          sold_by_type?: Database["public"]["Enums"]["sold_by_type"];
          status?: Database["public"]["Enums"]["product_status"];
          stock?: number;
          subcategory?: string | null;
          supplier?: string | null;
          tags?: string[] | null;
          title?: string;
          updated_at?: string;
          variants?: Json | null;
          vendor_id?: string | null;
          video_url?: string | null;
          visibility?: string | null;
          warranty?: string | null;
          weight?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "products_category_id_fkey";
            columns: ["category_id"];
            isOneToOne: false;
            referencedRelation: "categories";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "products_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "public_vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "products_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "vendors";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          avatar_url: string | null;
          is_active: boolean;
          created_at: string;
          email: string;
          full_name: string | null;
          id: string;
          phone: string | null;
          updated_at: string;
          username: string | null;
        };
        Insert: {
          avatar_url?: string | null;
          is_active?: boolean;
          created_at?: string;
          email: string;
          full_name?: string | null;
          id: string;
          phone?: string | null;
          updated_at?: string;
          username?: string | null;
        };
        Update: {
          avatar_url?: string | null;
          is_active?: boolean;
          created_at?: string;
          email?: string;
          full_name?: string | null;
          id?: string;
          phone?: string | null;
          updated_at?: string;
          username?: string | null;
        };
        Relationships: [];
      };
      settings: {
        Row: {
          is_public: boolean;
          key: string;
          updated_at: string;
          value: Json;
        };
        Insert: {
          is_public?: boolean;
          key: string;
          updated_at?: string;
          value?: Json;
        };
        Update: {
          is_public?: boolean;
          key?: string;
          updated_at?: string;
          value?: Json;
        };
        Relationships: [];
      };
      user_roles: {
        Row: {
          created_at: string;
          id: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          role?: Database["public"]["Enums"]["app_role"];
          user_id?: string;
        };
        Relationships: [];
      };
      vendor_applications: {
        Row: {
          contact_email: string | null;
          contact_phone: string | null;
          created_at: string;
          decline_reason: string | null;
          id: string;
          payment_amount: number | null;
          payment_proof_url: string | null;
          payment_transaction_id: string | null;
          payment_verified: boolean;
          reviewed_at: string | null;
          reviewed_by: string | null;
          status: Database["public"]["Enums"]["application_status"];
          store_description: string | null;
          store_logo_url: string | null;
          store_name: string;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          contact_email?: string | null;
          contact_phone?: string | null;
          created_at?: string;
          decline_reason?: string | null;
          id?: string;
          payment_amount?: number | null;
          payment_proof_url?: string | null;
          payment_transaction_id?: string | null;
          payment_verified?: boolean;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          status?: Database["public"]["Enums"]["application_status"];
          store_description?: string | null;
          store_logo_url?: string | null;
          store_name: string;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          contact_email?: string | null;
          contact_phone?: string | null;
          created_at?: string;
          decline_reason?: string | null;
          id?: string;
          payment_amount?: number | null;
          payment_proof_url?: string | null;
          payment_transaction_id?: string | null;
          payment_verified?: boolean;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          status?: Database["public"]["Enums"]["application_status"];
          store_description?: string | null;
          store_logo_url?: string | null;
          store_name?: string;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      vendor_bank_accounts: {
        Row: {
          account_name: string;
          account_number: string;
          bank_name: string;
          created_at: string;
          id: string;
          updated_at: string;
          vendor_id: string;
        };
        Insert: {
          account_name: string;
          account_number: string;
          bank_name: string;
          created_at?: string;
          id?: string;
          updated_at?: string;
          vendor_id: string;
        };
        Update: {
          account_name?: string;
          account_number?: string;
          bank_name?: string;
          created_at?: string;
          id?: string;
          updated_at?: string;
          vendor_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "vendor_bank_accounts_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: true;
            referencedRelation: "public_vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "vendor_bank_accounts_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: true;
            referencedRelation: "vendors";
            referencedColumns: ["id"];
          },
        ];
      };
      vendor_ledger: {
        Row: {
          amount_ngn: number;
          available_at: string;
          commission_ngn: number;
          commission_percent: number | null;
          created_at: string;
          description: string | null;
          entry_type: string;
          gross_ngn: number;
          id: string;
          order_id: string | null;
          order_item_id: string | null;
          reference: string;
          vendor_id: string;
          withdrawal_id: string | null;
        };
        Insert: {
          amount_ngn?: number;
          available_at?: string;
          commission_ngn?: number;
          commission_percent?: number | null;
          created_at?: string;
          description?: string | null;
          entry_type: string;
          gross_ngn?: number;
          id?: string;
          order_id?: string | null;
          order_item_id?: string | null;
          reference?: string;
          vendor_id: string;
          withdrawal_id?: string | null;
        };
        Update: {
          amount_ngn?: number;
          available_at?: string;
          commission_ngn?: number;
          commission_percent?: number | null;
          created_at?: string;
          description?: string | null;
          entry_type?: string;
          gross_ngn?: number;
          id?: string;
          order_id?: string | null;
          order_item_id?: string | null;
          reference?: string;
          vendor_id?: string;
          withdrawal_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "vendor_ledger_order_id_fkey";
            columns: ["order_id"];
            isOneToOne: false;
            referencedRelation: "orders";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "vendor_ledger_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "public_vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "vendor_ledger_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "vendor_ledger_withdrawal_id_fkey";
            columns: ["withdrawal_id"];
            isOneToOne: false;
            referencedRelation: "withdrawals";
            referencedColumns: ["id"];
          },
        ];
      };
      vendors: {
        Row: {
          banner_url: string | null;
          business_address: string | null;
          business_hours: string | null;
          commission_percent: number | null;
          contact_email: string | null;
          contact_phone: string | null;
          delivery_policy: string | null;
          description: string | null;
          exchange_policy: string | null;
          id: string;
          is_active: boolean;
          joined_at: string;
          logo_url: string | null;
          rating: number;
          return_policy: string | null;
          slug: string;
          social_links: Json;
          status: Database["public"]["Enums"]["vendor_status"];
          status_changed_at: string | null;
          status_reason: string | null;
          store_name: string;
          total_sold: number;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          banner_url?: string | null;
          business_address?: string | null;
          business_hours?: string | null;
          commission_percent?: number | null;
          contact_email?: string | null;
          contact_phone?: string | null;
          delivery_policy?: string | null;
          description?: string | null;
          exchange_policy?: string | null;
          id?: string;
          is_active?: boolean;
          joined_at?: string;
          logo_url?: string | null;
          rating?: number;
          return_policy?: string | null;
          slug: string;
          social_links?: Json;
          status?: Database["public"]["Enums"]["vendor_status"];
          status_changed_at?: string | null;
          status_reason?: string | null;
          store_name: string;
          total_sold?: number;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          banner_url?: string | null;
          business_address?: string | null;
          business_hours?: string | null;
          commission_percent?: number | null;
          contact_email?: string | null;
          contact_phone?: string | null;
          delivery_policy?: string | null;
          description?: string | null;
          exchange_policy?: string | null;
          id?: string;
          is_active?: boolean;
          joined_at?: string;
          logo_url?: string | null;
          rating?: number;
          return_policy?: string | null;
          slug?: string;
          social_links?: Json;
          status?: Database["public"]["Enums"]["vendor_status"];
          status_changed_at?: string | null;
          status_reason?: string | null;
          store_name?: string;
          total_sold?: number;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      withdrawal_payments: {
        Row: {
          amount_ngn: number;
          created_at: string;
          id: string;
          paid_by: string | null;
          proof_url: string | null;
          vendor_id: string;
          withdrawal_id: string;
        };
        Insert: {
          amount_ngn: number;
          created_at?: string;
          id?: string;
          paid_by?: string | null;
          proof_url?: string | null;
          vendor_id: string;
          withdrawal_id: string;
        };
        Update: {
          amount_ngn?: number;
          created_at?: string;
          id?: string;
          paid_by?: string | null;
          proof_url?: string | null;
          vendor_id?: string;
          withdrawal_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "withdrawal_payments_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "public_vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "withdrawal_payments_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "withdrawal_payments_withdrawal_id_fkey";
            columns: ["withdrawal_id"];
            isOneToOne: false;
            referencedRelation: "withdrawals";
            referencedColumns: ["id"];
          },
        ];
      };
      withdrawals: {
        Row: {
          amount_ngn: number;
          created_at: string;
          decision_reason: string | null;
          id: string;
          note: string | null;
          paid_ngn: number;
          reference: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
          status: string;
          updated_at: string;
          vendor_id: string;
        };
        Insert: {
          amount_ngn: number;
          created_at?: string;
          decision_reason?: string | null;
          id?: string;
          note?: string | null;
          paid_ngn?: number;
          reference?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          status?: string;
          updated_at?: string;
          vendor_id: string;
        };
        Update: {
          amount_ngn?: number;
          created_at?: string;
          decision_reason?: string | null;
          id?: string;
          note?: string | null;
          paid_ngn?: number;
          reference?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          status?: string;
          updated_at?: string;
          vendor_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "withdrawals_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "public_vendors";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "withdrawals_vendor_id_fkey";
            columns: ["vendor_id"];
            isOneToOne: false;
            referencedRelation: "vendors";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: {
      public_vendors: {
        Row: {
          banner_url: string | null;
          description: string | null;
          id: string | null;
          joined_at: string | null;
          logo_url: string | null;
          rating: number | null;
          slug: string | null;
          store_name: string | null;
          total_sold: number | null;
        };
        Insert: {
          banner_url?: string | null;
          description?: string | null;
          id?: string | null;
          joined_at?: string | null;
          logo_url?: string | null;
          rating?: number | null;
          slug?: string | null;
          store_name?: string | null;
          total_sold?: number | null;
        };
        Update: {
          banner_url?: string | null;
          description?: string | null;
          id?: string | null;
          joined_at?: string | null;
          logo_url?: string | null;
          rating?: number | null;
          slug?: string | null;
          store_name?: string | null;
          total_sold?: number | null;
        };
        Relationships: [];
      };
    };
    Functions: {
      get_admin_users: { Args: Record<string, never>; Returns: { id: string; email: string; full_name: string | null; phone: string | null; created_at: string; is_active: boolean; roles: Database["public"]["Enums"]["app_role"][] }[] };
      set_user_active: { Args: { p_active: boolean; p_user_id: string }; Returns: boolean };
      approve_vendor_application: {
        Args: { p_app_id: string };
        Returns: string;
      };
      cancel_withdrawal: { Args: { p_id: string }; Returns: undefined };
      finance_settings: {
        Args: never;
        Returns: {
          key: string;
          value: Json;
        }[];
      };
      products_availability: {
        Args: { p_ids: string[] };
        Returns: {
          available: boolean;
          product_id: string;
          stock: number;
        }[];
      };
      record_withdrawal_payment: {
        Args: { p_amount: number; p_id: string; p_proof_url: string };
        Returns: string;
      };
      request_withdrawal: {
        Args: { p_amount: number; p_note?: string };
        Returns: string;
      };
      review_withdrawal: {
        Args: { p_approve: boolean; p_id: string; p_reason?: string };
        Returns: undefined;
      };
      set_finance_setting: {
        Args: { p_key: string; p_value: Json };
        Returns: undefined;
      };
      set_vendor_commission: {
        Args: { p_percent: number; p_vendor: string };
        Returns: undefined;
      };
      set_vendor_status: {
        Args: { p_reason?: string; p_status: string; p_vendor: string };
        Returns: undefined;
      };
      vendor_wallets: {
        Args: never;
        Returns: {
          available_balance: number;
          commission_percent: number;
          commission_total: number;
          gross_sales: number;
          is_active: boolean;
          paid_out: number;
          pending_balance: number;
          pending_withdrawals: number;
          refunds_total: number;
          store_name: string;
          vendor_id: string;
          wallet_balance: number;
          withdrawals_requested: number;
        }[];
      };
    };
    Enums: {
      announcement_audience: "customers" | "vendors" | "admins" | "all";
      app_role: "customer" | "vendor" | "admin" | "super_admin";
      application_status: "pending" | "approved" | "declined";
      order_status:
        | "pending_payment"
        | "payment_review"
        | "paid"
        | "processing"
        | "shipped"
        | "delivered"
        | "cancelled"
        | "packed"
        | "out_for_delivery"
        | "refunded"
        | "returned";
      product_status: "draft" | "pending_review" | "approved" | "declined";
      sold_by_type: "welcome_wagon" | "vendor";
      vendor_status: "pending" | "active" | "suspended" | "terminated";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      announcement_audience: ["customers", "vendors", "admins", "all"],
      app_role: ["customer", "vendor", "admin", "super_admin"],
      application_status: ["pending", "approved", "declined"],
      order_status: [
        "pending_payment",
        "payment_review",
        "paid",
        "processing",
        "shipped",
        "delivered",
        "cancelled",
        "packed",
        "out_for_delivery",
        "refunded",
        "returned",
      ],
      product_status: ["draft", "pending_review", "approved", "declined"],
      sold_by_type: ["welcome_wagon", "vendor"],
      vendor_status: ["pending", "active", "suspended", "terminated"],
    },
  },
} as const;
