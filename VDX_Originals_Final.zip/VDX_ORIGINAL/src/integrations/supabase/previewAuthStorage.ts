/**
 * Supabase auth storage for Netlify deployment.
 * Uses localStorage for session persistence.
 * Lovable preview-specific logic has been removed.
 */

export function brokeredPreviewStorage() {
  if (typeof window === "undefined") return undefined;

  // Simply use localStorage for all environments
  // This works seamlessly on Netlify and other deployments
  return localStorage;
}
