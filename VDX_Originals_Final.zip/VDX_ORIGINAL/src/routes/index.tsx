import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ChevronRight, Package, Search, ShoppingBag, Sparkles } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoredImage } from "@/components/stored-image";
import { useCart } from "@/lib/cart-context";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VDX ORIGINALS — Contemporary Fashion" },
      { name: "description", content: "Distinctive Contemporary Luxury Fashion" },
      { property: "og:title", content: "VDX ORIGINALS" },
      { property: "og:description", content: "Distinctive Contemporary Luxury Fashion" },
    ],
  }),
  component: Index,
});

function Index() {
  const cart = useCart();
  const { data: categories } = useQuery({
    queryKey: ["home-categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("id, name, slug, image_url, display_order")
        .order("display_order")
        .limit(6);
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: featured } = useQuery({
    queryKey: ["home-featured-products"],
    queryFn: async () => {
      const base = "id, title, slug, price_ngn, discount_price_ngn, primary_image_url, stock, reserved_stock, low_stock_threshold, sold_by_type, vendor_id, is_featured, created_at";
      const { data, error } = await supabase
        .from("products")
        .select(base)
        .eq("status", "approved")
        .order("is_featured", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(8);
      if (error) throw error;
      return data ?? [];
    },
  });

  const categoryLinks = [
    { label: "Women", slug: "women" },
    { label: "Men", slug: "men" },
    { label: "Shirts", slug: "shirts" },
    { label: "Trousers", slug: "trousers" },
    { label: "Dresses", slug: "dresses" },
  ];

  return (
    <PageShell>
      <section className="group relative min-h-[100svh] w-full overflow-hidden bg-black text-white md:min-h-screen">
        <video
          className="absolute inset-0 h-full w-full object-cover scale-[1.02] opacity-95 transition-transform duration-[2200ms] ease-out group-hover:scale-[1.055]"
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          aria-hidden="true"
        >
          <source src="/hero-fashion.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-black/25" />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,transparent_0%,rgba(0,0,0,0.18)_55%,rgba(0,0,0,0.62)_100%)]" />

        <div className="relative z-10 flex min-h-[100svh] w-full items-end px-5 pb-14 pt-28 sm:px-8 sm:pb-16 md:items-center md:pb-20 lg:px-12">
          <div className="w-full max-w-5xl">
            <div className="mb-5 flex flex-wrap items-baseline gap-x-5 gap-y-1 sm:mb-7 sm:gap-x-7">
              <span className="font-sans text-[clamp(5rem,13vw,10.5rem)] font-extrabold leading-[0.72] tracking-[-0.085em]">VDX</span>
              <span className="font-display text-[clamp(1.2rem,3vw,2.35rem)] font-semibold uppercase leading-none tracking-[0.28em]">ORIGINALS</span>
            </div>
            <p className="mb-4 text-[9px] font-semibold uppercase tracking-[0.32em] text-white/75 sm:mb-5 sm:text-xs">Distinctive Contemporary Luxury Fashion</p>
            <h1 className="max-w-3xl text-[clamp(2.25rem,5.2vw,4.8rem)] font-bold leading-[0.94] tracking-[-0.045em]">
              Wear what feels <span className="font-display font-normal italic">original.</span>
            </h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-white/75 sm:text-lg sm:leading-8">
              A refined collection of contemporary pieces made for confident, effortless style.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/shop">
                <Button size="lg" className="rounded-full bg-white px-7 text-black shadow-2xl shadow-black/30 hover:bg-white/90">
                  Explore collection <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link to="/auth">
                <Button size="lg" variant="outline" className="rounded-full border-white/45 bg-white/5 px-7 text-white backdrop-blur-md hover:bg-white/15 hover:text-white">
                  Sign in
                </Button>
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-5 left-1/2 z-10 hidden -translate-x-1/2 items-center gap-3 text-[9px] uppercase tracking-[0.35em] text-white/60 md:flex">
          <span className="h-px w-12 bg-white/40" /> Scroll to explore <span className="h-px w-12 bg-white/40" />
        </div>
      </section>

      <section className="w-full px-4 py-16 sm:px-6 lg:px-12">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Browse</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">Shop by collection</h2>
          </div>
          <Link to="/categories" className="hidden items-center gap-1 text-sm font-medium md:flex">View all <ChevronRight className="h-4 w-4" /></Link>
        </div>
        <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
          {categoryLinks.map((c) => (
            <Link key={c.slug} to="/shop" search={{ category: c.slug } as never} className="group rounded-2xl border border-border bg-card p-5 transition hover:-translate-y-1 hover:border-foreground/30">
              <div className="flex items-center justify-between">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-secondary"><Package className="h-5 w-5" /></div>
                <ArrowRight className="h-4 w-4 opacity-30 transition group-hover:translate-x-1 group-hover:opacity-100" />
              </div>
              <p className="mt-7 font-semibold">{c.label}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="w-full px-4 pb-20 sm:px-6 lg:px-12">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Selected pieces</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">The latest edit</h2>
          </div>
          <Link to="/shop" className="flex items-center gap-1 text-sm font-medium">Shop all <ChevronRight className="h-4 w-4" /></Link>
        </div>
        {!featured || featured.length === 0 ? (
          <div className="mt-7 rounded-2xl border border-dashed border-border p-12 text-center text-sm text-muted-foreground">Your first collection will appear here once products are published.</div>
        ) : (
          <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {featured.map((p) => {
              const available = Math.max(0, (p.stock ?? 0) - (p.reserved_stock ?? 0));
              const price = p.discount_price_ngn ?? p.price_ngn;
              return (
                <div key={p.id} className="group overflow-hidden rounded-2xl border border-border bg-card">
                  <Link to="/product/$slug" params={{ slug: p.slug }} className="block">
                    <div className="relative aspect-[4/5] overflow-hidden bg-secondary">
                      <StoredImage bucket="product-media" path={p.primary_image_url} alt={p.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
                      {available === 0 && <span className="absolute left-3 top-3 rounded-full bg-background/90 px-2.5 py-1 text-[10px] font-semibold uppercase">Sold out</span>}
                    </div>
                    <div className="p-4">
                      <h3 className="line-clamp-2 text-sm font-semibold">{p.title}</h3>
                      <p className="mt-2 text-base font-bold">₦{Number(price).toLocaleString("en-NG")}</p>
                    </div>
                  </Link>
                  <div className="px-4 pb-4">
                    <Button size="sm" className="w-full rounded-full" disabled={available === 0} onClick={() => {
                      cart.add({ product_id: p.id, title: p.title, slug: p.slug, price_ngn: Number(price), quantity: 1, image: p.primary_image_url, vendor_id: null, vendor_name: "VDX ORIGINALS", sold_by_type: "welcome_wagon" as "vendor" | "welcome_wagon", stock: available });
                      toast.success(`Added ${p.title} to cart`);
                    }}>
                      <ShoppingBag className="mr-1 h-3.5 w-3.5" /> Add to bag
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="border-y border-border bg-secondary/40">
        <div className="grid w-full gap-8 px-4 py-16 sm:px-6 lg:px-12 md:grid-cols-3">
          {[
            ["01", "Curated pieces", "A focused collection without the noise of a marketplace."],
            ["02", "Simple ordering", "Choose your size, place your order, and follow its progress."],
            ["03", "Direct support", "Reach VDX Originals quickly by WhatsApp, phone, or email."],
          ].map(([n, title, desc]) => (
            <div key={n}>
              <span className="text-xs tracking-[0.25em] text-muted-foreground">{n}</span>
              <h3 className="mt-3 text-lg font-bold">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
