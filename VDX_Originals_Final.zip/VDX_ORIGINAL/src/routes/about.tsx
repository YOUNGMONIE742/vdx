import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Heart, ShieldCheck, Sparkles } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — VDX Originals" },
      { name: "description", content: "VDX Originals is a contemporary clothing and everyday fashion." },
      { property: "og:title", content: "About VDX Originals" },
      { property: "og:description", content: "A curated Nigerian clothing store for families." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <span className="chip"><Sparkles className="h-3 w-3" /> Our story</span>
        <h1 className="mt-4 font-display text-4xl font-bold md:text-5xl">Made to feel original.</h1>
        <p className="mt-5 text-base text-muted-foreground md:text-lg">
          VDX Originals is a focused fashion store built around considered pieces, clean presentation, and a simple shopping experience.
        </p>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          <div className="soft-card p-5">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-display text-lg font-semibold">Curated collection</h3>
            <p className="mt-1 text-sm text-muted-foreground">Products are reviewed before they are published.</p>
          </div>
          <div className="soft-card p-5">
            <Heart className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-display text-lg font-semibold">Easy shopping</h3>
            <p className="mt-1 text-sm text-muted-foreground">Clear collections make it easy to find your next piece.</p>
          </div>
          <div className="soft-card p-5">
            <Sparkles className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-display text-lg font-semibold">Simple payment</h3>
            <p className="mt-1 text-sm text-muted-foreground">Pay securely by manual bank transfer and upload your proof at checkout.</p>
          </div>
        </div>
      </section>
    </PageShell>
  );
}