import { createFileRoute } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useState } from "react";
import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/support")({
  head: () => ({ meta: [{ title: "Support & FAQs — VDX Originals" }] }),
  component: Support,
});

const FAQS = [
  { q: "How do I place an order?", a: "Choose a product, select your size and quantity, add it to your bag, then continue to checkout." },
  { q: "How do I pay?", a: "VDX Originals currently accepts manual bank transfer. Your bank details are shown after checkout." },
  { q: "How do I submit payment proof?", a: "Open your order, upload the transfer proof and enter the payment/reference number." },
  { q: "How can I track my order?", a: "Open My Orders from your account to see the latest order and delivery status." },
  { q: "Refunds & returns", a: "Contact VDX Originals within 48 hours of delivery with your order number and we will guide you through the return process." },
];

function Support() {
  const { user, profile } = useAuth();
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return toast.error("Please sign in to contact support.");
    if (message.trim().length < 10) return toast.error("Please describe your issue in at least 10 characters.");
    setBusy(true);
    const combined = [
      subject.trim() ? `Subject: ${subject.trim()}` : "",
      orderNumber.trim() ? `Order number: ${orderNumber.trim()}` : "",
      `Message: ${message.trim()}`,
    ].filter(Boolean).join("\n\n");
    const { error } = await supabase.from("feedback").insert({
      user_id: user.id,
      name: profile?.full_name || profile?.username || user.email?.split("@")[0] || "Customer",
      email: user.email || "",
      message: combined,
      source: "support",
    });
    setBusy(false);
    if (error) return toast.error("Could not send your support request", { description: error.message });
    setSubject("");
    setOrderNumber("");
    setMessage("");
    toast.success("Support request sent. We will get back to you shortly.");
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-5xl px-4 py-14 sm:px-6">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">VDX Originals support</p>
        <h1 className="mt-2 font-display text-4xl font-bold md:text-5xl">How can we help?</h1>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">Find quick answers below or send a support request directly from your customer account.</p>

        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_0.9fr]">
          <div className="space-y-3">
            {FAQS.map((item) => (
              <details key={item.q} className="soft-card group p-5">
                <summary className="cursor-pointer list-none font-semibold">{item.q}</summary>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">{item.a}</p>
              </details>
            ))}
          </div>

          <form onSubmit={submit} className="soft-card h-fit space-y-4 p-6">
            <div>
              <h2 className="font-display text-xl font-semibold">Send a support request</h2>
              <p className="mt-1 text-xs text-muted-foreground">For complaints, order problems, sizing questions, delivery issues, or other help.</p>
            </div>
            {!user && <p className="rounded-xl bg-secondary p-3 text-sm">Please sign in before sending a support request.</p>}
            <label className="block"><span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Subject</span><input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="e.g. Complaint about my order" className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" /></label>
            <label className="block"><span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Order number (optional)</span><input value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" /></label>
            <label className="block"><span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Message</span><textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={6} required placeholder="Describe what happened and how we can help." className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary" /></label>
            <Button type="submit" disabled={busy || !user} className="w-full rounded-full">{busy ? "Sending…" : "Send request"}</Button>
          </form>
        </div>
      </section>
    </PageShell>
  );
}
