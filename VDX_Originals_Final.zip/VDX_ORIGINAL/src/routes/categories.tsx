import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageShell } from "@/components/page-shell";
import { Package } from "lucide-react";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Categories — VDX Originals" },
      { name: "description", content: "Browse the VDX Originals fashion collections." },
      { property: "og:title", content: "Categories" },
      { property: "og:description", content: "Explore VDX Originals contemporary fashion collections." },
    ],
  }),
  component: Categories,
});

function Categories() {
  const { data } = useQuery({
    queryKey: ["all-categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("*").order("display_order");
      if (error) throw error;
      return data ?? [];
    },
  });
  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Categories</h1>
        <p className="text-sm text-muted-foreground">Explore contemporary fashion by collection.</p>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {(data ?? []).map((c) => (
            <Link key={c.id} to="/shop" search={{ category: c.slug } as never} className="soft-card group p-5 transition hover:-translate-y-0.5">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-primary">
                <Package className="h-6 w-6" />
              </div>
              <h3 className="mt-3 font-display text-lg font-semibold">{c.name}</h3>
              {c.description && <p className="mt-1 text-xs text-muted-foreground">{c.description}</p>}
            </Link>
          ))}
        </div>
      </section>
    </PageShell>
  );
}