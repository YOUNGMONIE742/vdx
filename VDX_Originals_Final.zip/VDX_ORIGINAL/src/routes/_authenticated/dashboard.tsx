import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth, type AppRole } from "@/lib/auth-context";
import { PageShell } from "@/components/page-shell";
import { LoadingScreen } from "@/components/loading-screen";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Bell, LogOut, ChevronRight, Package, Users, BarChart3, Settings, ShieldCheck, CreditCard, Truck, MessageSquare, Tags } from "lucide-react";
import { useEffect } from "react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — VDX Originals" }] }),
  component: DashboardRouter,
});

function DashboardRouter() {
  const { loading, primaryRole, profile, user, signOut, roles, isSuperAdminEmail, refresh } = useAuth();
  useEffect(() => { void refresh(); }, [user?.id]);
  if (loading) return <PageShell><LoadingScreen /></PageShell>;
  const role: AppRole = isSuperAdminEmail ? "super_admin" : (primaryRole ?? "customer");

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{labelFor(role)} dashboard</p>
            <h1 className="mt-2 text-3xl font-bold md:text-4xl">Hello, {profile?.full_name ?? profile?.username ?? user?.email}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{user?.email}{roles.length > 1 && <> · {roles.join(", ")}</>}</p>
          </div>
          <Button variant="outline" onClick={signOut} className="rounded-full"><LogOut className="mr-1 h-4 w-4" /> Sign out</Button>
        </div>
        <div className="mt-8">
          {role === "super_admin" ? <SuperAdminPanel /> : role === "admin" ? <AdminPanel /> : <CustomerPanel />}
        </div>
      </section>
    </PageShell>
  );
}

function labelFor(role: AppRole) {
  return ({ customer: "Customer", vendor: "Customer", admin: "Admin", super_admin: "Super Admin" } as const)[role];
}

function Tile({ icon: Icon, title, desc, to }: { icon: typeof Package; title: string; desc: string; to: string }) {
  return <Link to={to} className="group rounded-2xl border border-border bg-card p-5 transition hover:-translate-y-1 hover:border-foreground/30">
    <div className="flex items-start gap-3"><div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-secondary"><Icon className="h-5 w-5" /></div><div className="min-w-0 flex-1"><h3 className="font-semibold">{title}</h3><p className="mt-1 text-xs leading-5 text-muted-foreground">{desc}</p></div><ChevronRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-1" /></div>
  </Link>;
}

function CustomerPanel() {
  return <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
    <Tile icon={ShoppingBag} title="My orders" desc="View your orders and delivery status." to="/orders" />
    <Tile icon={Package} title="Shop" desc="Continue browsing the VDX Originals collection." to="/shop" />
    <Tile icon={Bell} title="Notifications" desc="View important store updates." to="/notifications" />
    <Tile icon={Settings} title="Account settings" desc="Update your profile details." to="/settings" />
    <Tile icon={MessageSquare} title="Support" desc="Get help with an order or question." to="/support" />
    <Tile icon={ShieldCheck} title="Apply to become an Admin" desc="Send a request for Super Admin review." to="/become-admin" />
  </div>;
}

function AdminPanel() {
  return <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
    <Tile icon={Truck} title="Orders" desc="Review orders and update delivery status." to="/admin/orders" />
    <Tile icon={Package} title="Products" desc="Manage and moderate the product catalog." to="/admin/products" />
    <Tile icon={CreditCard} title="Payments" desc="Review customer payment proofs." to="/admin/payments" />
    <Tile icon={MessageSquare} title="Messages" desc="Read customer feedback and inquiries." to="/admin/feedback" />
    <Tile icon={Settings} title="Account settings" desc="Update your own profile." to="/settings" />
  </div>;
}

function SuperAdminPanel() {
  return <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
    <Tile icon={Truck} title="Orders" desc="Manage orders, fulfillment and delivery status." to="/admin/orders" />
    <Tile icon={Package} title="Products" desc="Create, edit and manage the catalog." to="/admin/products" />
    <Tile icon={CreditCard} title="Payments" desc="Verify transfer proofs and payment references." to="/admin/payments" />
    <Tile icon={CreditCard} title="Store wallet" desc="View verified payments and store cash flow." to="/admin/wallets" />
    <Tile icon={Tags} title="Categories" desc="Manage Men, Women and other collections." to="/admin/categories" />
    <Tile icon={Users} title="Users & roles" desc="Manage customers and grant Admin access." to="/admin/users" />
    <Tile icon={ShieldCheck} title="Admin requests" desc="Review requests for Admin access." to="/admin/admin-applications" />
    <Tile icon={BarChart3} title="Analytics" desc="Monitor sales, orders, customers and products." to="/admin/analytics" />
    <Tile icon={Settings} title="Store settings" desc="Manage bank details, logo and protected settings." to="/admin/settings" />
    <Tile icon={Bell} title="Announcements" desc="Send updates to customers and admins." to="/admin/announcements" />
    <Tile icon={MessageSquare} title="Messages" desc="Read customer inquiries and feedback." to="/admin/feedback" />
  </div>;
}

