import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/admin/vendor-applications")({
  beforeLoad: () => { throw redirect({ to: "/admin/orders" }); },
  component: () => null,
});
