import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";
import { slugify } from "@/lib/format";
import { Trash2, Pencil, Check, X } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/categories")({
  component: CategoriesAdmin,
});

function CategoriesAdmin() {
  const qc = useQueryClient();
  const { data: cats } = useQuery({
    queryKey: ["admin-categories"],
    queryFn: async () => {
      const { data } = await supabase
        .from("categories")
        .select("*")
        .order("display_order")
        .order("name");
      return data ?? [];
    },
  });

  const [name, setName] = useState("");
  const [order, setOrder] = useState("0");
  const [editing, setEditing] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editOrder, setEditOrder] = useState("0");

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    const slug = slugify(name);
    const { error } = await supabase
      .from("categories")
      .insert({ name: name.trim(), slug, display_order: Number(order) || 0 });
    if (error) return toast.error(error.message);
    setName("");
    setOrder("0");
    toast.success("Category added");
    qc.invalidateQueries({ queryKey: ["admin-categories"] });
    qc.invalidateQueries({ queryKey: ["all-categories"] });
    qc.invalidateQueries({ queryKey: ["categories"] });
  }

  async function saveEdit(id: string) {
    const { error } = await supabase
      .from("categories")
      .update({
        name: editName.trim(),
        slug: slugify(editName),
        display_order: Number(editOrder) || 0,
      })
      .eq("id", id);
    if (error) return toast.error(error.message);
    setEditing(null);
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: ["admin-categories"] });
    qc.invalidateQueries({ queryKey: ["all-categories"] });
    qc.invalidateQueries({ queryKey: ["categories"] });
  }

  async function remove(id: string) {
    if (!confirm("Delete this category?")) return;
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: ["admin-categories"] });
    qc.invalidateQueries({ queryKey: ["all-categories"] });
  }

  return (
    <div className="space-y-6">
      <div className="soft-card p-5">
        <h2 className="font-display text-lg font-semibold">Add a new category</h2>
        <p className="mt-1 text-xs text-muted-foreground">
          Give it a name and a display order (lower shows first).
        </p>
        <form onSubmit={add} className="mt-3 grid gap-3 sm:grid-cols-[1fr_120px_auto]">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Baby Nursery"
            className="h-11 rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
          />
          <input
            value={order}
            onChange={(e) => setOrder(e.target.value)}
            type="number"
            placeholder="Order"
            className="h-11 rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
          />
          <Button type="submit" className="rounded-full" disabled={!name.trim()}>
            + Add category
          </Button>
        </form>
      </div>

      {!cats || cats.length === 0 ? (
        <p className="soft-card p-8 text-center text-sm text-muted-foreground">
          No categories yet.
        </p>
      ) : (
        <ul className="space-y-2">
          {cats.map((c) => (
            <li key={c.id} className="soft-card flex items-center gap-3 p-3">
              {editing === c.id ? (
                <>
                  <input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="h-10 flex-1 rounded-lg border border-border bg-card px-3 text-sm outline-none focus:border-primary"
                  />
                  <input
                    value={editOrder}
                    onChange={(e) => setEditOrder(e.target.value)}
                    type="number"
                    className="h-10 w-20 rounded-lg border border-border bg-card px-3 text-sm outline-none focus:border-primary"
                  />
                  <Button size="sm" className="rounded-full" onClick={() => saveEdit(c.id)}>
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-full"
                    onClick={() => setEditing(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </>
              ) : (
                <>
                  <div className="flex-1">
                    <p className="text-sm font-semibold">{c.name}</p>
                    <p className="text-xs text-muted-foreground">
                      /{c.slug} · order {c.display_order ?? 0}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-full"
                    onClick={() => {
                      setEditing(c.id);
                      setEditName(c.name);
                      setEditOrder(String(c.display_order ?? 0));
                    }}
                  >
                    <Pencil className="mr-1 h-4 w-4" /> Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-full text-destructive"
                    onClick={() => remove(c.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
