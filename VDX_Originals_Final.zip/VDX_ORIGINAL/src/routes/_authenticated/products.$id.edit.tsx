import { createFileRoute, Link, useNavigate, useParams } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { FileUpload } from "@/components/file-upload";
import { ArrowLeft, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/products/$id/edit")({
  head: () => ({ meta: [{ title: "Edit product — VDX Originals" }] }),
  component: EditProduct,
});

const fieldCls = "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary";
const labelCls = "mb-1 block text-xs font-semibold uppercase text-muted-foreground";

function EditProduct() {
  const { id } = useParams({ from: "/_authenticated/products/$id/edit" });
  const { user, primaryRole } = useAuth();
  const navigate = useNavigate();
  const isStaff = primaryRole === "admin" || primaryRole === "super_admin";
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [discountPrice, setDiscountPrice] = useState("");
  const [stock, setStock] = useState("0");
  const [categoryId, setCategoryId] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [image2, setImage2] = useState<string | null>(null);
  const [image3, setImage3] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [deliveryTime, setDeliveryTime] = useState("");
  const [returnPolicy, setReturnPolicy] = useState("");
  const [isFeatured, setIsFeatured] = useState(false);
  const [busy, setBusy] = useState(false);

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data } = await supabase.from("categories").select("id, name").order("display_order");
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!product) return;
    setTitle(product.title ?? "");
    setDescription(product.description ?? "");
    setPrice(String(product.price_ngn ?? ""));
    setDiscountPrice(product.discount_price_ngn == null ? "" : String(product.discount_price_ngn));
    setStock(String(product.stock ?? 0));
    setCategoryId(product.category_id ?? "");
    setImage(product.primary_image_url ?? null);
    setVideoUrl(product.video_url ?? null);
    setDeliveryTime((product as { delivery_time?: string | null }).delivery_time ?? "");
    setReturnPolicy((product as { return_policy?: string | null }).return_policy ?? "");
    setIsFeatured(Boolean((product as { is_featured?: boolean }).is_featured));
    const imgs = ((product as { images?: string[] | null }).images ?? []).filter(Boolean);
    setImage2(imgs[1] ?? null);
    setImage3(imgs[2] ?? null);
  }, [product]);

  if (isLoading) return <PageShell><div className="p-10 text-center text-sm text-muted-foreground">Loading…</div></PageShell>;
  if (!product) return <PageShell><div className="p-10 text-center">Product not found.</div></PageShell>;
  // Product management is Admin/Super Admin only in VDX Originals (single store,
  // not a vendor marketplace), matching the products RLS policies.
  if (!isStaff) return <PageShell><div className="p-10 text-center">Only Admins and Super Admins can edit products.</div></PageShell>;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return toast.error("Product title is required.");
    if (Number(price) < 0 || Number(stock) < 0) return toast.error("Price and stock cannot be negative.");
    if (discountPrice && Number(discountPrice) < 0) return toast.error("Discount price cannot be negative.");
    setBusy(true);
    const gallery = [image, image2, image3].filter(Boolean) as string[];
    const { error } = await supabase.from("products").update({
      title: title.trim(),
      description: description.trim() || null,
      price_ngn: Number(price),
      discount_price_ngn: discountPrice ? Number(discountPrice) : null,
      stock: Number(stock),
      category_id: categoryId || null,
      primary_image_url: image,
      images: gallery,
      video_url: videoUrl,
      delivery_time: deliveryTime.trim() || null,
      return_policy: returnPolicy.trim() || null,
      is_featured: isFeatured,
      vendor_id: null,
      sold_by: "VDX Originals",
      sold_by_type: "welcome_wagon",
      status: isStaff ? product.status : (product.status === "approved" ? "pending_review" : product.status),
    }).eq("id", id);
    setBusy(false);
    if (error) return toast.error("Could not save product", { description: error.message });
    toast.success("Product saved successfully");
    navigate({ to: "/admin/products" });
  }

  async function remove() {
    if (!confirm("Delete this product? This cannot be undone.")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Product deleted");
    navigate({ to: "/admin/products" });
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <Link to="/admin/products" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Products</Link>
        <div className="mt-4 flex items-center justify-between gap-3">
          <div><p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">VDX Originals catalog</p><h1 className="mt-1 font-display text-3xl font-bold">Edit product</h1></div>
          <Button type="button" variant="outline" className="rounded-full text-destructive" onClick={remove}><Trash2 className="mr-1 h-4 w-4" /> Delete</Button>
        </div>
        <form onSubmit={save} className="soft-card mt-6 space-y-5 p-6">
          <div className="grid gap-3 sm:grid-cols-2">
            <label><span className={labelCls}>Product name *</span><input value={title} required onChange={(e) => setTitle(e.target.value)} className={fieldCls} /></label>
            <label><span className={labelCls}>Category</span><select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className={fieldCls}><option value="">—</option>{(categories ?? []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          </div>
          <label><span className={labelCls}>Description</span><textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={5} className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary" /></label>
          <div className="grid gap-3 sm:grid-cols-3">
            <label><span className={labelCls}>Price (NGN) *</span><input value={price} type="number" min="0" required onChange={(e) => setPrice(e.target.value)} className={fieldCls} /></label>
            <label><span className={labelCls}>Discount price</span><input value={discountPrice} type="number" min="0" onChange={(e) => setDiscountPrice(e.target.value)} className={fieldCls} /></label>
            <label><span className={labelCls}>Stock *</span><input value={stock} type="number" min="0" required onChange={(e) => setStock(e.target.value)} className={fieldCls} /></label>
          </div>
          <div><span className={labelCls}>Product images</span><div className="grid gap-3 sm:grid-cols-3"><FileUpload bucket="product-media" prefix={user?.id ?? "admin"} value={image} onChange={setImage} label="Primary" /><FileUpload bucket="product-media" prefix={user?.id ?? "admin"} value={image2} onChange={setImage2} label="Image 2" /><FileUpload bucket="product-media" prefix={user?.id ?? "admin"} value={image3} onChange={setImage3} label="Image 3" /></div></div>
          <div><span className={labelCls}>Product video</span><FileUpload bucket="product-media" prefix={user?.id ?? "admin"} value={videoUrl} onChange={setVideoUrl} label="Upload video" accept="video/*" maxMB={50} /></div>
          <div className="grid gap-3 sm:grid-cols-2">
            <label><span className={labelCls}>Delivery time</span><input value={deliveryTime} onChange={(e) => setDeliveryTime(e.target.value)} placeholder="e.g. 2–5 business days" className={fieldCls} /></label>
            <label><span className={labelCls}>Return policy</span><input value={returnPolicy} onChange={(e) => setReturnPolicy(e.target.value)} placeholder="e.g. 7-day returns" className={fieldCls} /></label>
          </div>
          <label className="inline-flex items-center gap-2 text-sm"><input type="checkbox" checked={isFeatured} onChange={(e) => setIsFeatured(e.target.checked)} /> Featured product</label>
          <div className="rounded-xl bg-secondary/50 p-3 text-xs text-muted-foreground">Sold by <strong className="text-foreground">VDX Originals</strong>. Vendor selection is not used.</div>
          <Button type="submit" className="rounded-full" disabled={busy}>{busy ? "Saving…" : "Save changes"}</Button>
        </form>
      </section>
    </PageShell>
  );
}
