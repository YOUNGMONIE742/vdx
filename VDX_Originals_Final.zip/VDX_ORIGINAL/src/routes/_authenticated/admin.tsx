import { createFileRoute, Link, Outlet, useLocation } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { useAuth } from "@/lib/auth-context";
import { AccessDenied } from "@/components/access-denied";
import { LoadingScreen } from "@/components/loading-screen";
import { ShieldCheck, Package, CreditCard, ArrowLeft, Bell, BarChart3, Users, Tag, MessageSquare, Truck, Settings, Wallet } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — VDX Originals" }] }),
  component: AdminLayout,
});

const TABS = [
  { to: "/admin/orders", label: "Orders", icon: Truck, superOnly: false },
  { to: "/admin/products", label: "Products", icon: Package, superOnly: false },
  { to: "/admin/payments", label: "Payments", icon: CreditCard, superOnly: false },
  { to: "/admin/wallets", label: "Wallet", icon: Wallet, superOnly: false },
  { to: "/admin/feedback", label: "Messages", icon: MessageSquare, superOnly: false },
  { to: "/admin/admin-applications", label: "Admin requests", icon: ShieldCheck, superOnly: true },
  { to: "/admin/categories", label: "Categories", icon: Tag, superOnly: true },
  { to: "/admin/users", label: "Users & roles", icon: Users, superOnly: true },
  { to: "/admin/settings", label: "Store settings", icon: Settings, superOnly: true },
  { to: "/admin/announcements", label: "Announcements", icon: Bell, superOnly: true },
  { to: "/admin/analytics", label: "Analytics", icon: BarChart3, superOnly: true },
] as const;

function AdminLayout() {
  const { loading, primaryRole, isSuperAdminEmail, roles } = useAuth();
  const location = useLocation();
  if (loading) return <PageShell><LoadingScreen /></PageShell>;
  const isSuper = primaryRole === "super_admin" && isSuperAdminEmail;
  const isAdmin = roles.includes("admin");
  if (!isSuper && !isAdmin) return <PageShell><AccessDenied /></PageShell>;
  const visibleTabs = TABS.filter((t) => isSuper || !t.superOnly);

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Dashboard</Link>
        <h1 className="mt-3 text-3xl font-bold tracking-tight">{isSuper ? "Super Admin" : "Admin"} console</h1>
        <p className="mt-1 text-sm text-muted-foreground">Manage VDX Originals products, customers, orders and store content.</p>
        <nav className="mt-5 flex gap-2 overflow-x-auto border-b border-border pb-3">
          {visibleTabs.map((t) => {
            const active = location.pathname.startsWith(t.to);
            return <Link key={t.to} to={t.to} className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium transition ${active ? "bg-foreground text-background" : "bg-secondary text-foreground hover:bg-secondary/70"}`}><t.icon className="h-3.5 w-3.5" /> {t.label}</Link>;
          })}
        </nav>
        <div className="mt-6"><Outlet /></div>
      </section>
    </PageShell>
  );
}
