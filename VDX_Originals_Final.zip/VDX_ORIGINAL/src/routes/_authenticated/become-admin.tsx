import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, ShieldCheck, XCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/become-admin")({
  head: () => ({ meta: [{ title: "Apply for admin — VDX Originals" }] }),
  component: BecomeAdmin,
});

function BecomeAdmin() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const { data: app } = useQuery({
    queryKey: ["my-admin-app", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("admin_applications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
  });
  const { data: settings } = useQuery({
    queryKey: ["public-settings-admin"],
    queryFn: async () => {
      const { data } = await supabase.from("settings").select("key, value").eq("key", "admin_applications_enabled").maybeSingle();
      return data?.value !== false;
    },
  });
  const enabled = settings !== false;

  async function cancelApplication() {
    if (!app?.id) return;
    if (!confirm("Cancel your admin application?")) return;
    const { error } = await supabase.from("admin_applications").delete().eq("id", app.id);
    if (error) return toast.error(error.message);
    toast.success("Admin application cancelled.");
    qc.invalidateQueries({ queryKey: ["my-admin-app"] });
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (reason.trim().length < 30) return toast.error("Please write at least 30 characters.");
    setBusy(true);
    const { error } = await supabase.from("admin_applications").insert({ user_id: user.id, reason });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Application submitted.");
    qc.invalidateQueries({ queryKey: ["my-admin-app"] });
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-2xl px-4 py-12 sm:px-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Back to dashboard</Link>
        <h1 className="mt-4 font-display text-3xl font-bold md:text-4xl">Apply to become an admin</h1>
        <p className="mt-2 text-sm text-muted-foreground">Admins help moderate products and applications. No payment required.</p>

        {!enabled && (
          <div className="soft-card mt-6 border-destructive/30 bg-destructive/5 p-5 text-sm text-destructive">
            Admin applications are currently closed by the super admin.
          </div>
        )}

        {app && app.status !== "declined" ? (
          <div className="soft-card mt-8 p-6">
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-6 w-6 text-primary" />
              <h2 className="font-display text-xl font-semibold">Your application</h2>
            </div>
            <p className="mt-3 text-sm"><span className="text-muted-foreground">Status:</span> <span className="font-semibold capitalize text-primary">{app.status}</span></p>
            <p className="mt-1 text-xs text-muted-foreground">Submitted {new Date(app.created_at).toLocaleString()}</p>
            {app.status === "pending" && (
              <Button type="button" variant="outline" className="mt-4 rounded-full text-destructive" onClick={cancelApplication}>
                <XCircle className="mr-2 h-4 w-4" /> Cancel application
              </Button>
            )}
          </div>
        ) : enabled ? (
          <form onSubmit={submit} className="soft-card mt-8 space-y-4 p-6">
            {app?.status === "declined" && (
              <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
                Previous application declined: {app.decline_reason ?? "No reason provided"}. You can resubmit.
              </div>
            )}
            <label className="block">
              <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Why do you want to be an admin? *</span>
              <textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={6} required minLength={30} placeholder="Tell us about your experience moderating communities, online stores, etc." className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary" />
            </label>
            <Button type="submit" disabled={busy} className="rounded-full">{busy ? "Submitting…" : "Submit application"}</Button>
          </form>
        ) : null}
      </section>
    </PageShell>
  );
}