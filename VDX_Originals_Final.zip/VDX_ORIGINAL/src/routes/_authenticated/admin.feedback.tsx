import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Trash2, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/feedback")({
  component: FeedbackAdmin,
});

function FeedbackAdmin() {
  const qc = useQueryClient();
  const { data: items } = useQuery({
    queryKey: ["admin-feedback"],
    queryFn: async () => {
      const { data } = await supabase
        .from("feedback")
        .select("*")
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function markRead(id: string) {
    const { error } = await supabase.from("feedback").update({ status: "read" }).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin-feedback"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this message?")) return;
    const { error } = await supabase.from("feedback").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin-feedback"] });
  }

  if (!items || items.length === 0)
    return (
      <p className="soft-card p-8 text-center text-sm text-muted-foreground">No feedback yet.</p>
    );

  return (
    <ul className="space-y-3">
      {items.map((f) => (
        <li key={f.id} className="soft-card p-4">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <p className="text-sm font-semibold">
                {f.name}{" "}
                <span className="text-xs font-normal text-muted-foreground">· {f.email}</span>
              </p>
              <p className="text-xs text-muted-foreground">
                {new Date(f.created_at).toLocaleString()} · {f.source} ·{" "}
                <span className="capitalize">{f.status}</span>
              </p>
            </div>
            <div className="flex gap-2">
              {f.status !== "read" && (
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-full"
                  onClick={() => markRead(f.id)}
                >
                  <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Mark read
                </Button>
              )}
              <Button
                size="sm"
                variant="outline"
                className="rounded-full text-destructive"
                onClick={() => remove(f.id)}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
          <p className="mt-3 whitespace-pre-wrap text-sm">{f.message}</p>
        </li>
      ))}
    </ul>
  );
}
