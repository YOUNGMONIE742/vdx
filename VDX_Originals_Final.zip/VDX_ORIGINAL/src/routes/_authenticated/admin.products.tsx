import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Pencil } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { StoredImage } from "@/components/stored-image";
import { ngn, statusBadge } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/products")({
  component: ProductsAdmin,
});

function ProductsAdmin() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"pending_review" | "approved" | "declined" | "draft">(
    "approved",
  );
  const { data: items } = useQuery({
    queryKey: ["admin-products", filter],
    queryFn: async () => {
      const { data } = await supabase
        .from("products")
        .select(
          "id, title, price_ngn, stock, status, primary_image_url, decline_reason",
        )
        .eq("status", filter)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function setStatus(id: string, status: "approved" | "declined") {
    let decline_reason: string | null = null;
    if (status === "declined") {
      decline_reason = prompt("Reason for decline?") ?? "";
      if (!decline_reason) return;
    }
    const { error } = await supabase
      .from("products")
      .update({ status, decline_reason })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(status);
    qc.invalidateQueries({ queryKey: ["admin-products"] });
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {(["pending_review", "approved", "declined", "draft"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-3 py-1 text-xs font-semibold ${filter === f ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
          >
            {f.replace("_", " ")}
          </button>
          ))}
        </div>
        <Link to="/products/new"><Button className="rounded-full"><Plus className="mr-1 h-4 w-4" /> Add product</Button></Link>
      </div>
      {!items || items.length === 0 ? (
        <p className="soft-card p-8 text-center text-sm text-muted-foreground">
          No products in {filter}.
        </p>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2">
          {items.map((p) => {
            const vname = "VDX Originals";
            return (
              <li key={p.id} className="soft-card flex gap-3 p-3">
                <div className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-secondary">
                  <StoredImage
                    bucket="product-media"
                    path={p.primary_image_url}
                    alt={p.title}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="flex flex-1 flex-col">
                  <h3 className="line-clamp-2 text-sm font-semibold">{p.title}</h3>
                  <p className="text-xs text-muted-foreground">
                    {vname} · stock {p.stock}
                  </p>
                  <p className="mt-1 font-bold text-primary">{ngn(p.price_ngn)}</p>
                  <div className="mt-auto flex flex-wrap items-center gap-2">
                    <Link to="/products/$id/edit" params={{ id: p.id }}><Button size="sm" variant="outline" className="rounded-full"><Pencil className="mr-1 h-3.5 w-3.5" /> Edit</Button></Link>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${statusBadge(p.status).tone}`}
                    >
                      {statusBadge(p.status).label}
                    </span>
                    {(p.status === "pending_review" || p.status === "draft") && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          className="ml-auto rounded-full"
                          onClick={() => setStatus(p.id, "declined")}
                        >
                          Decline
                        </Button>
                        <Button
                          size="sm"
                          className="rounded-full"
                          onClick={() => setStatus(p.id, "approved")}
                        >
                          Approve
                        </Button>
                      </>
                    )}
                    {p.status === "approved" && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="ml-auto rounded-full"
                        onClick={() => setStatus(p.id, "declined")}
                      >
                        Unpublish
                      </Button>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
