import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, Package, ShoppingBag, Banknote, Hourglass } from "lucide-react";
import { ngn } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/analytics")({
  component: Analytics,
});

async function count(
  table: "profiles" | "products" | "orders",
  filters?: Record<string, string>,
) {
  let q = supabase.from(table).select("*", { count: "exact", head: true });
  if (filters) for (const [k, v] of Object.entries(filters)) q = q.eq(k, v);
  const { count, error } = await q;
  if (error) throw error;
  return count ?? 0;
}

function Analytics() {
  const { data, isLoading } = useQuery({
    queryKey: ["admin-analytics"],
    queryFn: async () => {
      const [
        users,
        products,
        pendingProducts,
        orders,
        paidOrders,
        revenueRows,
      ] = await Promise.all([
        count("profiles"),
        count("products", { status: "approved" }),
        count("products", { status: "pending_review" }),
        count("orders"),
        count("orders", { status: "paid" }),
        supabase
          .from("orders")
          .select("total_ngn, status")
          .in("status", ["paid", "processing", "shipped", "delivered"]),
      ]);
      const revenue = (revenueRows.data ?? []).reduce((s, r) => s + Number(r.total_ngn ?? 0), 0);
      return {
        users,
        products,
        pendingProducts,
        orders,
        paidOrders,
        revenue,
      };
    },
  });

  const cards = [
    { icon: Users, label: "Registered users", value: data?.users },
    { icon: Package, label: "Live products", value: data?.products },
    { icon: Hourglass, label: "Pending products", value: data?.pendingProducts },
    { icon: ShoppingBag, label: "Total orders", value: data?.orders },
    { icon: ShoppingBag, label: "Verified orders", value: data?.paidOrders },
    {
      icon: Banknote,
      label: "Gross revenue (verified)",
      value: data ? ngn(data.revenue) : undefined,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl font-semibold">Store overview</h2>
        <p className="text-sm text-muted-foreground">
          Live KPIs across customers, products, orders and revenue.
        </p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="soft-card flex items-start gap-3 p-5">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-secondary text-primary">
              <c.icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{c.label}</p>
              <p className="mt-1 font-display text-2xl font-bold">
                {isLoading || c.value === undefined ? "—" : c.value}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
