import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/become-vendor")({
  beforeLoad: () => { throw redirect({ to: "/dashboard" }); },
  component: () => null,
});
