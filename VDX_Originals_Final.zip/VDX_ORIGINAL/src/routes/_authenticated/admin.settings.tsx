import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { FileUpload } from "@/components/file-upload";
import { Eye, EyeOff, LockKeyhole } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/admin/settings")({
  component: SettingsAdmin,
});

function SettingsAdmin() {
  const qc = useQueryClient();
  const { user, isSuperAdminEmail } = useAuth();
  const { data } = useQuery({
    queryKey: ["all-settings"],
    queryFn: async () => {
      const { data } = await supabase.from("settings").select("key, value");
      return Object.fromEntries((data ?? []).map((s) => [s.key, s.value]));
    },
  });

  const [bankName, setBankName] = useState("");
  const [accountName, setAccountName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [logo, setLogo] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordBusy, setPasswordBusy] = useState(false);

  useEffect(() => {
    if (!data) return;
    const b = (data.bank_details ?? {}) as { bank_name?: string; account_name?: string; account_number?: string };
    setBankName(b.bank_name ?? "");
    setAccountName(b.account_name ?? "");
    setAccountNumber(b.account_number ?? "");
    setLogo((data.site_logo_url as string | null) ?? null);
  }, [data]);

  async function save(key: string, value: unknown, is_public = true) {
    const { error } = await supabase.from("settings").upsert({ key, value: value as never, is_public });
    if (error) throw error;
  }


  async function changeOwnPassword(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (password.length < 8) return toast.error("Password must be at least 8 characters.");
    if (password !== confirmPassword) return toast.error("Passwords do not match.");
    setPasswordBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setPasswordBusy(false);
    if (error) return toast.error("Could not change password", { description: error.message });
    setPassword("");
    setConfirmPassword("");
    toast.success("Super Admin password changed successfully.");
  }

  async function saveAll() {
    try {
      await Promise.all([
        save("bank_details", { bank_name: bankName, account_name: accountName, account_number: accountNumber }, false),
        save("site_logo_url", logo),
      ]);
      toast.success("Store settings saved");
      qc.invalidateQueries({ queryKey: ["all-settings"] });
      qc.invalidateQueries({ queryKey: ["public-settings"] });
      qc.invalidateQueries({ queryKey: ["public-bank"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not save settings");
    }
  }

  if (!isSuperAdminEmail) {
    return <div className="rounded-2xl border border-border p-8 text-center text-sm text-muted-foreground">Only a Super Admin can change protected store settings.</div>;
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card p-5">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">VDX Originals</p>
        <h2 className="mt-2 text-xl font-bold">Payment account</h2>
        <p className="mt-1 text-sm text-muted-foreground">These details are shown to customers after they choose bank transfer at checkout.</p>
        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          <Field label="Bank name" value={bankName} onChange={setBankName} />
          <Field label="Account name" value={accountName} onChange={setAccountName} />
          <Field label="Account number" value={accountNumber} onChange={setAccountNumber} />
        </div>
      </div>

      <form onSubmit={changeOwnPassword} className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2">
          <LockKeyhole className="h-5 w-5" />
          <h2 className="text-xl font-bold">Super Admin security</h2>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">Change the password for your own Super Admin account.</p>
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <PasswordField label="New password" value={password} onChange={setPassword} show={showPassword} setShow={setShowPassword} />
          <PasswordField label="Confirm new password" value={confirmPassword} onChange={setConfirmPassword} show={showConfirmPassword} setShow={setShowConfirmPassword} />
        </div>
        <Button type="submit" variant="outline" className="mt-4 rounded-full" disabled={passwordBusy || !password}>
          {passwordBusy ? "Updating…" : "Change password"}
        </Button>
      </form>

      <div className="rounded-2xl border border-border bg-card p-5">
        <h2 className="text-xl font-bold">Brand assets</h2>
        <p className="mt-1 text-sm text-muted-foreground">Upload a replacement logo when you are ready. The site has a built-in text mark as a safe fallback.</p>
        <div className="mt-4 max-w-md">
          <FileUpload bucket="site-assets" prefix="logos" value={logo} onChange={setLogo} label="Upload logo" />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-secondary/40 p-5 text-sm">
        <p className="font-semibold">Store contact</p>
        <p className="mt-2 text-muted-foreground">vdxoriginals@gmail.com · 07070273404 · WhatsApp 09115066738</p>
        <p className="text-muted-foreground">Best Plaza, Kachia Road, Sabo, Kaduna</p>
      </div>

      <Button className="rounded-full" onClick={saveAll} disabled={!user}>Save settings</Button>
    </div>
  );
}

function PasswordField({ label, value, onChange, show, setShow }: { label: string; value: string; onChange: (v: string) => void; show: boolean; setShow: (v: boolean) => void }) {
  return <label className="block"><span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</span><div className="relative"><input type={show ? "text" : "password"} value={value} onChange={(e) => onChange(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 pr-10 text-sm outline-none focus:border-foreground" /><button type="button" onClick={() => setShow(!show)} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-muted-foreground" aria-label={show ? "Hide password" : "Show password"}>{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></div></label>;
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return <label className="block"><span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</span><input type={type} value={value} onChange={(e) => onChange(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-foreground" /></label>;
}
