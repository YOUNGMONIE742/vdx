import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Banknote, Clock3, CircleCheck, ShoppingBag } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ngn } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/wallets")({
  component: AdminWallet,
});

function AdminWallet() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-wallet"],
    queryFn: async () => {
      const [{ data: payments, error: paymentsError }, { data: orders, error: ordersError }] = await Promise.all([
        supabase.from("payments").select("amount_ngn, verified, created_at"),
        supabase.from("orders").select("total_ngn, status"),
      ]);
      if (paymentsError) throw paymentsError;
      if (ordersError) throw ordersError;

      const rows = payments ?? [];
      const verifiedPayments = rows.filter((p) => p.verified);
      const pendingPayments = rows.filter((p) => !p.verified);
      const verifiedAmount = verifiedPayments.reduce((sum, p) => sum + Number(p.amount_ngn ?? 0), 0);
      const pendingAmount = pendingPayments.reduce((sum, p) => sum + Number(p.amount_ngn ?? 0), 0);
      const orderRevenue = (orders ?? [])
        .filter((o) => ["paid", "processing", "shipped", "delivered"].includes(o.status))
        .reduce((sum, o) => sum + Number(o.total_ngn ?? 0), 0);

      return {
        verifiedAmount,
        pendingAmount,
        orderRevenue,
        verifiedCount: verifiedPayments.length,
        pendingCount: pendingPayments.length,
      };
    },
  });

  const cards = [
    { icon: CircleCheck, label: "Verified payments", value: data ? ngn(data.verifiedAmount) : "—", note: data ? `${data.verifiedCount} payment${data.verifiedCount === 1 ? "" : "s"}` : "" },
    { icon: Clock3, label: "Pending payments", value: data ? ngn(data.pendingAmount) : "—", note: data ? `${data.pendingCount} awaiting review` : "" },
    { icon: ShoppingBag, label: "Verified order value", value: data ? ngn(data.orderRevenue) : "—", note: "Paid and fulfilled orders" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl font-semibold">Store wallet</h2>
        <p className="text-sm text-muted-foreground">A live view of VDX Originals cash flow from customer payments and verified orders.</p>
      </div>
      {error ? <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-5 text-sm text-destructive">Could not load wallet data: {error instanceof Error ? error.message : "Unknown error"}</div> : null}
      <div className="grid gap-4 md:grid-cols-3">
        {cards.map((card) => (
          <div key={card.label} className="soft-card p-5">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-2xl bg-secondary text-primary"><card.icon className="h-5 w-5" /></div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{card.label}</p>
            </div>
            <p className="mt-4 font-display text-2xl font-bold">{isLoading ? "—" : card.value}</p>
            <p className="mt-1 text-xs text-muted-foreground">{card.note}</p>
          </div>
        ))}
      </div>
      <div className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground">
        <div className="flex items-center gap-2 font-semibold text-foreground"><Banknote className="h-4 w-4" /> Payment workflow</div>
        <p className="mt-2">Customer bank-transfer payments appear here as pending until an Admin verifies the submitted proof. Verified amounts are reflected in the wallet summary and analytics.</p>
      </div>
    </div>
  );
}
