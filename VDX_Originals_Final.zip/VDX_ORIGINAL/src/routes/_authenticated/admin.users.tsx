import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";
import type { AppRole } from "@/lib/auth-context";
import { SUPER_ADMIN_EMAILS, useAuth } from "@/lib/auth-context";
import { confirmSuperAdminPassword } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/admin/users")({
  component: UsersAdmin,
});

type Row = { id: string; email: string; full_name: string | null; phone: string | null; created_at: string | null; is_active: boolean; roles: AppRole[] };

function UsersAdmin() {
  const qc = useQueryClient();
  const { primaryRole, isSuperAdminEmail } = useAuth();
  const [q, setQ] = useState("");
  const viewerIsSuper = primaryRole === "super_admin" && isSuperAdminEmail;

  const { data: rows, isLoading, isError, error } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await supabase.rpc("get_admin_users");
      if (!error) {
        return (data ?? []).map((r) => ({ ...r, roles: (r.roles ?? []) as AppRole[] }));
      }

      // Graceful fallback for projects where the newest RPC migration has not
      // been applied yet. This still shows all profile-backed accounts instead
      // of leaving the Super Admin page completely empty.
      const { data: profiles, error: profileError } = await supabase
        .from("profiles")
        .select("id, email, full_name, phone, created_at, is_active")
        .order("created_at", { ascending: false });
      if (profileError) throw profileError;

      const ids = (profiles ?? []).map((p) => p.id);
      let rolesByUser = new Map<string, AppRole[]>();
      if (ids.length) {
        const { data: roleRows } = await supabase
          .from("user_roles")
          .select("user_id, role")
          .in("user_id", ids);
        rolesByUser = new Map<string, AppRole[]>();
        for (const row of roleRows ?? []) {
          const list = rolesByUser.get(row.user_id) ?? [];
          list.push(row.role as AppRole);
          rolesByUser.set(row.user_id, list);
        }
      }
      return (profiles ?? []).map((p) => ({
        ...p,
        roles: rolesByUser.get(p.id) ?? ["customer" as AppRole],
      }));
    },
  });

  async function confirmAndChange(userId: string, role: "admin", action: "grant" | "revoke") {
    if (!viewerIsSuper) return toast.error("Only a Super Admin can change Admin roles.");
    const password = window.prompt("Re-enter your Super Admin password to continue:");
    if (!password) return;
    const verified = await confirmSuperAdminPassword(password);
    if (!verified) return toast.error("Password verification failed.");
    const query = action === "grant"
      ? supabase.from("user_roles").upsert({ user_id: userId, role }, { onConflict: "user_id,role", ignoreDuplicates: true })
      : supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
    const { error } = await query;
    if (error) return toast.error(error.message);
    toast.success(action === "grant" ? "Admin role granted." : "Admin role revoked.");
    qc.invalidateQueries({ queryKey: ["admin-users"] });
  }


  async function toggleActive(userId: string, active: boolean) {
    if (!viewerIsSuper) return toast.error("Only a Super Admin can disable or enable accounts.");
    const action = active ? "enable" : "disable";
    if (!confirm(`${active ? "Enable" : "Disable"} this account?`)) return;
    const { error } = await supabase.rpc("set_user_active", { p_user_id: userId, p_active: active });
    if (error) return toast.error(error.message);
    toast.success(`Account ${action}d.`);
    qc.invalidateQueries({ queryKey: ["admin-users"] });
  }

  const filtered = (rows ?? []).filter((r) => {
    const s = q.trim().toLowerCase();
    return !s || r.email.toLowerCase().includes(s) || (r.full_name ?? "").toLowerCase().includes(s);
  });

  return <div>
    <div className="rounded-2xl border border-border bg-card p-5">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">Access management</p>
      <h2 className="mt-2 text-2xl font-bold">Users & roles</h2>
      <p className="mt-1 text-sm text-muted-foreground">Super Admins can grant or revoke the Admin role. Super Admin access is permanently reserved for the two protected emails.</p>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or email" className="mt-5 h-11 w-full max-w-md rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-foreground" />
    </div>
    {isLoading ? <p className="mt-6 text-sm text-muted-foreground">Loading users…</p> : isError ? <div className="mt-6 rounded-2xl border border-destructive/30 bg-destructive/5 p-5 text-sm text-destructive">Could not load users. {error instanceof Error ? error.message : "Please check your Supabase migration and permissions."}</div> : <ul className="mt-4 space-y-3">
      {filtered.map((r) => {
        const isProtected = SUPER_ADMIN_EMAILS.includes(r.email.toLowerCase() as (typeof SUPER_ADMIN_EMAILS)[number]);
        const isAdmin = r.roles.includes("admin");
        return <li key={r.id} className="rounded-2xl border border-border bg-card p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="min-w-0 flex-1"><p className="font-semibold">{r.full_name ?? "Unnamed user"}</p><p className="text-xs text-muted-foreground">{r.email} · {r.phone ?? "No phone"}</p><p className="mt-1 text-xs text-muted-foreground">Roles: {isProtected ? "super_admin" : (r.roles.filter(x => x !== "vendor" && x !== "super_admin").join(", ") || "customer")} · {r.is_active ? "Active" : "Disabled"}</p></div>
            {!isProtected && viewerIsSuper && <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" className="rounded-full" onClick={() => confirmAndChange(r.id, "admin", isAdmin ? "revoke" : "grant")}>{isAdmin ? "Revoke Admin" : "Make Admin"}</Button>
              <Button size="sm" variant="outline" className={`rounded-full ${r.is_active ? "text-destructive" : ""}`} onClick={() => toggleActive(r.id, !r.is_active)}>{r.is_active ? "Disable account" : "Enable account"}</Button>
            </div>}
            {isProtected && <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">Protected Super Admin</span>}
          </div>
        </li>;
      })}
    </ul>}
  </div>;
}
