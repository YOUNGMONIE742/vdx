import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { useSignedUrl } from "@/components/stored-image";
import { ngn, statusBadge } from "@/lib/format";
import { ExternalLink, FileText } from "lucide-react";

type Row = {
  id: string;
  order_id: string;
  amount_ngn: number;
  transaction_id: string | null;
  proof_url: string | null;
  verified: boolean;
  created_at: string;
  orders: { order_number: string; status: string; user_id: string } | null;
};

export const Route = createFileRoute("/_authenticated/admin/payments")({
  component: PaymentsAdmin,
});

function PaymentsAdmin() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"pending" | "verified">("pending");
  const { data: rows } = useQuery({
    queryKey: ["admin-payments", filter],
    queryFn: async () => {
      const { data } = await supabase
        .from("payments")
        .select(
          "id, order_id, amount_ngn, transaction_id, proof_url, verified, created_at, orders(order_number, status, user_id)",
        )
        .eq("verified", filter === "verified")
        .order("created_at", { ascending: false });
      return (data ?? []) as unknown as Row[];
    },
  });

  async function verify(r: Row) {
    const { error: pErr } = await supabase
      .from("payments")
      .update({ verified: true, verified_by: user!.id, verified_at: new Date().toISOString() })
      .eq("id", r.id);
    if (pErr) return toast.error(pErr.message);
    const { error: oErr } = await supabase
      .from("orders")
      .update({ status: "paid" })
      .eq("id", r.order_id);
    if (oErr) return toast.error(oErr.message);
    toast.success("Payment verified · order marked paid");
    qc.invalidateQueries({ queryKey: ["admin-payments"] });
  }
  async function setOrderStatus(
    orderId: string,
    status: "processing" | "shipped" | "delivered" | "cancelled",
  ) {
    const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin-payments"] });
  }

  return (
    <div>
      <div className="mb-4 flex gap-2">
        {(["pending", "verified"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-3 py-1 text-xs font-semibold capitalize ${filter === f ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
          >
            {f}
          </button>
        ))}
      </div>
      {!rows || rows.length === 0 ? (
        <p className="soft-card p-8 text-center text-sm text-muted-foreground">
          No {filter} payments.
        </p>
      ) : (
        <ul className="space-y-3">
          {rows.map((r) => (
            <li key={r.id} className="soft-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-sm font-bold">{r.orders?.order_number ?? "—"}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(r.created_at).toLocaleString()}
                  </p>
                  <p className="mt-1 text-sm">
                    Amount: <strong>{ngn(r.amount_ngn)}</strong> · TX:{" "}
                    <span className="font-mono">{r.transaction_id ?? "—"}</span>
                  </p>
                  <ProofLink path={r.proof_url} />
                </div>
                <div className="flex flex-col items-end gap-2">
                  {r.orders && (
                    <span
                      className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${statusBadge(r.orders.status).tone}`}
                    >
                      {statusBadge(r.orders.status).label}
                    </span>
                  )}
                  {!r.verified ? (
                    <Button size="sm" className="rounded-full" onClick={() => verify(r)}>
                      Verify payment
                    </Button>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-full"
                        onClick={() => setOrderStatus(r.order_id, "processing")}
                      >
                        Processing
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-full"
                        onClick={() => setOrderStatus(r.order_id, "shipped")}
                      >
                        Shipped
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-full"
                        onClick={() => setOrderStatus(r.order_id, "delivered")}
                      >
                        Delivered
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-full"
                        onClick={() => setOrderStatus(r.order_id, "cancelled")}
                      >
                        Cancel
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function ProofLink({ path }: { path: string | null }) {
  const { data: url } = useSignedUrl("payment-proofs", path);
  if (!path) return <p className="mt-1 text-xs text-muted-foreground">No proof uploaded</p>;
  if (!url) return <p className="mt-1 text-xs text-muted-foreground">Loading proof…</p>;
  return (
    <a
      href={url}
      target="_blank"
      rel="noreferrer"
      className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
    >
      <FileText className="h-3 w-3" /> View proof <ExternalLink className="h-3 w-3" />
    </a>
  );
}
