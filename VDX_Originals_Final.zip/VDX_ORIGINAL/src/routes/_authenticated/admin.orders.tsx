import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { toast } from "sonner";
import { StoredImage } from "@/components/stored-image";
import { ngn, statusBadge } from "@/lib/format";
import { Truck, User as UserIcon, Phone, Mail, MapPin } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/orders")({
  component: AdminOrders,
});

const STATUSES = [
  "pending_payment",
  "payment_review",
  "paid",
  "processing",
  "packed",
  "shipped",
  "out_for_delivery",
  "delivered",
  "cancelled",
  "refunded",
  "returned",
] as const;
type Status = (typeof STATUSES)[number];

type Item = {
  id: string;
  title: string;
  quantity: number;
  unit_price_ngn: number;
  sold_by_type: "vendor" | "welcome_wagon";
  products: {
    primary_image_url: string | null;
    product_code: string | null;
  } | null;
};
type Order = {
  id: string;
  order_number: string;
  status: Status;
  total_ngn: number;
  subtotal_ngn: number;
  shipping_ngn: number;
  contact_phone: string | null;
  customer_name: string | null;
  customer_email: string | null;
  shipping_address: Record<string, string> | null;
  notes: string | null;
  created_at: string;
  order_items: Item[];
  payments: Array<{ verified: boolean }>;
};

function AdminOrders() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"all" | Status>("all");
  const { data: orders, isLoading } = useQuery({
    queryKey: ["admin-orders", filter],
    queryFn: async () => {
      let q = supabase
        .from("orders")
        .select(
          "id, order_number, status, total_ngn, subtotal_ngn, shipping_ngn, contact_phone, customer_name, customer_email, shipping_address, notes, created_at, order_items(id, title, quantity, unit_price_ngn, sold_by_type, products(primary_image_url, product_code)), payments(verified)",
        )
        .order("created_at", { ascending: false })
        .limit(200);
      if (filter !== "all") q = q.eq("status", filter);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as Order[];
    },
  });

  async function updateStatus(id: string, status: Status) {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Order marked ${statusBadge(status).label}`);
    qc.invalidateQueries({ queryKey: ["admin-orders"] });
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Truck className="h-4 w-4 text-primary" />
        <span className="text-sm font-semibold">Filter:</span>
        <button
          onClick={() => setFilter("all")}
          className={`rounded-full px-3 py-1 text-xs font-semibold ${filter === "all" ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
        >
          All
        </button>
        {STATUSES.map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-full px-3 py-1 text-xs font-semibold ${filter === s ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
          >
            {statusBadge(s).label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <p className="soft-card p-8 text-center text-sm text-muted-foreground">Loading orders…</p>
      ) : !orders || orders.length === 0 ? (
        <p className="soft-card p-8 text-center text-sm text-muted-foreground">
          No orders match this filter.
        </p>
      ) : (
        <ul className="space-y-4">
          {orders.map((o) => {
            const badge = statusBadge(o.status);
            const addr = o.shipping_address ?? {};
            const paid = o.payments?.some((p) => p.verified);
            return (
              <li key={o.id} className="soft-card p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-sm font-bold">{o.order_number}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(o.created_at).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${badge.tone}`}
                    >
                      {badge.label}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      Payment:{" "}
                      <strong className={paid ? "text-emerald-600" : "text-amber-600"}>
                        {paid ? "Verified" : "Awaiting"}
                      </strong>
                    </span>
                    <span className="font-bold text-primary">{ngn(o.total_ngn)}</span>
                  </div>
                </div>

                <div className="mt-4 grid gap-4 md:grid-cols-[1fr_260px]">
                  <ul className="space-y-3">
                    {o.order_items.map((it) => {
                      const seller = "VDX Originals";
                      return (
                        <li
                          key={it.id}
                          className="flex items-center gap-3 rounded-xl border border-border/60 bg-background/40 p-2"
                        >
                          <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-secondary">
                            {it.products?.primary_image_url && (
                              <StoredImage
                                bucket="product-media"
                                path={it.products.primary_image_url}
                                alt=""
                                className="h-full w-full object-cover"
                              />
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="line-clamp-1 text-sm font-semibold">{it.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {seller}
                              {it.products?.product_code ? ` · ${it.products.product_code}` : ""}
                            </p>
                          </div>
                          <div className="text-right text-xs">
                            <p className="font-semibold">
                              {it.quantity} × {ngn(it.unit_price_ngn)}
                            </p>
                            <p className="text-muted-foreground">
                              {ngn(it.quantity * it.unit_price_ngn)}
                            </p>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                  <aside className="rounded-xl border border-border/60 bg-background/40 p-3 text-xs">
                    <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                      Delivery contact
                    </p>
                    <p className="flex items-center gap-1.5">
                      <UserIcon className="h-3.5 w-3.5 text-muted-foreground" />{" "}
                      {o.customer_name || addr.full_name || "—"}
                    </p>
                    <p className="flex items-center gap-1.5">
                      <Phone className="h-3.5 w-3.5 text-muted-foreground" />{" "}
                      {o.contact_phone || "—"}
                    </p>
                    <p className="flex items-center gap-1.5">
                      <Mail className="h-3.5 w-3.5 text-muted-foreground" />{" "}
                      {o.customer_email || addr.email || "—"}
                    </p>
                    <p className="mt-2 flex items-start gap-1.5">
                      <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                      <span>
                        {addr.address ?? "—"}
                        <br />
                        {[addr.city, addr.state, addr.postal_code].filter(Boolean).join(", ")}
                      </span>
                    </p>
                    {o.notes && (
                      <p className="mt-2 rounded-md bg-muted/50 p-2 italic">Note: {o.notes}</p>
                    )}
                  </aside>
                </div>

                <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border/60 pt-3">
                  <span className="text-xs font-semibold text-muted-foreground">
                    Update status:
                  </span>
                  <select
                    value={o.status}
                    onChange={(e) => updateStatus(o.id, e.target.value as Status)}
                    className="h-8 rounded-full border border-border bg-card px-3 text-xs font-medium outline-none focus:border-primary"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {statusBadge(s).label}
                      </option>
                    ))}
                  </select>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
