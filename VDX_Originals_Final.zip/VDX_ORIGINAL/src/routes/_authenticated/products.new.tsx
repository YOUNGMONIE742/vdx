import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { FileUpload } from "@/components/file-upload";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { slugify } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/products/new")({
  head: () => ({ meta: [{ title: "New product — VDX Originals" }] }),
  component: NewProduct,
});

function NewProduct() {
  const { user, primaryRole } = useAuth();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [productCode, setProductCode] = useState("");
  const [shortDescription, setShortDescription] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [discountPrice, setDiscountPrice] = useState("");
  const [stock, setStock] = useState("1");
  const [lowStock, setLowStock] = useState("5");
  const [categoryId, setCategoryId] = useState("");
  const [subcategory, setSubcategory] = useState("");
  const [brand, setBrand] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [image2, setImage2] = useState<string | null>(null);
  const [image3, setImage3] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [supplier, setSupplier] = useState("");
  const [sku, setSku] = useState("");
  const [weight, setWeight] = useState("");
  const [dimensions, setDimensions] = useState("");
  const [condition, setCondition] = useState("new");
  const [tags, setTags] = useState("");
  const [visibility, setVisibility] = useState("public");
  const [isFeatured, setIsFeatured] = useState(false);
  const [variants, setVariants] = useState("");
  const [shippingFee, setShippingFee] = useState("");
  const [deliveryTime, setDeliveryTime] = useState("");
  const [returnPolicy, setReturnPolicy] = useState("");
  const [warranty, setWarranty] = useState("");
  const [soldBy, setSoldBy] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data } = await supabase.from("categories").select("id, name").order("display_order");
      return data ?? [];
    },
  });

  const isStoreStaff = primaryRole === "admin" || primaryRole === "super_admin";
  const fieldCls = "h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary";
  const labelCls = "mb-1 block text-xs font-semibold uppercase text-muted-foreground";

  async function submit(e: React.FormEvent, asDraft: boolean) {
    e.preventDefault();
    if (!user) return;
    if (!isStoreStaff) return toast.error("Only Admins can add products.");
    if (!image) return toast.error("Add at least one product image.");
    if (Number(price) < 0) return toast.error("Price cannot be negative.");
    if (Number(stock) < 0) return toast.error("Quantity cannot be negative.");
    if (discountPrice && Number(discountPrice) < 0) return toast.error("Discount cannot be negative.");
    setBusy(true);
    if (productCode.trim()) {
      const { data: existing } = await supabase.from("products").select("id").eq("product_code", productCode.trim()).maybeSingle();
      if (existing) { setBusy(false); return toast.error("Product code already exists — pick a unique one."); }
    }
    const slug = `${slugify(title)}-${Math.random().toString(36).slice(2, 6)}`;
    const gallery = [image, image2, image3].filter(Boolean) as string[];
    let parsedVariants: unknown = null;
    if (variants.trim()) {
      try { parsedVariants = JSON.parse(variants); }
      catch { parsedVariants = variants.split(",").map((v) => v.trim()).filter(Boolean); }
    }
    const { error } = await supabase.from("products").insert({
      title,
      slug,
      product_code: productCode.trim() || null,
      short_description: shortDescription || null,
      description: description || null,
      price_ngn: Number(price),
      discount_price_ngn: discountPrice ? Number(discountPrice) : null,
      stock: Number(stock),
      low_stock_threshold: Number(lowStock) || 5,
      primary_image_url: image,
      images: gallery,
      video_url: videoUrl,
      category_id: categoryId || null,
      subcategory: subcategory || null,
      brand: brand || null,
      supplier: supplier || null,
      sku: sku || null,
      weight: weight || null,
      dimensions: dimensions || null,
      condition: condition || null,
      tags: tags ? tags.split(",").map((t) => t.trim()).filter(Boolean) : [],
      visibility,
      is_featured: isFeatured,
      variants: (parsedVariants ?? []) as never,
      shipping_fee_ngn: shippingFee ? Number(shippingFee) : 0,
      delivery_time: deliveryTime || null,
      return_policy: returnPolicy || null,
      warranty: warranty || null,
      sold_by: "VDX Originals",
      vendor_id: null,
      sold_by_type: "welcome_wagon",
      status: asDraft ? "draft" : "approved",
      created_by: user.id,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(asDraft ? "Saved as draft." : "Product published successfully.");
    navigate({ to: "/products" });
  }

  if (!isStoreStaff) {
    return (
      <PageShell>
        <section className="mx-auto max-w-2xl px-4 py-16 text-center">
          <h1 className="font-display text-2xl font-bold">Admin access required</h1>
          <p className="mt-2 text-sm text-muted-foreground">Only Admins and Super Admins can add products.</p>
        </section>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        <Link to="/products" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> My products</Link>
        <h1 className="mt-4 font-display text-3xl font-bold">New product</h1>
        <form onSubmit={(e) => submit(e, false)} className="soft-card mt-6 space-y-4 p-6">
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block"><span className={labelCls}>Product name *</span>
              <input value={title} required maxLength={200} onChange={(e) => setTitle(e.target.value)} className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Product code (unique)</span>
              <input value={productCode} onChange={(e) => setProductCode(e.target.value)} placeholder="e.g. VDX-0001" className={fieldCls} />
            </label>
          </div>
          <label className="block"><span className={labelCls}>Short description</span>
            <input value={shortDescription} maxLength={160} onChange={(e) => setShortDescription(e.target.value)} placeholder="One-line summary" className={fieldCls} />
          </label>
          <label className="block"><span className={labelCls}>Full description</span>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary" />
          </label>

          <div className="grid gap-3 sm:grid-cols-3">
            <label className="block"><span className={labelCls}>Category</span>
              <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className={fieldCls}>
                <option value="">—</option>
                {(categories ?? []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
            <label className="block"><span className={labelCls}>Subcategory</span>
              <input value={subcategory} onChange={(e) => setSubcategory(e.target.value)} className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Brand</span>
              <input value={brand} onChange={(e) => setBrand(e.target.value)} className={fieldCls} />
            </label>
          </div>

          <div>
            <label className={labelCls}>Product images * (up to 3)</label>
            <div className="grid gap-3 sm:grid-cols-3">
              <FileUpload bucket="product-media" prefix={user?.id ?? "anon"} value={image} onChange={setImage} label="Primary" />
              <FileUpload bucket="product-media" prefix={user?.id ?? "anon"} value={image2} onChange={setImage2} label="Image 2" />
              <FileUpload bucket="product-media" prefix={user?.id ?? "anon"} value={image3} onChange={setImage3} label="Image 3" />
            </div>
          </div>
          <div>
            <label className={labelCls}>Product video (optional)</label>
            <FileUpload bucket="product-media" prefix={user?.id ?? "anon"} value={videoUrl} onChange={setVideoUrl} label="Upload video" accept="video/*" maxMB={50} />
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <label className="block"><span className={labelCls}>Price (NGN) *</span>
              <input value={price} type="number" min="0" required onChange={(e) => setPrice(e.target.value)} className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Discount price</span>
              <input value={discountPrice} type="number" min="0" onChange={(e) => setDiscountPrice(e.target.value)} className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Shipping fee</span>
              <input value={shippingFee} type="number" min="0" onChange={(e) => setShippingFee(e.target.value)} className={fieldCls} />
            </label>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <label className="block"><span className={labelCls}>Stock quantity *</span>
              <input value={stock} type="number" min="0" required onChange={(e) => setStock(e.target.value)} className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Low stock threshold</span>
              <input value={lowStock} type="number" min="0" onChange={(e) => setLowStock(e.target.value)} className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>SKU</span>
              <input value={sku} onChange={(e) => setSku(e.target.value)} className={fieldCls} />
            </label>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <label className="block"><span className={labelCls}>Weight</span>
              <input value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="e.g. 500g" className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Dimensions</span>
              <input value={dimensions} onChange={(e) => setDimensions(e.target.value)} placeholder="LxWxH" className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Condition</span>
              <select value={condition} onChange={(e) => setCondition(e.target.value)} className={fieldCls}>
                <option value="new">New</option>
                <option value="used">Used</option>
                <option value="refurbished">Refurbished</option>
              </select>
            </label>
          </div>

          <label className="block"><span className={labelCls}>Tags (comma separated)</span>
            <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="baby, gift, cotton" className={fieldCls} />
          </label>

          <label className="block"><span className={labelCls}>Variants (JSON or comma list)</span>
            <input value={variants} onChange={(e) => setVariants(e.target.value)} placeholder='{"size":["S","M","L"],"color":["red","blue"]}' className={fieldCls} />
          </label>

          <div className="grid gap-3 sm:grid-cols-3">
            <label className="block"><span className={labelCls}>Visibility</span>
              <select value={visibility} onChange={(e) => setVisibility(e.target.value)} className={fieldCls}>
                <option value="public">Public</option>
                <option value="hidden">Hidden</option>
              </select>
            </label>
            <label className="block"><span className={labelCls}>Delivery time</span>
              <input value={deliveryTime} onChange={(e) => setDeliveryTime(e.target.value)} placeholder="e.g. 2-5 days" className={fieldCls} />
            </label>
            <label className="mt-6 inline-flex items-center gap-2 text-sm">
              <input type="checkbox" checked={isFeatured} onChange={(e) => setIsFeatured(e.target.checked)} /> Featured product
            </label>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block"><span className={labelCls}>Return policy</span>
              <input value={returnPolicy} onChange={(e) => setReturnPolicy(e.target.value)} placeholder="e.g. 7-day returns" className={fieldCls} />
            </label>
            <label className="block"><span className={labelCls}>Warranty</span>
              <input value={warranty} onChange={(e) => setWarranty(e.target.value)} className={fieldCls} />
            </label>
          </div>

          <div className="rounded-xl bg-secondary/50 p-3 text-xs text-muted-foreground">Sold by <strong className="text-foreground">VDX Originals</strong>. This is a single-store catalog; vendor selection is not required.</div>

          <div className="flex flex-wrap gap-2 pt-2">
            <Button type="button" variant="outline" className="rounded-full" disabled={busy} onClick={(e) => submit(e as unknown as React.FormEvent, true)}>Save draft</Button>
            <Button type="submit" className="rounded-full" disabled={busy}>{busy ? "Submitting…" : "Submit for review"}</Button>
          </div>
        </form>
      </section>
    </PageShell>
  );
}