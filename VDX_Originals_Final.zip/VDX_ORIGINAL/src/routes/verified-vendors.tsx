import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/verified-vendors")({
  component: () => <Navigate to="/" replace />,
});
