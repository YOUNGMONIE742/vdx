import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart-context";
import { StoredImage } from "@/components/stored-image";
import { ngn } from "@/lib/format";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Your cart — VDX Originals" }] }),
  component: CartPage,
});

function CartPage() {
  const cart = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  return (
    <PageShell>
      <section className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Your cart</h1>
        {cart.items.length === 0 ? (
          <div className="soft-card mt-8 p-12 text-center">
            <ShoppingBag className="mx-auto h-10 w-10 text-muted-foreground" />
            <p className="mt-3 text-sm text-muted-foreground">Your cart is empty.</p>
            <Link to="/shop" className="mt-3 inline-block text-sm font-medium text-primary hover:underline">Continue shopping →</Link>
          </div>
        ) : (
          <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
            <ul className="space-y-3">
              {cart.items.map((it) => (
                <li key={`${it.product_id}-${it.variant ?? ""}`} className="soft-card flex gap-4 p-4">
                  <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-secondary">
                    <StoredImage bucket="product-media" path={it.image} alt={it.title} className="h-full w-full object-cover" />
                  </div>
                  <div className="flex flex-1 flex-col">
                    <Link to="/product/$slug" params={{ slug: it.slug }} className="line-clamp-2 text-sm font-semibold hover:underline">{it.title}</Link>
                    {it.variant && <p className="text-xs font-medium text-foreground">{it.variant}</p>}
                    <p className="text-xs text-muted-foreground">VDX Originals</p>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="inline-flex items-center rounded-full border border-border">
                        <button className="grid h-8 w-8 place-items-center" onClick={() => cart.setQty(it.product_id, it.quantity - 1, it.variant)} aria-label="Decrease"><Minus className="h-3.5 w-3.5" /></button>
                        <span className="w-8 text-center text-sm font-semibold">{it.quantity}</span>
                        <button className="grid h-8 w-8 place-items-center" onClick={() => cart.setQty(it.product_id, it.quantity + 1, it.variant)} aria-label="Increase"><Plus className="h-3.5 w-3.5" /></button>
                      </div>
                      <p className="font-bold text-primary">{ngn(it.price_ngn * it.quantity)}</p>
                    </div>
                  </div>
                  <button onClick={() => cart.remove(it.product_id, it.variant)} className="self-start text-muted-foreground hover:text-destructive" aria-label="Remove">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
            <aside className="soft-card h-fit p-5">
              <h2 className="font-display text-lg font-semibold">Summary</h2>
              <dl className="mt-3 space-y-1 text-sm">
                <div className="flex justify-between"><dt>Subtotal</dt><dd className="font-semibold">{ngn(cart.subtotal)}</dd></div>
                <div className="flex justify-between"><dt>Shipping</dt><dd className="text-muted-foreground">Calculated at checkout</dd></div>
              </dl>
              <div className="mt-4 flex items-baseline justify-between border-t border-border pt-3">
                <span className="text-sm">Total</span>
                <span className="font-display text-xl font-bold text-primary">{ngn(cart.subtotal)}</span>
              </div>
              <Button
                className="mt-4 w-full rounded-full"
                onClick={() => {
                  if (!user) navigate({ to: "/auth", search: { redirect: "/checkout" } as never });
                  else navigate({ to: "/checkout" });
                }}
              >
                Proceed to checkout
              </Button>
              <Link to="/shop" className="mt-3 block text-center text-xs text-muted-foreground hover:text-primary">Continue shopping</Link>
            </aside>
          </div>
        )}
      </section>
    </PageShell>
  );
}