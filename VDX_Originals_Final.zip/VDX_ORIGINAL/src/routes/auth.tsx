import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Eye, EyeOff, KeyRound } from "lucide-react";

const searchSchema = z
  .object({
    tab: z.enum(["login", "register"]).optional(),
    redirect: z.string().optional(),
    token_hash: z.string().optional(),
    type: z.string().optional(),
    error: z.string().optional(),
    error_description: z.string().optional(),
  })
  .passthrough();

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign In or Register — VDX Originals" },
      {
        name: "description",
        content: "Sign in or create your VDX Originals account to shop and manage orders.",
      },
    ],
  }),
  validateSearch: searchSchema,
  component: AuthPage,
});

const registerSchema = z.object({
  full_name: z.string().trim().min(2, "Enter your full name").max(100),
  username: z
    .string()
    .trim()
    .min(3, "At least 3 characters")
    .max(30)
    .regex(/^[a-zA-Z0-9_.]+$/, "Letters, numbers, _ or . only"),
  email: z.string().trim().email("Enter a valid email address").max(200),
  phone: z.string().trim().min(7, "Enter a valid phone number").max(20),
  password: z.string().min(8, "Password must be at least 8 characters").max(72),
});

const loginSchema = z.object({
  email: z.string().trim().email("Enter a valid email address").max(200),
  password: z.string().min(1, "Password is required").max(72),
});

export function AuthPage() {
  const search = Route.useSearch();
  const redirect = search.redirect;

  const [passwordMode, setPasswordMode] = useState<"login" | "register">(
    search.tab === "register" ? "register" : "login",
  );

  // Password visibility
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);

  // Password reset modal
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetEmail, setResetEmail] = useState("");

  const [busy, setBusy] = useState(false);
  const [recoveryPassword, setRecoveryPassword] = useState("");
  const [recoveryPassword2, setRecoveryPassword2] = useState("");
  const [recoveryMode, setRecoveryMode] = useState(search.type === "recovery");

  const { session, loading } = useAuth();
  const navigate = useNavigate();

  // Redirect if already logged in
  useEffect(() => {
    if (!loading && session && !recoveryMode) {
      navigate({
        to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
        replace: true,
      });
    }
  }, [loading, session, navigate, redirect, recoveryMode]);

  // Handle email verification / password reset links
  useEffect(() => {
    if (typeof window === "undefined") return;

    const url = new URL(window.location.href);
    const recoveryFromUrl = url.searchParams.get("type") === "recovery" ||
      new URLSearchParams(window.location.hash.replace(/^#/, "")).get("type") === "recovery";
    if (recoveryFromUrl) setRecoveryMode(true);
    const hash = window.location.hash
      ? new URLSearchParams(window.location.hash.substring(1))
      : null;
    const errorParam = url.searchParams.get("error_description") || url.searchParams.get("error");
    const hashError = hash?.get("error_description") || hash?.get("error");
    const tokenHash = url.searchParams.get("token_hash") || hash?.get("token_hash");
    const otpType = (url.searchParams.get("type") || hash?.get("type")) as
      "email" | "signup" | "invite" | "magiclink" | "recovery" | null;

    if (errorParam || hashError) {
      toast.error("Authentication notice", {
        description: errorParam || hashError || "An error occurred",
      });
      return;
    }

    if (tokenHash) {
      setBusy(true);
      supabase.auth
        .verifyOtp({ token_hash: tokenHash, type: (otpType ?? "email") as "email" })
        .then(({ data, error }) => {
          setBusy(false);
          if (data?.session) {
            toast.success("Verified successfully!");
            navigate({
              to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
              replace: true,
            });
          } else if (error) {
            toast.error("Verification error", { description: error.message });
          }
        })
        .catch(() => setBusy(false));
    }
  }, [navigate, redirect]);

  // Handle Email & Password Login
  async function handleLogin(form: FormData) {
    const parsed = loginSchema.safeParse({
      email: form.get("email"),
      password: form.get("password"),
    });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setBusy(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email: parsed.data.email.toLowerCase(),
      password: parsed.data.password,
    });
    setBusy(false);
    if (error) {
      toast.error("Sign-in failed", { description: error.message });
      return;
    }
    if (data.session) {
      toast.success("Welcome back!");
      navigate({
        to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
        replace: true,
      });
    }
  }

  // Handle Email & Password Registration
  async function handleRegister(form: FormData) {
    const parsed = registerSchema.safeParse({
      full_name: form.get("full_name"),
      username: form.get("username"),
      email: form.get("email"),
      phone: form.get("phone"),
      password: form.get("password"),
    });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email: parsed.data.email.toLowerCase(),
      password: parsed.data.password,
      options: {
        data: {
          full_name: parsed.data.full_name,
          username: parsed.data.username,
          phone: parsed.data.phone,
        },
      },
    });
    setBusy(false);
    if (error) {
      toast.error("Could not create account", { description: error.message });
      return;
    }

    if (data.session) {
      toast.success("Account created successfully!");
      navigate({
        to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
        replace: true,
      });
    } else {
      toast.success("Account created! You can now sign in below.");
      setPasswordMode("login");
    }
  }

  // Handle Password Reset Request
  async function handlePasswordReset(e: React.FormEvent) {
    e.preventDefault();
    if (!resetEmail.trim()) {
      toast.error("Enter your account email address");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(resetEmail.trim().toLowerCase(), {
      redirectTo: `${window.location.origin}/auth?type=recovery`,
    });
    setBusy(false);
    if (error) {
      toast.error("Could not send reset email", { description: error.message });
      return;
    }
    toast.success("Password reset email sent!", {
      description: "Please check your inbox for instructions to reset your password.",
    });
    setShowResetModal(false);
  }

  async function handleRecoveryPassword(e: React.FormEvent) {
    e.preventDefault();
    if (recoveryPassword.length < 8) {
      toast.error("Password must be at least 8 characters.");
      return;
    }
    if (recoveryPassword !== recoveryPassword2) {
      toast.error("Passwords do not match.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: recoveryPassword });
    setBusy(false);
    if (error) {
      toast.error("Could not reset password", { description: error.message });
      return;
    }
    toast.success("Password reset successfully.");
    setRecoveryPassword("");
    setRecoveryPassword2("");
    setRecoveryMode(false);
    navigate({ to: "/dashboard", replace: true });
  }

  if (recoveryMode) {
    return (
      <PageShell>
        <section className="mx-auto grid max-w-md gap-6 px-4 py-12 sm:px-6">
          <div className="text-center">
            <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-foreground text-background text-xl font-bold">V</div>
            <h1 className="mt-4 font-display text-2xl font-bold">Create a new password</h1>
            <p className="mt-1 text-xs text-muted-foreground">Choose a strong new password for your VDX Originals account.</p>
          </div>
          <form onSubmit={handleRecoveryPassword} className="soft-card space-y-4 p-6">
            <div>
              <label className="text-xs font-medium text-foreground">New password</label>
              <input
                type="password"
                value={recoveryPassword}
                onChange={(e) => setRecoveryPassword(e.target.value)}
                required
                autoComplete="new-password"
                className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-foreground">Confirm new password</label>
              <input
                type="password"
                value={recoveryPassword2}
                onChange={(e) => setRecoveryPassword2(e.target.value)}
                required
                autoComplete="new-password"
                className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <Button type="submit" disabled={busy} className="h-11 w-full rounded-full">
              {busy ? "Updating…" : "Update password"}
            </Button>
          </form>
        </section>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <section className="mx-auto grid max-w-md gap-6 px-4 py-12 sm:px-6">
        {/* Brand Header */}
        <div className="text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-foreground text-background text-xl font-bold">V</div>
          <h1 className="mt-4 font-display text-2xl font-bold">Welcome to VDX ORIGINALS</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            Contemporary clothing, simple ordering, and direct support.
          </p>
        </div>

        <div className="soft-card p-6 space-y-5 shadow-sm">
          {/* Mode toggle */}
          <div className="flex rounded-xl bg-muted/70 p-1 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setPasswordMode("login")}
              className={`flex-1 py-2 rounded-lg transition-all cursor-pointer ${
                passwordMode === "login"
                  ? "bg-background text-foreground shadow-xs font-bold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setPasswordMode("register")}
              className={`flex-1 py-2 rounded-lg transition-all cursor-pointer ${
                passwordMode === "register"
                  ? "bg-background text-foreground shadow-xs font-bold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Create Account
            </button>
          </div>

          {passwordMode === "login" ? (
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                handleLogin(new FormData(e.currentTarget));
              }}
            >
              <Field label="Email address" name="email" type="email" required />
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-foreground">Password</label>
                  <button
                    type="button"
                    onClick={() => setShowResetModal(true)}
                    className="text-xs text-primary hover:underline cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    name="password"
                    type={showLoginPassword ? "text" : "password"}
                    required
                    autoComplete="current-password"
                    className="h-11 w-full rounded-xl border border-border bg-card pl-3 pr-10 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 cursor-pointer transition-colors"
                    aria-label={showLoginPassword ? "Hide password" : "Show password"}
                  >
                    {showLoginPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>
              <Button type="submit" disabled={busy} className="h-11 w-full rounded-full mt-2">
                {busy ? "Signing in…" : "Sign In"}
              </Button>
            </form>
          ) : (
            <form
              className="space-y-3.5"
              onSubmit={(e) => {
                e.preventDefault();
                handleRegister(new FormData(e.currentTarget));
              }}
            >
              <Field label="Full name" name="full_name" required />
              <Field label="Username" name="username" required />
              <Field label="Email address" name="email" type="email" required />
              <Field label="Phone number" name="phone" type="tel" required />
              <div>
                <label className="text-xs font-medium text-foreground">
                  Password (min 8 characters)
                </label>
                <div className="relative mt-1">
                  <input
                    name="password"
                    type={showRegisterPassword ? "text" : "password"}
                    required
                    autoComplete="new-password"
                    className="h-11 w-full rounded-xl border border-border bg-card pl-3 pr-10 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegisterPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 cursor-pointer transition-colors"
                    aria-label={showRegisterPassword ? "Hide password" : "Show password"}
                  >
                    {showRegisterPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>
              <Button type="submit" disabled={busy} className="h-11 w-full rounded-full mt-2">
                {busy ? "Creating account…" : "Create Account"}
              </Button>
            </form>
          )}
        </div>

        {/* Forgot Password Modal */}
        {showResetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-xs p-4">
            <div className="soft-card max-w-sm w-full p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 font-display text-lg font-semibold">
                <KeyRound className="h-5 w-5 text-primary" /> Reset Password
              </div>
              <p className="text-xs text-muted-foreground">
                Enter your account email address. We will send you a secure link to reset your
                password.
              </p>
              <form onSubmit={handlePasswordReset} className="space-y-3">
                <div>
                  <label className="text-xs font-medium text-foreground">Email address</label>
                  <input
                    type="email"
                    required
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowResetModal(false)}
                    className="rounded-full"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={busy} className="rounded-full">
                    {busy ? "Sending…" : "Send Reset Link"}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        <p className="text-center text-xs text-muted-foreground">
          By continuing you agree to our{" "}
          <Link to="/support" className="underline hover:text-primary">
            Terms
          </Link>{" "}
          &amp;{" "}
          <Link to="/support" className="underline hover:text-primary">
            Privacy
          </Link>
          .
        </p>
      </section>
    </PageShell>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
  defaultValue,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  defaultValue?: string;
}) {
  return (
    <div>
      <label className="text-xs font-medium text-foreground">{label}</label>
      <input
        name={name}
        type={type}
        required={required}
        defaultValue={defaultValue}
        autoComplete={name}
        className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
      />
    </div>
  );
}
