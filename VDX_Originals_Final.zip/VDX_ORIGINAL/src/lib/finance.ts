import { supabase } from "@/integrations/supabase/client";

/** Mandatory re-authentication before any Super Admin sensitive write (e.g. role changes). */
export async function confirmSuperAdminPassword(password: string): Promise<boolean> {
  const { data: userData } = await supabase.auth.getUser();
  const email = userData.user?.email;
  if (!email || !password) return false;
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  return !error;
}
