export type VariantGroups = Record<string, string[]>;

/**
 * Normalizes the products.variants jsonb column into named option groups.
 * Accepts: {"size":["S","M"],"color":["red"]} | ["S","M"] | null
 */
export function parseVariantGroups(raw: unknown): VariantGroups {
  if (!raw) return {};
  if (Array.isArray(raw)) {
    const opts = raw.map((v) => String(v).trim()).filter(Boolean);
    return opts.length ? { Option: opts } : {};
  }
  if (typeof raw === "object") {
    const out: VariantGroups = {};
    for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
      const opts = (Array.isArray(v) ? v : [v]).map((x) => String(x).trim()).filter(Boolean);
      if (opts.length) out[k] = opts;
    }
    return out;
  }
  return {};
}

/** "Size: S · Color: red" style summary for cart/order lines. */
export function variantSummary(selection: Record<string, string>): string | null {
  const parts = Object.entries(selection)
    .filter(([, v]) => v)
    .map(([k, v]) => `${k}: ${v}`);
  return parts.length ? parts.join(" · ") : null;
}
