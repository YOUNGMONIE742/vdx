import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export type AppRole = "customer" | "vendor" | "admin" | "super_admin";

export const SUPER_ADMIN_EMAILS = [
  "bhabeeb742@gmail.com",
  "vdxoriginals@gmail.com",
];

type Profile = {
  id: string;
  email: string;
  full_name: string | null;
  username: string | null;
  phone: string | null;
  avatar_url: string | null;
  is_active: boolean;
};

type AuthCtx = {
  loading: boolean;
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  roles: AppRole[];
  primaryRole: AppRole | null;
  isSuperAdminEmail: boolean;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
};

const Ctx = createContext<AuthCtx | null>(null);

function rolePriority(r: AppRole): number {
  return { super_admin: 0, admin: 1, vendor: 2, customer: 3 }[r];
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);

  async function hydrate(s: Session | null) {
    if (!s) {
      setProfile(null);
      setRoles([]);
      return;
    }

    const email = s.user.email?.trim().toLowerCase() ?? "";
    const isSuper = SUPER_ADMIN_EMAILS.includes(email);

    try {
      const [{ data: p }, { data: r }] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", s.user.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", s.user.id),
      ]);

      // Disabled customer/admin accounts are blocked at the application boundary.
      if (p && p.is_active === false && !isSuper) {
        await supabase.auth.signOut({ scope: "local" });
        setProfile(null);
        setRoles([]);
        return;
      }

      // Safety net: if the profile row is missing, create it in Supabase
      if (!p) {
        const meta = s.user.user_metadata ?? {};
        const fallbackName =
          (meta.full_name as string) ??
          (meta.name as string) ??
          (s.user.email ? s.user.email.split("@")[0] : null);
        const fallbackUsername =
          (meta.username as string) ??
          (s.user.email ? s.user.email.split("@")[0].replace(/[^a-zA-Z0-9_.]/g, "") : null);

        try {
          await supabase.from("profiles").upsert(
            {
              id: s.user.id,
              email: s.user.email ?? "",
              full_name: fallbackName,
              username: fallbackUsername,
              phone: (meta.phone as string) ?? null,
            } as Database["public"]["Tables"]["profiles"]["Insert"],
            { onConflict: "id", ignoreDuplicates: true },
          );
        } catch {
          // Continue gracefully if upsert fails
        }

        const { data: p2 } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", s.user.id)
          .maybeSingle();

        setProfile(
          (p2 as Profile) ?? {
            id: s.user.id,
            email: s.user.email ?? "",
            full_name: fallbackName,
            username: fallbackUsername,
            phone: null,
            avatar_url: (meta.avatar_url as string) ?? null,
            is_active: true,
          },
        );
      } else {
        setProfile(p as Profile);
      }

      let userRoles = ((r as Array<{ role: AppRole }>) ?? []).map((row) => row.role);
      // Strictly isolate super_admin: only the two designated emails may ever hold super_admin
      if (!isSuper) {
        userRoles = userRoles.filter((role) => role !== "super_admin");
      }
      if (userRoles.length === 0 && !isSuper) {
        userRoles = ["customer"];
      }
      if (isSuper && !userRoles.includes("super_admin")) {
        userRoles = ["super_admin", ...userRoles];
        void supabase
          .from("user_roles")
          .upsert(
            { user_id: s.user.id, role: "super_admin" },
            { onConflict: "user_id,role", ignoreDuplicates: true },
          );
      }
      setRoles(userRoles);
    } catch (err) {
      console.warn("[auth-context] hydrate warning:", err);
      // Ensure user is never locked out of basic authenticated state
      const fallbackRoles: AppRole[] = isSuper ? ["super_admin"] : ["customer"];
      setRoles(fallbackRoles);
      setProfile(
        (prev) =>
          prev ?? {
            id: s.user.id,
            email: s.user.email ?? "",
            full_name:
              (s.user.user_metadata?.full_name as string) ??
              (s.user.email ? s.user.email.split("@")[0] : "User"),
            username: s.user.email ? s.user.email.split("@")[0] : "user",
            phone: null,
            avatar_url: (s.user.user_metadata?.avatar_url as string) ?? null,
            is_active: true,
          },
      );
    }
  }

  useEffect(() => {
    let mounted = true;

    // Purge any legacy unverified mock admin sessions
    if (typeof window !== "undefined") {
      localStorage.removeItem("ww_admin_session");
    }

    supabase.auth.getSession().then(async ({ data, error }) => {
      if (!mounted) return;
      if (error) console.warn("[auth-context] getSession warning:", error.message);
      setSession(data.session);
      await hydrate(data.session);
      if (mounted) setLoading(false);
    }).catch((error) => {
      console.error("[auth-context] session initialization failed:", error);
      if (mounted) setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange(async (event, s) => {
      if (!mounted) return;
      setSession(s);
      if (
        event === "SIGNED_IN" ||
        event === "SIGNED_OUT" ||
        event === "USER_UPDATED" ||
        event === "INITIAL_SESSION" ||
        event === "TOKEN_REFRESHED"
      ) {
        // Do not await Supabase reads/writes inside onAuthStateChange.
        // Deferring hydration prevents auth event deadlocks and makes sign-in reliable.
        window.setTimeout(() => {
          if (mounted) void hydrate(s);
        }, 0);
      }
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const isSuperAdminEmail =
    !!session?.user.email && SUPER_ADMIN_EMAILS.includes(session.user.email.trim().toLowerCase());
  const cleanRoles: AppRole[] = isSuperAdminEmail
    ? roles.includes("super_admin")
      ? roles
      : ["super_admin", ...roles]
    : roles.filter((r) => r !== "super_admin");
  const sortedRoles = [...cleanRoles].sort((a, b) => rolePriority(a) - rolePriority(b));
  const primaryRole: AppRole | null = session
    ? isSuperAdminEmail
      ? "super_admin"
      : (sortedRoles[0] ?? "customer")
    : null;

  const value: AuthCtx = {
    loading,
    session,
    user: session?.user ?? null,
    profile,
    roles: cleanRoles,
    primaryRole,
    isSuperAdminEmail,
    signOut: async () => {
      if (typeof window !== "undefined") {
        localStorage.removeItem("ww_admin_session");
      }
      await supabase.auth.signOut();
      setSession(null);
      setProfile(null);
      setRoles([]);
    },
    refresh: async () => hydrate(session),
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside <AuthProvider>");
  return v;
}

export function dashboardPathForRole(role: AppRole | null): string {
  return "/dashboard";
}
