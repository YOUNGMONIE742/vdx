# VDX Originals — audit fixes

Every item below was a live-breaking bug found by cross-checking the frontend
against the actual Supabase schema. Database changes are already applied to the
live project and are mirrored in `supabase/migrations/` so a fresh
`supabase db push` reproduces them.

## Database (applied live)

| Fix | Broke |
| --- | --- |
| Created `notifications`, `announcements`, `notification_preferences` | Notification bell, `/notifications`, Admin → Announcements, Settings → notification preferences — all failed with "relation does not exist" |
| Added `order_items.sold_by_type`, `order_items.vendor_id` | **Every checkout**: the order row was created, the items insert then failed, leaving an orphaned order |
| Added `products.decline_reason` | Admin → Products showed "No products" in every tab; Decline always errored |
| Added `profiles.username`; `handle_new_user` now populates it | Saving the profile in Settings failed silently |
| Created `products_availability(uuid[])` RPC | Cart protection (dropping unavailable items) was silently dead |
| `products.status` default `'active'` → `'draft'` | A product created without an explicit status was invisible on every screen |
| Replaced the `USING (true)` products SELECT policy with scoped policies | Draft, pending and declined products were readable by anonymous visitors |
| Added storage policies for the `site-assets` bucket | Admin logo upload and logo rendering were both denied |

## Frontend

- `product.$slug.tsx`, `orders.tsx`, `admin.orders.tsx` — removed dead
  `vendors(...)` joins. No `vendors` table exists, so PostgREST rejected the
  whole query: the product detail page, the customer orders list and the admin
  orders list all loaded nothing. The vendor name is hardcoded to
  `VDX Originals` anyway (single-store app).
- `shop.tsx`, `admin.orders.tsx` — removed the matching dead TypeScript fields.
- `products.new.tsx` — sent `null` for `tags`, `variants` and
  `shipping_fee_ngn`, all `NOT NULL` with defaults, so publishing a product
  without those fields hit a not-null violation. Now sends `[]`, `[]` and `0`.
- `admin.users.tsx` — `if (profileError) throw error` threw the wrong error
  object.

## Verified clean

- Every column in all 74 Supabase calls (`select`, `eq`, `order`, `in`, …)
  checked against the live schema — no mismatches remain.
- Every PostgREST embed is backed by a real foreign key.
- RLS policies cover every read and write each page performs.
- `wallets` and `vendor-applications` admin pages are redirect-only stubs with
  no dead queries.
- `track-order.tsx` intentionally only resolves a signed-in customer's own
  order, matching its own error copy — left as designed.
