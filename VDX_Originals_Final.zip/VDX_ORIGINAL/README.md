# VDX Originals

A single-store fashion e-commerce website for VDX Originals, adapted from the existing Welcome Wagon codebase.

## Business details
- Email: vdxoriginals@gmail.com
- Phone: 07070273404
- WhatsApp: 09115066738
- Address: Best Plaza, Kachia Road, Sabo, Kaduna

## Architecture
- React + TypeScript
- TanStack Router / TanStack Start
- Supabase Auth, Postgres and Storage
- Tailwind CSS
- Netlify deployment configuration

## Roles
Customer → Admin → Super Admin.

Only these two emails are protected Super Admin accounts:
- bhabeeb742@gmail.com
- vdxoriginals@gmail.com

Super Admin can grant/revoke the Admin role. Protected Super Admin accounts cannot be demoted through the application.

## VDX Originals storefront
Public visitors can browse the store without signing in. Customers sign in/register before checkout.

Core flow:
1. Browse collections
2. Search/filter products
3. Open a product and select variants/size
4. Add to bag
5. Sign in or register
6. Checkout with delivery details
7. Pay by manual bank transfer
8. Upload payment proof/reference
9. Follow order status

## Admin
Admins manage day-to-day products, orders, payments and customer messages.

Super Admin additionally manages users/roles, categories, store settings, analytics, announcements and protected payment settings.

## Important note about the legacy database
The original project was a multi-vendor marketplace. Legacy vendor-related database tables/migrations remain in the repository for migration compatibility, but vendor storefront/application/payout flows are no longer exposed by the VDX Originals UI.

Do not re-enable vendor features unless the business requirements change.

## Environment
Copy `.env.example` to `.env` and add your own Supabase values. The distributed project intentionally does **not** include the original `.env` or any private keys.

## Development
```bash
npm install
npm run dev
```

Production build:
```bash
npm run build
```

Netlify configuration is included in `netlify.toml`.
