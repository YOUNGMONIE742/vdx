# VDX Originals migration notes

This version is a direct adaptation of the supplied Company Wagon / Welcome Wagon codebase.

## Completed in this code package

- Rebranded visible storefront and metadata to VDX Originals.
- Replaced the public landing page with a minimal black/white fashion presentation.
- Removed the floating AI assistant/tip popups.
- Replaced the old logo image usage with a safe VDX text mark so there is no broken legacy logo.
- Updated store contact details:
  - vdxoriginals@gmail.com
  - 07070273404
  - WhatsApp 09115066738
  - Best Plaza, Kachia Road, Sabo, Kaduna
- Removed vendor marketplace navigation and converted vendor-only public/admin entry points to redirects.
- Removed vendor wallet/store dashboard entry points from the main customer/admin experience.
- Kept the existing customer, cart, checkout, payment, order, product, category, notification and role architecture.
- Kept Admin role assignment and added Super Admin password re-verification before granting/revoking Admin.
- Restricted Super Admin email allow-list to:
  - bhabeeb742@gmail.com
  - vdxoriginals@gmail.com
- Added a Supabase migration that removes legacy Super Admin assignments from the old marketplace addresses and grants the protected role to the two VDX Originals addresses when their profiles exist.
- Removed the private `.env` file from the distributed package. Use `.env.example`.

## Important database note

The original database has legacy vendor-related tables and migrations. They are intentionally retained for migration compatibility rather than being destructively dropped. The VDX Originals UI no longer exposes vendor marketplace workflows.

If the old Supabase project is reused, apply the new VDX migration after the existing migrations.

## Next recommended check

Run:

```bash
npm install
npm run build
```

Then test:
- registration/login
- forgot password
- customer browsing/cart/checkout
- payment proof upload
- order tracking/status
- Admin access
- Super Admin access
- Admin role assignment
- mobile layout
- Netlify deployment

The original `.env` was deliberately excluded because it may contain private credentials.
