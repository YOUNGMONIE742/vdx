# Deploying VDX Originals to Netlify

This replaces the previous `DEPLOY_NOW.md` / `NETLIFY_DEPLOYMENT.md`, which
described an older codebase (a different Supabase project and a Groq-powered
AI assistant that no longer exists in this app) and contained live API keys.
Rotate any key you see in old chat logs or screenshots referencing those
files — they should be treated as compromised.

## 1. Environment variables

Set these in **Netlify → Site settings → Build & deploy → Environment**:

| Key | Value |
| --- | --- |
| `VITE_SUPABASE_URL` | `https://jwgkiuyaaaunkxfzkbiq.supabase.co` |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | your Supabase **publishable** key (Supabase Dashboard → Settings → API) |

Both are safe to expose in the browser. **Never** put a `sb_secret_...` /
service-role key in Netlify env vars or anywhere in this repo — the app
never needs one client-side.

## 2. Build settings

`netlify.toml` already pins the correct settings for this TanStack Start +
Nitro app, so Netlify's UI settings don't need to override them:

- Build command: `npm run build:netlify`
- Publish directory: `dist`
- Functions directory: `.netlify/functions-internal`
- Node version: 20

## 3. Supabase setup

Apply every file in `supabase/migrations/` (in filename/timestamp order) to
your Supabase project, either via the Supabase CLI (`supabase db push`) or by
pasting them into the SQL editor in order. This provisions the schema, RLS
policies, and the four storage buckets the app uses: `product-media`,
`store-logos`, `site-assets`, `payment-proofs`.

## 4. Test after deploy

- Register a new account, confirm you land on `/dashboard`.
- Sign in as `bhabeeb742@gmail.com` or `vdxoriginals@gmail.com` and confirm
  you see the Super Admin console at `/admin`.
- Add a product with images + a video as an Admin, confirm it appears on
  `/shop`.
- Add an item to cart, check out, upload a payment proof, confirm the order
  appears under `/admin/orders`.
- Submit the contact/support form and confirm it appears under
  `/admin/feedback` ("Messages").

## Rollback

Netlify keeps deployment history — from **Deployments**, pick any previous
build and click **Publish deploy** to revert instantly.
