DROP FUNCTION IF EXISTS private.approve_vendor_application(uuid, uuid);

CREATE OR REPLACE FUNCTION public.approve_vendor_application(p_app_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path TO 'public'
AS $function$
DECLARE
  app public.vendor_applications%ROWTYPE;
  v_id uuid;
  v_slug text;
BEGIN
  IF NOT private.has_role(auth.uid(), 'super_admin') THEN
    RAISE EXCEPTION 'Only a super admin can approve vendor applications';
  END IF;

  SELECT * INTO app FROM public.vendor_applications WHERE id = p_app_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Application not found';
  END IF;

  SELECT id INTO v_id FROM public.vendors WHERE user_id = app.user_id;
  IF v_id IS NULL THEN
    v_slug := regexp_replace(lower(coalesce(app.store_name, 'store')), '[^a-z0-9]+', '-', 'g');
    v_slug := trim(both '-' from v_slug);
    IF v_slug = '' THEN v_slug := 'store'; END IF;
    IF EXISTS (SELECT 1 FROM public.vendors WHERE slug = v_slug) THEN
      v_slug := v_slug || '-' || substr(md5(random()::text), 1, 4);
    END IF;
    INSERT INTO public.vendors (user_id, store_name, slug, description, logo_url, contact_phone, contact_email, is_active)
    VALUES (app.user_id, app.store_name, v_slug, app.store_description, app.store_logo_url, app.contact_phone, app.contact_email, true)
    RETURNING id INTO v_id;
  ELSE
    UPDATE public.vendors SET is_active = true WHERE id = v_id;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (app.user_id, 'vendor')
  ON CONFLICT (user_id, role) DO NOTHING;

  UPDATE public.vendor_applications
     SET status = 'approved',
         payment_verified = true,
         reviewed_by = auth.uid(),
         reviewed_at = now()
   WHERE id = p_app_id;

  RETURN v_id;
END; $function$;

REVOKE ALL ON FUNCTION public.approve_vendor_application(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.approve_vendor_application(uuid) TO authenticated, service_role;