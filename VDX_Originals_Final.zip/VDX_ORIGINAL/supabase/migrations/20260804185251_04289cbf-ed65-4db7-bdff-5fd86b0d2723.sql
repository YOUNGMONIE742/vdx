
-- ============ SETTINGS ============
INSERT INTO public.settings(key, value, is_public) VALUES
  ('refund_protection_days', '7'::jsonb, false),
  ('payout_schedule', '{"mode":"always"}'::jsonb, false)
ON CONFLICT (key) DO NOTHING;

-- ============ TABLES ============
CREATE TABLE public.vendor_bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_id uuid NOT NULL UNIQUE REFERENCES public.vendors(id) ON DELETE CASCADE,
  bank_name text NOT NULL,
  account_name text NOT NULL,
  account_number text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.vendor_bank_accounts TO authenticated;
GRANT ALL ON public.vendor_bank_accounts TO service_role;
ALTER TABLE public.vendor_bank_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY vba_vendor_manage ON public.vendor_bank_accounts FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = vendor_id AND v.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = vendor_id AND v.user_id = auth.uid()));
CREATE POLICY vba_staff_read ON public.vendor_bank_accounts FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'super_admin') OR private.has_role(auth.uid(),'admin'));
CREATE TRIGGER vba_updated_at BEFORE UPDATE ON public.vendor_bank_accounts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.withdrawals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference text NOT NULL UNIQUE DEFAULT ('WD-' || upper(substr(md5(random()::text),1,8))),
  vendor_id uuid NOT NULL REFERENCES public.vendors(id) ON DELETE CASCADE,
  amount_ngn numeric(14,2) NOT NULL CHECK (amount_ngn > 0),
  paid_ngn numeric(14,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  note text,
  decision_reason text,
  reviewed_by uuid REFERENCES auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.withdrawals TO authenticated;
GRANT ALL ON public.withdrawals TO service_role;
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
CREATE POLICY wd_vendor_read ON public.withdrawals FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = vendor_id AND v.user_id = auth.uid()));
CREATE POLICY wd_staff_read ON public.withdrawals FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'super_admin') OR private.has_role(auth.uid(),'admin'));
CREATE TRIGGER wd_updated_at BEFORE UPDATE ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.withdrawal_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  withdrawal_id uuid NOT NULL REFERENCES public.withdrawals(id) ON DELETE CASCADE,
  vendor_id uuid NOT NULL REFERENCES public.vendors(id) ON DELETE CASCADE,
  amount_ngn numeric(14,2) NOT NULL CHECK (amount_ngn > 0),
  proof_url text,
  paid_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.withdrawal_payments TO authenticated;
GRANT ALL ON public.withdrawal_payments TO service_role;
ALTER TABLE public.withdrawal_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY wdp_vendor_read ON public.withdrawal_payments FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = vendor_id AND v.user_id = auth.uid()));
CREATE POLICY wdp_staff_read ON public.withdrawal_payments FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'super_admin') OR private.has_role(auth.uid(),'admin'));

CREATE TABLE public.vendor_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference text NOT NULL DEFAULT ('TX-' || upper(substr(md5(random()::text),1,10))),
  vendor_id uuid NOT NULL REFERENCES public.vendors(id) ON DELETE CASCADE,
  entry_type text NOT NULL,
  description text,
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  order_item_id uuid,
  withdrawal_id uuid REFERENCES public.withdrawals(id) ON DELETE SET NULL,
  gross_ngn numeric(14,2) NOT NULL DEFAULT 0,
  commission_ngn numeric(14,2) NOT NULL DEFAULT 0,
  amount_ngn numeric(14,2) NOT NULL DEFAULT 0,
  commission_percent numeric(5,2),
  available_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX vendor_ledger_vendor_idx ON public.vendor_ledger(vendor_id, created_at DESC);
GRANT SELECT ON public.vendor_ledger TO authenticated;
GRANT ALL ON public.vendor_ledger TO service_role;
ALTER TABLE public.vendor_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY vl_vendor_read ON public.vendor_ledger FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = vendor_id AND v.user_id = auth.uid()));
CREATE POLICY vl_staff_read ON public.vendor_ledger FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'super_admin') OR private.has_role(auth.uid(),'admin'));

CREATE TABLE public.financial_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid REFERENCES auth.users(id),
  actor_role text,
  action text NOT NULL,
  entity_type text,
  entity_id uuid,
  vendor_id uuid REFERENCES public.vendors(id) ON DELETE SET NULL,
  previous_value jsonb,
  new_value jsonb,
  ip_address text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.financial_audit_log TO authenticated;
GRANT ALL ON public.financial_audit_log TO service_role;
ALTER TABLE public.financial_audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY fal_staff_read ON public.financial_audit_log FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(),'super_admin') OR private.has_role(auth.uid(),'admin'));
CREATE POLICY fal_vendor_read ON public.financial_audit_log FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = vendor_id AND v.user_id = auth.uid()));

CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  body text NOT NULL,
  kind text NOT NULL DEFAULT 'finance',
  link text,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON public.notifications(user_id, created_at DESC);
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY notif_own_read ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY notif_own_update ON public.notifications FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ============ HELPERS ============
CREATE OR REPLACE FUNCTION private.commission_percent_for(_vendor uuid)
RETURNS numeric LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(
    (SELECT v.commission_percent FROM public.vendors v WHERE v.id = _vendor),
    (SELECT (value #>> '{}')::numeric FROM public.settings WHERE key = 'default_commission_percent'),
    0
  )
$$;

CREATE OR REPLACE FUNCTION private.refund_protection_days()
RETURNS numeric LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE((SELECT (value #>> '{}')::numeric FROM public.settings WHERE key = 'refund_protection_days'), 0)
$$;

CREATE OR REPLACE FUNCTION private.log_financial(
  _action text, _entity_type text, _entity_id uuid, _vendor uuid, _prev jsonb, _new jsonb
) RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  INSERT INTO public.financial_audit_log(actor_id, actor_role, action, entity_type, entity_id, vendor_id, previous_value, new_value)
  VALUES (auth.uid(), private.current_user_role()::text, _action, _entity_type, _entity_id, _vendor, _prev, _new);
$$;

CREATE OR REPLACE FUNCTION private.notify_user(_user uuid, _title text, _body text, _link text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  INSERT INTO public.notifications(user_id, title, body, link) VALUES (_user, _title, _body, _link);
$$;

CREATE OR REPLACE FUNCTION private.payout_window_open()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE
  cfg jsonb;
  mode text;
  today date := (now() AT TIME ZONE 'Africa/Lagos')::date;
BEGIN
  SELECT value INTO cfg FROM public.settings WHERE key = 'payout_schedule';
  mode := COALESCE(cfg->>'mode','always');
  IF mode = 'always' THEN RETURN true; END IF;
  IF mode = 'weekly' THEN
    RETURN EXTRACT(ISODOW FROM today)::int = COALESCE((cfg->>'weekday')::int, 5);
  END IF;
  IF mode = 'monthly' THEN
    RETURN EXTRACT(DAY FROM today)::int = COALESCE((cfg->>'day1')::int, 28);
  END IF;
  IF mode = 'twice_monthly' THEN
    RETURN EXTRACT(DAY FROM today)::int IN (COALESCE((cfg->>'day1')::int, 15), COALESCE((cfg->>'day2')::int, 28));
  END IF;
  IF mode = 'custom' THEN
    RETURN EXTRACT(DAY FROM today)::int = ANY (
      SELECT ARRAY(SELECT jsonb_array_elements_text(COALESCE(cfg->'days','[]'::jsonb))::int)
    );
  END IF;
  RETURN true;
END; $$;

CREATE OR REPLACE FUNCTION private.payout_window_label()
RETURNS text LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE cfg jsonb; mode text;
BEGIN
  SELECT value INTO cfg FROM public.settings WHERE key = 'payout_schedule';
  mode := COALESCE(cfg->>'mode','always');
  RETURN CASE mode
    WHEN 'always' THEN 'Withdrawals are accepted at any time'
    WHEN 'weekly' THEN 'Withdrawals are accepted weekly (day ' || COALESCE(cfg->>'weekday','5') || ' of the week)'
    WHEN 'monthly' THEN 'Withdrawals are accepted on day ' || COALESCE(cfg->>'day1','28') || ' of each month'
    WHEN 'twice_monthly' THEN 'Withdrawals are accepted on days ' || COALESCE(cfg->>'day1','15') || ' and ' || COALESCE(cfg->>'day2','28') || ' of each month'
    ELSE 'Withdrawals are accepted on the configured payout days'
  END;
END; $$;

-- ============ SALE / REFUND FINANCE TRIGGER ============
CREATE OR REPLACE FUNCTION private.orders_finance_on_status_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  earned_states text[] := ARRAY['paid','processing','packed','shipped','out_for_delivery','delivered'];
  reversed_states text[] := ARRAY['cancelled','refunded','returned'];
  it record;
  pct numeric;
  comm numeric;
  hold numeric := private.refund_protection_days();
BEGIN
  IF NEW.status::text = ANY(earned_states) THEN
    FOR it IN
      SELECT oi.id, oi.vendor_id, oi.title, oi.subtotal_ngn
        FROM public.order_items oi
       WHERE oi.order_id = NEW.id AND oi.vendor_id IS NOT NULL
         AND NOT EXISTS (SELECT 1 FROM public.vendor_ledger l WHERE l.order_item_id = oi.id AND l.entry_type = 'sale')
    LOOP
      pct := private.commission_percent_for(it.vendor_id);
      comm := round(it.subtotal_ngn * pct / 100.0, 2);
      INSERT INTO public.vendor_ledger(vendor_id, entry_type, description, order_id, order_item_id,
        gross_ngn, commission_ngn, amount_ngn, commission_percent, available_at)
      VALUES (it.vendor_id, 'sale', 'Sale · ' || NEW.order_number || ' · ' || it.title, NEW.id, it.id,
        it.subtotal_ngn, comm, it.subtotal_ngn - comm, pct, now() + (hold || ' days')::interval);
    END LOOP;
  END IF;

  IF NEW.status::text = ANY(reversed_states) THEN
    FOR it IN
      SELECT l.* FROM public.vendor_ledger l
       WHERE l.order_id = NEW.id AND l.entry_type = 'sale'
         AND NOT EXISTS (SELECT 1 FROM public.vendor_ledger r WHERE r.order_item_id = l.order_item_id AND r.entry_type = 'refund')
    LOOP
      INSERT INTO public.vendor_ledger(vendor_id, entry_type, description, order_id, order_item_id,
        gross_ngn, commission_ngn, amount_ngn, commission_percent, available_at)
      VALUES (it.vendor_id, 'refund', 'Refund reversal · ' || NEW.order_number, NEW.id, it.order_item_id,
        -it.gross_ngn, -it.commission_ngn, -it.amount_ngn, it.commission_percent, now());
      PERFORM private.log_financial('refund_reversal','order',NEW.id,it.vendor_id,
        to_jsonb(it.amount_ngn), to_jsonb(-it.amount_ngn));
    END LOOP;
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER orders_finance_on_status_change
AFTER UPDATE OF status ON public.orders
FOR EACH ROW EXECUTE FUNCTION private.orders_finance_on_status_change();

-- ============ WALLET SUMMARY ============
CREATE OR REPLACE FUNCTION public.vendor_wallets()
RETURNS TABLE (
  vendor_id uuid, store_name text, is_active boolean, commission_percent numeric,
  gross_sales numeric, commission_total numeric, refunds_total numeric,
  pending_balance numeric, available_balance numeric, wallet_balance numeric,
  paid_out numeric, withdrawals_requested numeric, pending_withdrawals numeric
) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  RETURN QUERY
  SELECT v.id, v.store_name, v.is_active, private.commission_percent_for(v.id),
    COALESCE(l.gross,0), COALESCE(l.comm,0), COALESCE(l.refunds,0),
    COALESCE(l.pending,0), COALESCE(l.available,0) - COALESCE(p.paid,0),
    COALESCE(l.pending,0) + COALESCE(l.available,0) - COALESCE(p.paid,0),
    COALESCE(p.paid,0), COALESCE(w.requested,0), COALESCE(w.pending_req,0)
  FROM public.vendors v
  LEFT JOIN LATERAL (
    SELECT
      SUM(gross_ngn) FILTER (WHERE entry_type='sale') AS gross,
      SUM(commission_ngn) AS comm,
      -SUM(amount_ngn) FILTER (WHERE entry_type='refund') AS refunds,
      SUM(amount_ngn) FILTER (WHERE available_at > now() AND entry_type IN ('sale','refund','adjustment')) AS pending,
      SUM(amount_ngn) FILTER (WHERE available_at <= now() AND entry_type IN ('sale','refund','adjustment')) AS available
    FROM public.vendor_ledger WHERE vendor_id = v.id
  ) l ON true
  LEFT JOIN LATERAL (
    SELECT SUM(amount_ngn) AS paid FROM public.withdrawal_payments WHERE vendor_id = v.id
  ) p ON true
  LEFT JOIN LATERAL (
    SELECT SUM(amount_ngn) AS requested,
           SUM(amount_ngn) FILTER (WHERE status IN ('pending','approved','partially_paid')) AS pending_req
    FROM public.withdrawals WHERE vendor_id = v.id
  ) w ON true
  WHERE private.has_role(auth.uid(),'super_admin')
     OR private.has_role(auth.uid(),'admin')
     OR v.user_id = auth.uid();
END; $$;
REVOKE ALL ON FUNCTION public.vendor_wallets() FROM public, anon;
GRANT EXECUTE ON FUNCTION public.vendor_wallets() TO authenticated, service_role;

-- ============ WITHDRAWAL RPCs ============
CREATE OR REPLACE FUNCTION public.request_withdrawal(p_amount numeric, p_note text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v public.vendors%ROWTYPE; avail numeric; wid uuid; admin_row record;
BEGIN
  SELECT * INTO v FROM public.vendors WHERE user_id = auth.uid();
  IF v.id IS NULL THEN RAISE EXCEPTION 'Only a vendor can request a withdrawal'; END IF;
  IF NOT v.is_active THEN RAISE EXCEPTION 'Your store is not active'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.vendor_bank_accounts WHERE vendor_id = v.id) THEN
    RAISE EXCEPTION 'Add your bank account details before requesting a withdrawal';
  END IF;
  IF NOT private.payout_window_open() THEN
    RAISE EXCEPTION 'Withdrawal rejected: %', private.payout_window_label();
  END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN RAISE EXCEPTION 'Enter a valid amount'; END IF;
  IF EXISTS (SELECT 1 FROM public.withdrawals WHERE vendor_id = v.id AND status IN ('pending','approved','partially_paid')) THEN
    RAISE EXCEPTION 'You already have a withdrawal in progress';
  END IF;
  SELECT available_balance INTO avail FROM public.vendor_wallets() WHERE vendor_id = v.id;
  IF p_amount > COALESCE(avail,0) THEN RAISE EXCEPTION 'Amount exceeds your available balance'; END IF;

  INSERT INTO public.withdrawals(vendor_id, amount_ngn, note) VALUES (v.id, p_amount, p_note) RETURNING id INTO wid;
  PERFORM private.log_financial('withdrawal_requested','withdrawal',wid,v.id,NULL,jsonb_build_object('amount',p_amount));
  PERFORM private.notify_user(v.user_id,'Withdrawal submitted',
    'Your withdrawal request of NGN ' || p_amount::text || ' has been submitted for review.', '/wallet');
  FOR admin_row IN SELECT user_id FROM public.user_roles WHERE role = 'super_admin' LOOP
    PERFORM private.notify_user(admin_row.user_id,'New withdrawal request',
      v.store_name || ' requested NGN ' || p_amount::text || '.', '/admin/wallets');
  END LOOP;
  RETURN wid;
END; $$;
REVOKE ALL ON FUNCTION public.request_withdrawal(numeric, text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.request_withdrawal(numeric, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.cancel_withdrawal(p_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w public.withdrawals%ROWTYPE;
BEGIN
  SELECT * INTO w FROM public.withdrawals WHERE id = p_id;
  IF w.id IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = w.vendor_id AND v.user_id = auth.uid()) THEN
    RAISE EXCEPTION 'Not allowed';
  END IF;
  IF w.status <> 'pending' THEN RAISE EXCEPTION 'Only a pending request can be cancelled'; END IF;
  UPDATE public.withdrawals SET status = 'cancelled' WHERE id = p_id;
  PERFORM private.log_financial('withdrawal_cancelled','withdrawal',p_id,w.vendor_id,to_jsonb(w.status),to_jsonb('cancelled'::text));
END; $$;
REVOKE ALL ON FUNCTION public.cancel_withdrawal(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.cancel_withdrawal(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.review_withdrawal(p_id uuid, p_approve boolean, p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w public.withdrawals%ROWTYPE; v public.vendors%ROWTYPE;
BEGIN
  IF NOT private.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can review withdrawals'; END IF;
  SELECT * INTO w FROM public.withdrawals WHERE id = p_id;
  IF w.id IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  IF w.status NOT IN ('pending') THEN RAISE EXCEPTION 'This request has already been reviewed'; END IF;
  SELECT * INTO v FROM public.vendors WHERE id = w.vendor_id;
  UPDATE public.withdrawals
     SET status = CASE WHEN p_approve THEN 'approved' ELSE 'rejected' END,
         decision_reason = p_reason, reviewed_by = auth.uid(), reviewed_at = now()
   WHERE id = p_id;
  PERFORM private.log_financial(CASE WHEN p_approve THEN 'withdrawal_approved' ELSE 'withdrawal_rejected' END,
    'withdrawal',p_id,w.vendor_id,to_jsonb(w.status),to_jsonb(CASE WHEN p_approve THEN 'approved' ELSE 'rejected' END));
  PERFORM private.notify_user(v.user_id,
    CASE WHEN p_approve THEN 'Withdrawal approved' ELSE 'Withdrawal rejected' END,
    CASE WHEN p_approve THEN 'Your withdrawal of NGN ' || w.amount_ngn::text || ' was approved and is queued for payment.'
         ELSE 'Your withdrawal of NGN ' || w.amount_ngn::text || ' was rejected. ' || COALESCE(p_reason,'') END,
    '/wallet');
END; $$;
REVOKE ALL ON FUNCTION public.review_withdrawal(uuid, boolean, text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.review_withdrawal(uuid, boolean, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.record_withdrawal_payment(p_id uuid, p_amount numeric, p_proof_url text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w public.withdrawals%ROWTYPE; v public.vendors%ROWTYPE; pid uuid; new_paid numeric; new_status text;
BEGIN
  IF NOT private.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can pay withdrawals'; END IF;
  SELECT * INTO w FROM public.withdrawals WHERE id = p_id FOR UPDATE;
  IF w.id IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;
  IF w.status NOT IN ('approved','partially_paid') THEN RAISE EXCEPTION 'Approve the request before paying'; END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN RAISE EXCEPTION 'Enter a valid payment amount'; END IF;
  IF p_amount > (w.amount_ngn - w.paid_ngn) THEN RAISE EXCEPTION 'Payment exceeds the outstanding request amount'; END IF;
  IF p_proof_url IS NULL OR length(trim(p_proof_url)) = 0 THEN RAISE EXCEPTION 'Upload a payment proof image'; END IF;
  SELECT * INTO v FROM public.vendors WHERE id = w.vendor_id;

  INSERT INTO public.withdrawal_payments(withdrawal_id, vendor_id, amount_ngn, proof_url, paid_by)
  VALUES (p_id, w.vendor_id, p_amount, p_proof_url, auth.uid()) RETURNING id INTO pid;

  INSERT INTO public.vendor_ledger(vendor_id, entry_type, description, withdrawal_id, amount_ngn, available_at)
  VALUES (w.vendor_id, 'payout', 'Payout · ' || w.reference, p_id, -p_amount, now());

  new_paid := w.paid_ngn + p_amount;
  new_status := CASE WHEN new_paid >= w.amount_ngn THEN 'paid' ELSE 'partially_paid' END;
  UPDATE public.withdrawals SET paid_ngn = new_paid, status = new_status WHERE id = p_id;

  PERFORM private.log_financial('withdrawal_payment','withdrawal',p_id,w.vendor_id,
    jsonb_build_object('paid',w.paid_ngn,'status',w.status),
    jsonb_build_object('paid',new_paid,'status',new_status,'proof',p_proof_url));
  PERFORM private.notify_user(v.user_id,
    CASE WHEN new_status = 'paid' THEN 'Withdrawal paid' ELSE 'Partial payment received' END,
    'NGN ' || p_amount::text || ' was paid for withdrawal ' || w.reference || '.', '/wallet');
  RETURN pid;
END; $$;
REVOKE ALL ON FUNCTION public.record_withdrawal_payment(uuid, numeric, text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.record_withdrawal_payment(uuid, numeric, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.set_vendor_commission(p_vendor uuid, p_percent numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE prev numeric;
BEGIN
  IF NOT private.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can change commission'; END IF;
  IF p_percent IS NOT NULL AND (p_percent < 0 OR p_percent > 100) THEN RAISE EXCEPTION 'Commission must be between 0 and 100'; END IF;
  SELECT commission_percent INTO prev FROM public.vendors WHERE id = p_vendor;
  UPDATE public.vendors SET commission_percent = p_percent WHERE id = p_vendor;
  PERFORM private.log_financial('commission_changed','vendor',p_vendor,p_vendor,to_jsonb(prev),to_jsonb(p_percent));
END; $$;
REVOKE ALL ON FUNCTION public.set_vendor_commission(uuid, numeric) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.set_vendor_commission(uuid, numeric) TO authenticated;

CREATE OR REPLACE FUNCTION public.set_finance_setting(p_key text, p_value jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE prev jsonb;
BEGIN
  IF NOT private.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can change finance settings'; END IF;
  IF p_key NOT IN ('default_commission_percent','refund_protection_days','payout_schedule') THEN
    RAISE EXCEPTION 'Unsupported setting';
  END IF;
  SELECT value INTO prev FROM public.settings WHERE key = p_key;
  INSERT INTO public.settings(key, value, is_public)
  VALUES (p_key, p_value, p_key = 'default_commission_percent')
  ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now();
  PERFORM private.log_financial('setting_changed','setting',NULL,NULL,prev,p_value);
END; $$;
REVOKE ALL ON FUNCTION public.set_finance_setting(text, jsonb) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.set_finance_setting(text, jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.finance_settings()
RETURNS TABLE (key text, value jsonb) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT (private.has_role(auth.uid(),'super_admin') OR private.has_role(auth.uid(),'admin')) THEN
    RAISE EXCEPTION 'Not allowed';
  END IF;
  RETURN QUERY SELECT s.key, s.value FROM public.settings s
   WHERE s.key IN ('default_commission_percent','refund_protection_days','payout_schedule');
END; $$;
REVOKE ALL ON FUNCTION public.finance_settings() FROM public, anon;
GRANT EXECUTE ON FUNCTION public.finance_settings() TO authenticated;
