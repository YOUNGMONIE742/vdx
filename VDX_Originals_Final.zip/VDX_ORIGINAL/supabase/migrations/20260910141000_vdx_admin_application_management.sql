-- VDX_ORIGINALS: allow customers to cancel their own pending admin request and
-- Super Admins to remove admin applications from the review queue.
GRANT DELETE ON public.admin_applications TO authenticated;

DROP POLICY IF EXISTS aa_self_delete ON public.admin_applications;
CREATE POLICY aa_self_delete ON public.admin_applications
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id AND status = 'pending');

DROP POLICY IF EXISTS aa_super_delete ON public.admin_applications;
CREATE POLICY aa_super_delete ON public.admin_applications
  FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'::public.app_role));
