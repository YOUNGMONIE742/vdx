-- Safe helper so public visibility checks no longer depend on the caller
-- having direct read access to the vendors / user_roles tables.
CREATE OR REPLACE FUNCTION private.vendor_is_active(_vendor uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.vendors v
     WHERE v.id = _vendor AND v.status = 'active' AND v.is_active = true
  )
$$;

REVOKE ALL ON FUNCTION private.vendor_is_active(uuid) FROM PUBLIC;

-- Products: approved items from active vendors are public again.
DROP POLICY IF EXISTS products_public_view_approved ON public.products;
CREATE POLICY products_public_view_approved
  ON public.products FOR SELECT
  TO anon, authenticated
  USING (
    status = 'approved'
    AND (vendor_id IS NULL OR private.vendor_is_active(vendor_id))
  );

-- Verified vendors list: definer view exposing only safe public columns.
DROP VIEW IF EXISTS public.public_vendors;
CREATE VIEW public.public_vendors AS
  SELECT v.id, v.store_name, v.slug, v.description, v.logo_url, v.banner_url,
         v.rating, v.total_sold, v.joined_at
    FROM public.vendors v
   WHERE v.status = 'active' AND v.is_active = true;

GRANT SELECT ON public.public_vendors TO anon, authenticated;