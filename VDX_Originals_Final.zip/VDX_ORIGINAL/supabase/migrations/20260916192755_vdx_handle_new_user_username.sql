-- profiles.username now exists, so the signup trigger should populate it from
-- the signup metadata (the auth form collects a username) instead of leaving
-- it null and relying on the client-side upsert fallback.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  new_role public.app_role;
  user_email text;
begin
  user_email := lower(coalesce(new.email, ''));

  if user_email in ('bhabeeb742@gmail.com', 'vdxoriginals@gmail.com') then
    new_role := 'super_admin';
  else
    new_role := 'customer';
  end if;

  insert into public.profiles (id, email, full_name, username, phone)
  values (
    new.id,
    new.email,
    coalesce(
      new.raw_user_meta_data ->> 'full_name',
      new.raw_user_meta_data ->> 'name',
      ''
    ),
    coalesce(
      nullif(new.raw_user_meta_data ->> 'username', ''),
      split_part(coalesce(new.email, 'user'), '@', 1)
    ),
    nullif(new.raw_user_meta_data ->> 'phone', '')
  )
  on conflict (id) do update
    set email = excluded.email,
        username = coalesce(public.profiles.username, excluded.username);

  insert into public.user_roles (user_id, role)
  values (new.id, new_role)
  on conflict (user_id, role) do nothing;

  return new;
end;
$$;
