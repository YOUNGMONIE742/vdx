-- 1. Bank details no longer public
UPDATE public.settings SET is_public = false WHERE key = 'bank_details';

DROP POLICY IF EXISTS settings_public_read ON public.settings;
CREATE POLICY settings_public_read ON public.settings
  FOR SELECT TO anon, authenticated
  USING (is_public = true AND key <> 'bank_details');

CREATE POLICY settings_authenticated_bank_read ON public.settings
  FOR SELECT TO authenticated
  USING (key = 'bank_details');

-- 2. Vendor role assignments no longer publicly readable
DROP POLICY IF EXISTS user_roles_public_read ON public.user_roles;
REVOKE SELECT ON public.user_roles FROM anon;

-- 3. Move approve_vendor_application out of the exposed API schema
DROP FUNCTION IF EXISTS public.approve_vendor_application(uuid);

CREATE OR REPLACE FUNCTION private.approve_vendor_application(p_app_id uuid, p_actor uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  app public.vendor_applications%ROWTYPE;
  v_id uuid;
  v_slug text;
BEGIN
  IF p_actor IS NULL OR NOT private.has_role(p_actor, 'super_admin') THEN
    RAISE EXCEPTION 'Only a super admin can approve vendor applications';
  END IF;

  SELECT * INTO app FROM public.vendor_applications WHERE id = p_app_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Application not found';
  END IF;

  SELECT id INTO v_id FROM public.vendors WHERE user_id = app.user_id;
  IF v_id IS NULL THEN
    v_slug := regexp_replace(lower(coalesce(app.store_name, 'store')), '[^a-z0-9]+', '-', 'g');
    v_slug := trim(both '-' from v_slug);
    IF v_slug = '' THEN v_slug := 'store'; END IF;
    IF EXISTS (SELECT 1 FROM public.vendors WHERE slug = v_slug) THEN
      v_slug := v_slug || '-' || substr(md5(random()::text), 1, 4);
    END IF;
    INSERT INTO public.vendors (user_id, store_name, slug, description, logo_url, contact_phone, contact_email, is_active)
    VALUES (app.user_id, app.store_name, v_slug, app.store_description, app.store_logo_url, app.contact_phone, app.contact_email, true)
    RETURNING id INTO v_id;
  ELSE
    UPDATE public.vendors SET is_active = true WHERE id = v_id;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (app.user_id, 'vendor')
  ON CONFLICT (user_id, role) DO NOTHING;

  UPDATE public.vendor_applications
     SET status = 'approved',
         payment_verified = true,
         reviewed_by = p_actor,
         reviewed_at = now()
   WHERE id = p_app_id;

  RETURN v_id;
END; $function$;

REVOKE ALL ON FUNCTION private.approve_vendor_application(uuid, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION private.approve_vendor_application(uuid, uuid) TO service_role;