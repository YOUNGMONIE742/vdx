GRANT USAGE ON SCHEMA private TO anon;
GRANT EXECUTE ON FUNCTION private.vendor_is_active(uuid) TO anon, authenticated;