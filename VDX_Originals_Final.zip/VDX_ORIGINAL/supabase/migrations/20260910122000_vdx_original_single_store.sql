-- VDX_ORIGINALS: convert retained legacy products to the single-store model.
ALTER TABLE public.products
  ALTER COLUMN sold_by_type SET DEFAULT 'welcome_wagon'::public.sold_by_type;

UPDATE public.products
SET vendor_id = NULL,
    sold_by_type = 'welcome_wagon'::public.sold_by_type;
