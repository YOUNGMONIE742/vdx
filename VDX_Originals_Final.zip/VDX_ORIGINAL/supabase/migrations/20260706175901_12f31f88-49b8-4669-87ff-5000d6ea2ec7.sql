
-- ================== Extensions for scheduled auto-cancel ==================
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- ================== Product stock reservation ==================
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS reserved_stock integer NOT NULL DEFAULT 0
    CHECK (reserved_stock >= 0);

-- ================== Order contact + expiry ==================
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS customer_name text,
  ADD COLUMN IF NOT EXISTS customer_email text,
  ADD COLUMN IF NOT EXISTS payment_expires_at timestamptz;

-- Default expiry: 1 hour after creation, only meaningful while awaiting payment.
CREATE OR REPLACE FUNCTION private.orders_set_payment_expiry()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.payment_expires_at IS NULL THEN
    NEW.payment_expires_at := now() + interval '1 hour';
  END IF;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS orders_set_payment_expiry ON public.orders;
CREATE TRIGGER orders_set_payment_expiry
  BEFORE INSERT ON public.orders
  FOR EACH ROW EXECUTE FUNCTION private.orders_set_payment_expiry();

-- ================== Reserve stock on order_items INSERT ==================
CREATE OR REPLACE FUNCTION private.reserve_stock_on_item()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  UPDATE public.products
     SET reserved_stock = reserved_stock + NEW.quantity
   WHERE id = NEW.product_id
     AND (stock - reserved_stock) >= NEW.quantity;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Not enough stock available for product %', NEW.product_id
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS reserve_stock_on_item ON public.order_items;
CREATE TRIGGER reserve_stock_on_item
  AFTER INSERT ON public.order_items
  FOR EACH ROW EXECUTE FUNCTION private.reserve_stock_on_item();

-- ================== Release / commit stock on order status change ==================
CREATE OR REPLACE FUNCTION private.orders_stock_on_status_change()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE
  released_states text[] := ARRAY['cancelled','refunded','returned'];
  active_states   text[] := ARRAY['pending_payment','payment_review','paid','processing','packed','shipped','out_for_delivery'];
  item record;
BEGIN
  -- Reservation released (no fulfillment)
  IF NEW.status::text = ANY(released_states) AND OLD.status::text = ANY(active_states) THEN
    FOR item IN SELECT product_id, quantity FROM public.order_items WHERE order_id = NEW.id LOOP
      UPDATE public.products
         SET reserved_stock = GREATEST(reserved_stock - item.quantity, 0)
       WHERE id = item.product_id;
    END LOOP;
  END IF;
  -- Delivered = permanent consumption
  IF NEW.status::text = 'delivered' AND OLD.status::text <> 'delivered' THEN
    FOR item IN SELECT product_id, quantity FROM public.order_items WHERE order_id = NEW.id LOOP
      UPDATE public.products
         SET stock = GREATEST(stock - item.quantity, 0),
             reserved_stock = GREATEST(reserved_stock - item.quantity, 0)
       WHERE id = item.product_id;
    END LOOP;
  END IF;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS orders_stock_on_status_change ON public.orders;
CREATE TRIGGER orders_stock_on_status_change
  AFTER UPDATE OF status ON public.orders
  FOR EACH ROW EXECUTE FUNCTION private.orders_stock_on_status_change();

-- ================== Scheduled auto-cancel of unpaid orders ==================
CREATE OR REPLACE FUNCTION private.expire_pending_orders()
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  n integer;
BEGIN
  WITH updated AS (
    UPDATE public.orders
       SET status = 'cancelled'
     WHERE status = 'pending_payment'
       AND payment_expires_at IS NOT NULL
       AND payment_expires_at < now()
    RETURNING id
  )
  SELECT count(*) INTO n FROM updated;
  RETURN n;
END; $$;
REVOKE ALL ON FUNCTION private.expire_pending_orders() FROM PUBLIC, anon, authenticated;

-- Run every 5 minutes; safe no-op when nothing to cancel.
DO $$
BEGIN
  PERFORM cron.unschedule('expire-pending-orders')
    WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'expire-pending-orders');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

SELECT cron.schedule(
  'expire-pending-orders',
  '*/5 * * * *',
  $$SELECT private.expire_pending_orders();$$
);
