-- The site-assets bucket (Admin -> Settings logo upload, and the signed-URL
-- read used to render the logo) had no storage policies at all, so both the
-- upload and the read were denied.
drop policy if exists vdx_site_assets_read on storage.objects;
drop policy if exists vdx_site_assets_insert on storage.objects;
drop policy if exists vdx_site_assets_update on storage.objects;
drop policy if exists vdx_site_assets_delete on storage.objects;

create policy vdx_site_assets_read on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'site-assets');

create policy vdx_site_assets_insert on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'site-assets'
    and (has_role(auth.uid(), 'admin'::app_role) or has_role(auth.uid(), 'super_admin'::app_role))
  );

create policy vdx_site_assets_update on storage.objects
  for update to authenticated
  using (
    bucket_id = 'site-assets'
    and (has_role(auth.uid(), 'admin'::app_role) or has_role(auth.uid(), 'super_admin'::app_role))
  )
  with check (
    bucket_id = 'site-assets'
    and (has_role(auth.uid(), 'admin'::app_role) or has_role(auth.uid(), 'super_admin'::app_role))
  );

create policy vdx_site_assets_delete on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'site-assets'
    and (has_role(auth.uid(), 'admin'::app_role) or has_role(auth.uid(), 'super_admin'::app_role))
  );
