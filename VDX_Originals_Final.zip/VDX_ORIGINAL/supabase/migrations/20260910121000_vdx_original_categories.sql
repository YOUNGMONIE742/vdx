-- VDX_ORIGINALS: replace the legacy kids/marketplace categories with clothing collections.
DELETE FROM public.categories;

INSERT INTO public.categories (name, slug, display_order, description) VALUES
  ('Women', 'women', 1, 'Women''s clothing and selected pieces.'),
  ('Men', 'men', 2, 'Men''s clothing and selected pieces.'),
  ('Shirts', 'shirts', 3, 'Shirts and versatile tops.'),
  ('Trousers', 'trousers', 4, 'Trousers and everyday bottoms.'),
  ('Dresses', 'dresses', 5, 'Dresses for effortless dressing.');
