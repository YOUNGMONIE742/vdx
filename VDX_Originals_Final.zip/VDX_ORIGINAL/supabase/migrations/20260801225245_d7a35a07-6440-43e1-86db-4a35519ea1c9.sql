-- ============ BUG 1: vendor approval ============
CREATE OR REPLACE FUNCTION public.approve_vendor_application(p_app_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  app public.vendor_applications%ROWTYPE;
  v_id uuid;
  v_slug text;
BEGIN
  IF NOT private.has_role(auth.uid(), 'super_admin') THEN
    RAISE EXCEPTION 'Only a super admin can approve vendor applications';
  END IF;

  SELECT * INTO app FROM public.vendor_applications WHERE id = p_app_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Application not found';
  END IF;

  SELECT id INTO v_id FROM public.vendors WHERE user_id = app.user_id;
  IF v_id IS NULL THEN
    v_slug := regexp_replace(lower(coalesce(app.store_name, 'store')), '[^a-z0-9]+', '-', 'g');
    v_slug := trim(both '-' from v_slug);
    IF v_slug = '' THEN v_slug := 'store'; END IF;
    IF EXISTS (SELECT 1 FROM public.vendors WHERE slug = v_slug) THEN
      v_slug := v_slug || '-' || substr(md5(random()::text), 1, 4);
    END IF;
    INSERT INTO public.vendors (user_id, store_name, slug, description, logo_url, contact_phone, contact_email, is_active)
    VALUES (app.user_id, app.store_name, v_slug, app.store_description, app.store_logo_url, app.contact_phone, app.contact_email, true)
    RETURNING id INTO v_id;
  ELSE
    UPDATE public.vendors SET is_active = true WHERE id = v_id;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (app.user_id, 'vendor')
  ON CONFLICT (user_id, role) DO NOTHING;

  UPDATE public.vendor_applications
     SET status = 'approved',
         payment_verified = true,
         reviewed_by = auth.uid(),
         reviewed_at = now()
   WHERE id = p_app_id;

  RETURN v_id;
END; $$;

REVOKE ALL ON FUNCTION public.approve_vendor_application(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.approve_vendor_application(uuid) TO authenticated;

-- backfill: approved applications missing the vendor role
INSERT INTO public.user_roles (user_id, role)
SELECT DISTINCT va.user_id, 'vendor'::app_role
FROM public.vendor_applications va
WHERE va.status = 'approved'
ON CONFLICT (user_id, role) DO NOTHING;

-- ============ BUG 2: stock synchronisation ============
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS stock_consumed boolean NOT NULL DEFAULT false;

CREATE OR REPLACE FUNCTION private.orders_stock_on_status_change()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  released_states text[] := ARRAY['cancelled','refunded','returned'];
  consumed_states text[] := ARRAY['paid','processing','packed','shipped','out_for_delivery','delivered'];
  item record;
BEGIN
  -- Payment accepted (or beyond): permanently reduce stock, once.
  IF NEW.status::text = ANY(consumed_states) AND NOT OLD.stock_consumed THEN
    FOR item IN SELECT product_id, quantity FROM public.order_items WHERE order_id = NEW.id LOOP
      UPDATE public.products
         SET stock = GREATEST(stock - item.quantity, 0),
             reserved_stock = GREATEST(reserved_stock - item.quantity, 0)
       WHERE id = item.product_id;
    END LOOP;
    UPDATE public.orders SET stock_consumed = true WHERE id = NEW.id;
  END IF;

  -- Order failed / reversed: give inventory back.
  IF NEW.status::text = ANY(released_states) THEN
    IF OLD.stock_consumed THEN
      FOR item IN SELECT product_id, quantity FROM public.order_items WHERE order_id = NEW.id LOOP
        UPDATE public.products SET stock = stock + item.quantity WHERE id = item.product_id;
      END LOOP;
      UPDATE public.orders SET stock_consumed = false WHERE id = NEW.id;
    ELSE
      FOR item IN SELECT product_id, quantity FROM public.order_items WHERE order_id = NEW.id LOOP
        UPDATE public.products
           SET reserved_stock = GREATEST(reserved_stock - item.quantity, 0)
         WHERE id = item.product_id;
      END LOOP;
    END IF;
  END IF;

  RETURN NEW;
END; $$;
