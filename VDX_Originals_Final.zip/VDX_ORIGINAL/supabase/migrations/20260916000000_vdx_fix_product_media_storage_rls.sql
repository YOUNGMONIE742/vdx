-- Fix: storage.objects had NO policies at all for the 'product-media'
-- bucket on the live project (RLS is enabled with zero matching
-- policies = every operation, including Admin uploads, is denied by
-- default). Earlier migration files in this repo (20260910170000,
-- 20260914120000) were never actually applied to the live database and
-- also referenced a non-existent `private.has_role` function — the live
-- project only has `public.has_role(uuid, app_role)`. This migration adds
-- the missing, minimal policies using the function that actually exists,
-- matching the role model already used by public.products.
--
-- Read: anon + authenticated (storefront needs to render signed URLs for
-- product images/videos to shoppers, including logged-out visitors).
-- Write (insert/update/delete): Admin and Super Admin only.

DROP POLICY IF EXISTS "vdx_product_media_read" ON storage.objects;
CREATE POLICY "vdx_product_media_read"
ON storage.objects FOR SELECT
TO authenticated, anon
USING (bucket_id = 'product-media');

DROP POLICY IF EXISTS "vdx_product_media_insert" ON storage.objects;
CREATE POLICY "vdx_product_media_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'product-media'
  AND (public.has_role(auth.uid(), 'admin'::public.app_role)
       OR public.has_role(auth.uid(), 'super_admin'::public.app_role))
);

DROP POLICY IF EXISTS "vdx_product_media_update" ON storage.objects;
CREATE POLICY "vdx_product_media_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'product-media'
  AND (public.has_role(auth.uid(), 'admin'::public.app_role)
       OR public.has_role(auth.uid(), 'super_admin'::public.app_role))
)
WITH CHECK (
  bucket_id = 'product-media'
  AND (public.has_role(auth.uid(), 'admin'::public.app_role)
       OR public.has_role(auth.uid(), 'super_admin'::public.app_role))
);

DROP POLICY IF EXISTS "vdx_product_media_delete" ON storage.objects;
CREATE POLICY "vdx_product_media_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'product-media'
  AND (public.has_role(auth.uid(), 'admin'::public.app_role)
       OR public.has_role(auth.uid(), 'super_admin'::public.app_role))
);
