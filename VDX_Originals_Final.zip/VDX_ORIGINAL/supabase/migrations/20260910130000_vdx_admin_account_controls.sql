-- VDX_ORIGINALS: reliable Super Admin user management and account controls.
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;

CREATE INDEX IF NOT EXISTS profiles_is_active_idx ON public.profiles(is_active);

-- Return the customer/admin accounts visible to Super Admins. This reads auth.users
-- as a fallback so a newly registered account is still visible even if its profile
-- trigger was delayed or failed.
CREATE OR REPLACE FUNCTION public.get_admin_users()
RETURNS TABLE (
  id UUID,
  email TEXT,
  full_name TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ,
  is_active BOOLEAN,
  roles public.app_role[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  actor_email TEXT := lower(trim(coalesce(auth.jwt() ->> 'email', '')));
BEGIN
  -- VDX_ORIGINALS has exactly two Super Admin identities. Avoid depending on
  -- another helper schema here so this RPC remains reliable after migration.
  IF actor_email NOT IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com') THEN
    RAISE EXCEPTION 'Only a Super Admin can view user management';
  END IF;

  RETURN QUERY
  SELECT
    u.id,
    u.email::text,
    p.full_name,
    p.phone,
    u.created_at,
    coalesce(p.is_active, true),
    CASE
      WHEN lower(coalesce(u.email, '')) IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com')
        THEN ARRAY['super_admin'::public.app_role]
      ELSE coalesce(
        ARRAY(
          SELECT ur.role
          FROM public.user_roles ur
          WHERE ur.user_id = u.id
            AND ur.role <> 'vendor'::public.app_role
          ORDER BY CASE ur.role
            WHEN 'super_admin' THEN 1
            WHEN 'admin' THEN 2
            WHEN 'customer' THEN 3
            ELSE 99
          END
        ),
        ARRAY['customer'::public.app_role]
      )
    END
  FROM auth.users u
  LEFT JOIN public.profiles p ON p.id = u.id
  ORDER BY u.created_at DESC;
END;
$$;

REVOKE ALL ON FUNCTION public.get_admin_users() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_users() TO authenticated;

-- Super Admin account activation/deactivation. Protected Super Admins can never
-- be disabled by this function.
CREATE OR REPLACE FUNCTION public.set_user_active(p_user_id UUID, p_active BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, private
AS $$
DECLARE
  actor_email TEXT := lower(coalesce(auth.jwt() ->> 'email', ''));
  target_email TEXT;
BEGIN
  IF actor_email NOT IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com')
     AND NOT private.has_role(auth.uid(), 'super_admin'::public.app_role) THEN
    RAISE EXCEPTION 'Only a Super Admin can disable or enable accounts';
  END IF;

  SELECT lower(email) INTO target_email FROM auth.users WHERE id = p_user_id;
  IF target_email IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  IF target_email IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com') THEN
    RAISE EXCEPTION 'Protected Super Admin accounts cannot be disabled';
  END IF;

  INSERT INTO public.profiles (id, email)
  SELECT id, email FROM auth.users WHERE id = p_user_id
  ON CONFLICT (id) DO NOTHING;

  UPDATE public.profiles
  SET is_active = p_active
  WHERE id = p_user_id;

  RETURN p_active;
END;
$$;

REVOKE ALL ON FUNCTION public.set_user_active(UUID, BOOLEAN) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_user_active(UUID, BOOLEAN) TO authenticated;

-- Ensure only the two designated emails can carry the Super Admin role.
DELETE FROM public.user_roles ur
USING public.profiles p
WHERE ur.user_id = p.id
  AND ur.role = 'super_admin'::public.app_role
  AND lower(p.email) NOT IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com');

-- Database-level protection: no other account can ever receive super_admin,
-- and the two protected Super Admin role rows cannot be removed or demoted.
CREATE OR REPLACE FUNCTION public.enforce_vdx_super_admin_roles()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  target_email TEXT;
BEGIN
  SELECT lower(email) INTO target_email FROM auth.users WHERE id = COALESCE(NEW.user_id, OLD.user_id);

  IF TG_OP = 'INSERT' AND NEW.role = 'super_admin'::public.app_role
     AND target_email NOT IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com') THEN
    RAISE EXCEPTION 'Only the two protected VDX_ORIGINALS emails may be Super Admins';
  END IF;

  IF TG_OP = 'UPDATE' AND OLD.role = 'super_admin'::public.app_role
     AND OLD.user_id <> NEW.user_id THEN
    RAISE EXCEPTION 'Protected Super Admin role cannot be moved';
  END IF;

  IF TG_OP = 'UPDATE' AND OLD.role = 'super_admin'::public.app_role
     AND NEW.role <> 'super_admin'::public.app_role
     AND target_email IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com') THEN
    RAISE EXCEPTION 'Protected Super Admin accounts cannot be demoted';
  END IF;

  IF TG_OP = 'DELETE' AND OLD.role = 'super_admin'::public.app_role
     AND target_email IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com') THEN
    RAISE EXCEPTION 'Protected Super Admin accounts cannot lose Super Admin access';
  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS protect_vdx_super_admin_roles ON public.user_roles;
CREATE TRIGGER protect_vdx_super_admin_roles
BEFORE INSERT OR UPDATE OR DELETE ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.enforce_vdx_super_admin_roles();

-- Remove any legacy Super Admin rows even if a legacy profile row is missing.
DELETE FROM public.user_roles ur
USING auth.users u
WHERE ur.user_id = u.id
  AND ur.role = 'super_admin'::public.app_role
  AND lower(u.email) NOT IN ('bhabeeb742@gmail.com','vdxoriginals@gmail.com');
