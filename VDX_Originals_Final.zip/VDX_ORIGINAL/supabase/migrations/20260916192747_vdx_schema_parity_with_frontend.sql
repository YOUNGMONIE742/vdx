-- Schema parity fixes: the live database was missing columns that both the
-- frontend code and the generated src/integrations/supabase/types.ts assume
-- exist. Each gap below broke a real, shipped user flow.

-- 1. profiles.username -- collected at signup, edited in Settings, read by
--    auth-context, the dashboard and the support form. The profile update
--    failed outright without it.
alter table public.profiles add column if not exists username text;

-- 2. products.decline_reason -- Admin -> Products selects it (so the select
--    errored and every tab showed "No products") and writes it when declining.
alter table public.products add column if not exists decline_reason text;

-- products.status defaulted to 'active', a value no screen ever filters on,
-- so a product created without an explicit status was invisible everywhere.
alter table public.products alter column status set default 'draft';

-- 3. order_items.sold_by_type / vendor_id -- checkout inserts both. Without
--    them every checkout created an order row and then failed on the items
--    insert, leaving an orphaned order. The orders pages also select them.
alter table public.order_items add column if not exists sold_by_type text not null default 'welcome_wagon';
alter table public.order_items add column if not exists vendor_id uuid;

-- 4. products_availability RPC -- called by cart-context to drop items whose
--    product is no longer purchasable. The function did not exist, so the
--    cart-protection feature was silently dead.
create or replace function public.products_availability(p_ids uuid[])
returns table (product_id uuid, available boolean)
language sql
stable
security definer
set search_path = public
as $$
  select p.id,
         (p.status = 'approved'
          and p.visibility = 'public'
          and greatest(p.stock - p.reserved_stock, 0) > 0) as available
  from public.products p
  where p.id = any(p_ids);
$$;

grant execute on function public.products_availability(uuid[]) to anon, authenticated;

-- 5. products SELECT policies -- one existing policy was USING (true), which
--    exposed draft, pending and declined products (and non-public ones) to
--    anonymous visitors. Replaced with scoped read access.
drop policy if exists products_public_read on public.products;
drop policy if exists vdx_products_public_read on public.products;

create policy products_read_public on public.products
  for select
  using (visibility = 'public' and status = 'approved');

create policy products_read_staff on public.products
  for select
  using (has_role(auth.uid(), 'admin'::app_role) or has_role(auth.uid(), 'super_admin'::app_role));

create policy products_read_owner on public.products
  for select
  using (created_by = auth.uid());
