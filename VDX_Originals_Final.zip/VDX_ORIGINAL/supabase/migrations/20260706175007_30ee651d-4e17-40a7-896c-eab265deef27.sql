
ALTER VIEW public.public_vendors SET (security_invoker = true);

-- Column-level SELECT so anon/authenticated can never read contact_email/contact_phone.
REVOKE SELECT ON public.vendors FROM anon;
GRANT SELECT (id, user_id, store_name, slug, description, logo_url, rating, total_sold, joined_at, is_active)
  ON public.vendors TO anon, authenticated;

-- Row-level access limited to active vendor rows for public reads.
DROP POLICY IF EXISTS vendors_public_active_read ON public.vendors;
CREATE POLICY vendors_public_active_read ON public.vendors
  FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

-- View needs to resolve user_roles too; allow reading only role rows (no sensitive data).
GRANT SELECT (user_id, role) ON public.user_roles TO anon;
DROP POLICY IF EXISTS user_roles_public_read ON public.user_roles;
CREATE POLICY user_roles_public_read ON public.user_roles
  FOR SELECT
  TO anon, authenticated
  USING (role = 'vendor'::app_role);
