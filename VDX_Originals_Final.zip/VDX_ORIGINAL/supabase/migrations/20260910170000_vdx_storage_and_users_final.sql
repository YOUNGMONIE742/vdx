-- VDX_ORIGINALS final storage + user-management reliability fix.
-- Run this migration in the VDX_ORIGINALS Supabase project.

-- ============================================================
-- 1) Create the storage buckets used by the application.
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES
  ('product-media', 'product-media', false),
  ('store-logos', 'store-logos', false),
  ('site-assets', 'site-assets', false),
  ('payment-proofs', 'payment-proofs', false)
ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- 2) Storage policies. These are intentionally idempotent.
-- Product/store/site assets can be read through signed URLs.
-- Upload paths must begin with the authenticated user's UUID.
-- ============================================================
DROP POLICY IF EXISTS "vdx_product_media_read" ON storage.objects;
CREATE POLICY "vdx_product_media_read"
ON storage.objects FOR SELECT
TO authenticated, anon
USING (bucket_id = 'product-media');

DROP POLICY IF EXISTS "vdx_product_media_insert" ON storage.objects;
CREATE POLICY "vdx_product_media_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'product-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_product_media_update" ON storage.objects;
CREATE POLICY "vdx_product_media_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'product-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'product-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_product_media_delete" ON storage.objects;
CREATE POLICY "vdx_product_media_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'product-media'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_store_logos_read" ON storage.objects;
CREATE POLICY "vdx_store_logos_read"
ON storage.objects FOR SELECT
TO authenticated, anon
USING (bucket_id = 'store-logos');

DROP POLICY IF EXISTS "vdx_store_logos_insert" ON storage.objects;
CREATE POLICY "vdx_store_logos_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'store-logos'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_store_logos_update" ON storage.objects;
CREATE POLICY "vdx_store_logos_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'store-logos'
  AND (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'store-logos'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_store_logos_delete" ON storage.objects;
CREATE POLICY "vdx_store_logos_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'store-logos'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_site_assets_read" ON storage.objects;
CREATE POLICY "vdx_site_assets_read"
ON storage.objects FOR SELECT
TO authenticated, anon
USING (bucket_id = 'site-assets');

DROP POLICY IF EXISTS "vdx_site_assets_insert" ON storage.objects;
CREATE POLICY "vdx_site_assets_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'site-assets'
  AND private.has_role(auth.uid(), 'super_admin'::public.app_role)
);

DROP POLICY IF EXISTS "vdx_site_assets_update" ON storage.objects;
CREATE POLICY "vdx_site_assets_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'site-assets'
  AND private.has_role(auth.uid(), 'super_admin'::public.app_role)
)
WITH CHECK (
  bucket_id = 'site-assets'
  AND private.has_role(auth.uid(), 'super_admin'::public.app_role)
);

DROP POLICY IF EXISTS "vdx_site_assets_delete" ON storage.objects;
CREATE POLICY "vdx_site_assets_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'site-assets'
  AND private.has_role(auth.uid(), 'super_admin'::public.app_role)
);

DROP POLICY IF EXISTS "vdx_payment_proofs_read_owner" ON storage.objects;
CREATE POLICY "vdx_payment_proofs_read_owner"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_payment_proofs_read_admin" ON storage.objects;
CREATE POLICY "vdx_payment_proofs_read_admin"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND (
    private.has_role(auth.uid(), 'admin'::public.app_role)
    OR private.has_role(auth.uid(), 'super_admin'::public.app_role)
  )
);

DROP POLICY IF EXISTS "vdx_payment_proofs_insert" ON storage.objects;
CREATE POLICY "vdx_payment_proofs_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'payment-proofs'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_payment_proofs_update" ON storage.objects;
CREATE POLICY "vdx_payment_proofs_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'payment-proofs'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "vdx_payment_proofs_delete" ON storage.objects;
CREATE POLICY "vdx_payment_proofs_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- ============================================================
-- 3) Make the new-user trigger reliable and correct the two
-- protected Super Admin identities.
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _email TEXT := lower(trim(NEW.email));
BEGIN
  INSERT INTO public.profiles (id, email, full_name, username, phone)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name'),
    NEW.raw_user_meta_data->>'username',
    NEW.raw_user_meta_data->>'phone'
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = COALESCE(public.profiles.full_name, EXCLUDED.full_name),
    phone = COALESCE(public.profiles.phone, EXCLUDED.phone),
    updated_at = now();

  IF _email IN ('bhabeeb742@gmail.com', 'vdxoriginals@gmail.com') THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'super_admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  ELSE
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'customer')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- 4) Final robust user-list RPC. It checks the caller's actual
-- auth.users email rather than relying on JWT email claims.
-- It also repairs missing profiles for existing auth accounts.
-- ============================================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE;

CREATE OR REPLACE FUNCTION public.get_admin_users()
RETURNS TABLE (
  id UUID,
  email TEXT,
  full_name TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ,
  is_active BOOLEAN,
  roles public.app_role[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  actor_email TEXT;
BEGIN
  SELECT lower(trim(email)) INTO actor_email
  FROM auth.users
  WHERE id = auth.uid();

  IF actor_email NOT IN ('bhabeeb742@gmail.com', 'vdxoriginals@gmail.com') THEN
    RAISE EXCEPTION 'Only a Super Admin can view user management';
  END IF;

  -- Ensure every existing Auth account has a profile row.
  INSERT INTO public.profiles (id, email)
  SELECT u.id, u.email
  FROM auth.users u
  LEFT JOIN public.profiles p ON p.id = u.id
  WHERE p.id IS NULL
  ON CONFLICT (id) DO NOTHING;

  RETURN QUERY
  SELECT
    u.id,
    u.email::text,
    p.full_name,
    p.phone,
    u.created_at,
    COALESCE(p.is_active, TRUE),
    CASE
      WHEN lower(trim(COALESCE(u.email, ''))) IN ('bhabeeb742@gmail.com', 'vdxoriginals@gmail.com')
      THEN ARRAY['super_admin'::public.app_role]
      ELSE COALESCE(
        ARRAY(
          SELECT ur.role
          FROM public.user_roles ur
          WHERE ur.user_id = u.id
            AND ur.role <> 'vendor'::public.app_role
          ORDER BY CASE ur.role
            WHEN 'super_admin' THEN 1
            WHEN 'admin' THEN 2
            WHEN 'customer' THEN 3
            ELSE 99
          END
        ),
        ARRAY['customer'::public.app_role]
      )
    END
  FROM auth.users u
  LEFT JOIN public.profiles p ON p.id = u.id
  ORDER BY u.created_at DESC;
END;
$$;

REVOKE ALL ON FUNCTION public.get_admin_users() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_users() TO authenticated;

-- ============================================================
-- 5) Backfill existing accounts and roles.
-- ============================================================
INSERT INTO public.profiles (id, email)
SELECT u.id, u.email
FROM auth.users u
LEFT JOIN public.profiles p ON p.id = u.id
WHERE p.id IS NULL
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.user_roles (user_id, role)
SELECT u.id, 'customer'::public.app_role
FROM auth.users u
LEFT JOIN public.user_roles ur ON ur.user_id = u.id
WHERE ur.user_id IS NULL
  AND lower(trim(u.email)) NOT IN ('bhabeeb742@gmail.com', 'vdxoriginals@gmail.com')
ON CONFLICT (user_id, role) DO NOTHING;

INSERT INTO public.user_roles (user_id, role)
SELECT u.id, 'super_admin'::public.app_role
FROM auth.users u
WHERE lower(trim(u.email)) IN ('bhabeeb742@gmail.com', 'vdxoriginals@gmail.com')
ON CONFLICT (user_id, role) DO NOTHING;

-- Remove any legacy/incorrect Super Admin identities.
DELETE FROM public.user_roles ur
USING auth.users u
WHERE ur.user_id = u.id
  AND ur.role = 'super_admin'::public.app_role
  AND lower(trim(u.email)) NOT IN ('bhabeeb742@gmail.com', 'vdxoriginals@gmail.com');
