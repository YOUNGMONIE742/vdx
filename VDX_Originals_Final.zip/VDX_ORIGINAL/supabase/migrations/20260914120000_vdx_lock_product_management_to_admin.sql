-- VDX_ORIGINALS: VDX_ORIGINALS is a single-store clothing shop, not a marketplace.
-- The original codebase (Welcome Wagon marketplace) let ANY authenticated user
-- insert/update/delete rows in public.products, public.product_images, and
-- write into the product-media / store-logos storage buckets as long as they
-- "owned" the row (created_by = auth.uid() / folder = auth.uid()). That is a
-- leftover vendor self-service permission model. It means a signed-in customer
-- could currently call the Supabase client directly (bypassing the UI) and:
--   - insert a new product with status = 'approved', making it publicly visible
--   - edit or delete products they created
--   - upload arbitrary files into the product-media bucket
-- This migration removes that owner-based write access and restricts all
-- product/catalog writes to Admin and Super Admin, matching the app's actual
-- UI (only /admin/products, /products/new, /products/:id/edit are used, and
-- all of them are meant for staff only). This is additive/corrective only —
-- no data is deleted and public read access is unchanged.

-- ============================================================
-- 1) products: remove owner-based write policies.
-- ============================================================
DROP POLICY IF EXISTS products_owner_insert ON public.products;
DROP POLICY IF EXISTS products_owner_update ON public.products;
DROP POLICY IF EXISTS products_owner_delete ON public.products;

-- products_admin_all (FOR ALL, admin/super_admin) already exists and now
-- becomes the only way to insert/update/delete products.
-- products_public_view_approved and products_owner_view / products_admin_view
-- are left in place — they are read-only and harmless.

-- ============================================================
-- 2) product_images: restrict writes to admin/super_admin only.
-- ============================================================
DROP POLICY IF EXISTS pi_owner_write ON public.product_images;

DROP POLICY IF EXISTS pi_admin_write ON public.product_images;
CREATE POLICY pi_admin_write ON public.product_images
FOR ALL TO authenticated
USING (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role));

-- ============================================================
-- 3) Storage: product-media and store-logos writes are staff-only.
-- Read access (needed for public storefront images and signed URLs) is
-- unchanged.
-- ============================================================
DROP POLICY IF EXISTS "vdx_product_media_insert" ON storage.objects;
CREATE POLICY "vdx_product_media_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'product-media'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
);

DROP POLICY IF EXISTS "vdx_product_media_update" ON storage.objects;
CREATE POLICY "vdx_product_media_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'product-media'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
)
WITH CHECK (
  bucket_id = 'product-media'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
);

DROP POLICY IF EXISTS "vdx_product_media_delete" ON storage.objects;
CREATE POLICY "vdx_product_media_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'product-media'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
);

DROP POLICY IF EXISTS "vdx_store_logos_insert" ON storage.objects;
CREATE POLICY "vdx_store_logos_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'store-logos'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
);

DROP POLICY IF EXISTS "vdx_store_logos_update" ON storage.objects;
CREATE POLICY "vdx_store_logos_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'store-logos'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
)
WITH CHECK (
  bucket_id = 'store-logos'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
);

DROP POLICY IF EXISTS "vdx_store_logos_delete" ON storage.objects;
CREATE POLICY "vdx_store_logos_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'store-logos'
  AND (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role))
);

-- ============================================================
-- 4) Critical fix: Super Admin could not actually grant/revoke the Admin
-- role or approve Admin applications. The RLS policy
-- "user_roles_super_admin_manage" (FOR ALL, super_admin only) already
-- existed and is correct, but the table-level GRANT for the `authenticated`
-- role only ever included SELECT — INSERT/UPDATE/DELETE were never granted.
-- In Postgres, a GRANT is required in addition to a passing RLS policy;
-- without it every write from admin.users.tsx / admin.admin-applications.tsx
-- (both of which write directly to public.user_roles) fails with a
-- "permission denied for table user_roles" error. This grant is safe: the
-- existing FOR ALL RLS policy still restricts all writes to Super Admins,
-- and the enforce_vdx_super_admin_roles trigger still protects the two
-- permanent Super Admin role rows from being moved, demoted or deleted.
-- ============================================================
GRANT INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;

-- ============================================================
-- 5) Functional fix: targeted Announcements ("notify specific emails") were
-- silently failing. admin.announcements.tsx inserts directly into
-- public.notifications on behalf of the target users, but that table only
-- ever had GRANT SELECT, UPDATE to authenticated (no INSERT grant, and no
-- INSERT policy at all). Broadcast-style announcements (audience =
-- all/customers/admins) still worked because they are read straight from
-- public.announcements, but picking specific recipient emails did not.
-- Order-status and other system notifications are unaffected — those are
-- written by SECURITY DEFINER trigger functions (private.notify_user),
-- which do not depend on the calling user's grants.
-- ============================================================
GRANT INSERT ON public.notifications TO authenticated;

DROP POLICY IF EXISTS notif_admin_insert ON public.notifications;
CREATE POLICY notif_admin_insert ON public.notifications
FOR INSERT TO authenticated
WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role) OR private.has_role(auth.uid(), 'super_admin'::public.app_role));
