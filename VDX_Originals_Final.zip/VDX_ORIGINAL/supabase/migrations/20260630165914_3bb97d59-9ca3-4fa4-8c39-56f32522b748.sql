-- Revoke EXECUTE on SECURITY DEFINER helpers from public roles. They remain callable
-- inside RLS policies (planner uses table owner privileges), but no longer exposed via PostgREST.
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.current_user_role() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO service_role;
GRANT EXECUTE ON FUNCTION public.current_user_role() TO service_role;